package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class ReadAETitleValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class ReadAETitleValidatorTest {

	/** The validator. */
	@InjectMocks
	private ReadAETitleValidator validator = new ReadAETitleValidator();

	/** The read ae title dto. */
	ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test validate input fields.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {

		int val = validator.validateInputFields(readAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
		verify(validator, times(1)).validateInputFields(readAETitleDTO);

	}

	/**
	 * Test validate input fields2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {

		readAETitleDTO.setSapId(IdexxDicomTestConstants.SAPID);
		int val = validator.validateInputFields(readAETitleDTO);
		assertTrue("Validation Failing#2", val == 1);

	}

	/**
	 * Test validate input fields3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateInputFields3() throws IdexxDicomAEConfigServiceException {

		readAETitleDTO.setAeTitle(IdexxDicomTestConstants.AETITLE);
		int val = validator.validateInputFields(readAETitleDTO);
		assertTrue("Validation Failing#2", val == 1);
	}

	/**
	 * Test validate db fields.
	 */
	@Test
	public final void testValidateDBFields() {

		int val = validator.validateDBFields(readAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
	}
}
