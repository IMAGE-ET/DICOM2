/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v12;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.CancelSendJobParamDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class CancelSendJobServiceValidatorImplTest.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class CancelSendJobServiceValidatorImplTest {

	/** The obj in test. */
	@InjectMocks
	private CancelSendJobServiceValidatorImpl objInTest = new CancelSendJobServiceValidatorImpl();

	/** The cancel send job param dto. */
	CancelSendJobParamDTO cancelSendJobParamDTO = new CancelSendJobParamDTO();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test for excpetion.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testForExcpetion() throws IdexxDicomAEConfigServiceException {

		cancelSendJobParamDTO.setJobStatusDescription("Test descp");
		objInTest.validate(cancelSendJobParamDTO);

	}

	/**
	 * Test for return value.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testForReturnValue() throws IdexxDicomAEConfigServiceException {

		cancelSendJobParamDTO.setJobStatusDescription("Test descp");
		cancelSendJobParamDTO.setJobId("Test Jobid");
		int i = objInTest.validate(cancelSendJobParamDTO);
		assertEquals(i, 1);
	}

}
