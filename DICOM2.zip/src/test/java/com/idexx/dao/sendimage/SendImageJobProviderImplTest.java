/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.impl.SendImageJobProviderImpl;

// TODO: Auto-generated Javadoc
/**
 * Test class from SendImageJobProviderImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class SendImageJobProviderImplTest {

	
	/** The obj in test. */
	@InjectMocks
	private SendImageJobProvider objInTest = new SendImageJobProviderImpl();

	/** The job dao. */
	@Mock
	private DicomJobDao jobDao;

	/** The result list. */
	List<IdexxSendImageJob> resultList = new ArrayList<IdexxSendImageJob>();

	/** The idexxjob. */
	IdexxSendImageJob idexxjob = new IdexxSendImageJob();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		idexxjob.setJobId(IdexxDicomTestConstants.TESTJOBID);
		resultList.add(idexxjob);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test_get_pending_jobs.
	 */
	@Test
	public void testGetSendingjobs() {
		when(jobDao.getPendingJobs(IdexxDicomTestConstants.JOB_COUNT)).thenReturn(resultList);
		List<IdexxSendImageJob> originalList = objInTest.getPendingJobs(IdexxDicomTestConstants.JOB_COUNT);
		assertTrue(originalList.size() > 0);
	}

	/**
	 * Test_update_inprogess_jobs.
	 */
	@Test
	public void testUpdateInprogessJobs() {

		doNothing().when(jobDao).updateAllInProgressJobs(anyString());
		objInTest.updateInProgressJobs(anyString());
		verify(jobDao, times(1)).updateAllInProgressJobs(anyString());
	}

	/**
	 * Test_update_jobs_to_inprogess.
	 */
	@Test
	public void testUpdateJobsToInprogess() {

		doNothing().when(jobDao).updateJobsToInProgressStatus(anyObject());
		objInTest.updateJobsToInProgressStatus(anyObject());
		verify(jobDao, times(1)).updateJobsToInProgressStatus(anyObject());
	}

}
