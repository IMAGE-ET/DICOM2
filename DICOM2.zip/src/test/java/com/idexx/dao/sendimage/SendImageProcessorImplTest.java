/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.sendimage.exceptions.SendRetryCountExceedException;
import com.idexx.dicom.sendimage.impl.SendImageException;
import com.idexx.dicom.sendimage.impl.SendImageProcessorImpl;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;

// TODO: Auto-generated Javadoc
/**
 * Test Cases Related CancelRequestServiceImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class SendImageProcessorImplTest  {

	/** The job provider. */
	@Mock
	private SendImageJobProvider jobProvider;

	/** The job update service. */
	@Mock
	private SendImageJobUpdateService jobUpdateService;

	/** The presigned url provider. */
	@Mock
	private ImagePresignedUrlProvider presignedUrlProvider;

	/** The image downloader. */
	@Mock
	private TimedImageDownloader imageDownloader;

	/** The config dao. */
	@Mock
	private DicomConfigDao configDao;

	/** The send image service. */
	@Mock
	private SendImage sendImageService;

	/** The entity mapper. */
	@Mock
	private EntityMapper entityMapper;

	/** The base dicom im plugin config. */
	private BaseDicomImPluginConfig baseDicomImPluginConfig;

	/** The send job. */
	SendImagePendingJobDTO sendJob = new SendImagePendingJobDTO();

	/** The obj in test. */
	@InjectMocks
	private SendImageProcessorImpl objInTest = new SendImageProcessorImpl(sendJob, jobUpdateService,
			presignedUrlProvider, imageDownloader, configDao, sendImageService);

	/** The jobs. */
	List<IdexxSendImageJob> jobs = new ArrayList<IdexxSendImageJob>();

	/** The send image dtos. */
	List<SendImagePendingJobDTO> sendImageDtos = new ArrayList<SendImagePendingJobDTO>();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		baseDicomImPluginConfig = new BaseDicomImPluginConfig();
		baseDicomImPluginConfig.setConfigName(IdexxDicomTestConstants.TEST_CONFIG_NAME);
		baseDicomImPluginConfig.setConfigValue(IdexxDicomTestConstants.TEST_CONFIG_VALUE);

		IdexxSendImageJob job = new IdexxSendImageJob();
		job.setJobId(IdexxDicomTestConstants.JOB_ID);
		jobs.add(job);

		sendJob.setJobId(IdexxDicomTestConstants.JOB_ID);
		sendJob.setImageAssetId(IdexxDicomTestConstants.IMAGEASSETID);
		sendImageDtos.add(sendJob);

		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test_update_inprogress_jobs.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 */
	@Test
	public void testUpdate_inprogress_jobs()
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		when(configDao.getConfig(anyString())).thenReturn(baseDicomImPluginConfig);
		objInTest.run();
	}

	/**
	 * Test_build.
	 *
	 * @throws SendRetryCountExceedException
	 *             the send retry count exceed exception
	 * @throws SendImageException
	 *             the send image exception
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	@Test(expected = SendImageException.class)
	public void testBuild()
			throws SendRetryCountExceedException, SendImageException, InterruptedException, IOException {

		when(jobProvider.getPendingJobs(anyString())).thenReturn(jobs);
		doNothing().when(jobProvider).updateJobsToInProgressStatus(jobs);
		when(entityMapper.createPendingJobDto(jobs)).thenReturn(sendImageDtos);
		when(configDao.getConfig(anyString())).thenReturn(baseDicomImPluginConfig);
		PatientDTO patientDTO = new PatientDTO();
		patientDTO.setId(IdexxDicomTestConstants.JOB_ID);
		when(this.presignedUrlProvider.getPresignedUrl(anyString())).thenReturn(anyObject());
		objInTest.process();
	}

}
