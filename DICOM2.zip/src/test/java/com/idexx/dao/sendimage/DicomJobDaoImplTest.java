/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.dao.sendimage.impl.DicomJobDaoImpl;

// TODO: Auto-generated Javadoc
/**
 * Test class from DicomJobDaoImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class DicomJobDaoImplTest {

	/** The obj in test. */
	@InjectMocks
	private DicomJobDao objInTest = new DicomJobDaoImpl();

	/** The entity manager. */
	@Mock
	private EntityManager entityManager;

	/** The query. */
	@Mock
	private Query query;

	/** The result list. */
	List<IdexxSendImageJob> resultList = new ArrayList<IdexxSendImageJob>();

	/** The idexxjob. */
	IdexxSendImageJob idexxjob = new IdexxSendImageJob();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		idexxjob.setJobId(IdexxDicomTestConstants.TESTJOBID);
		idexxjob.setCreatedDateTime(IdexxDicomTestConstants.CREATEDDATETIME);
		idexxjob.setDestinationAETitle(IdexxDicomTestConstants.TESTDESTINATIONAETITLE);
		idexxjob.setDestinationHostName(IdexxDicomTestConstants.DESTINATIONHOSTNAME);
		idexxjob.setDestinationPort(IdexxDicomTestConstants.DESTINATIONPORT);
		idexxjob.setDownloadedIMFilePath(IdexxDicomTestConstants.DOWNLOADEDIMFILEPATH);
		idexxjob.setImageAssetId(IdexxDicomTestConstants.IMAGEASSETID);
		idexxjob.setJobStatus(IdexxDicomTestConstants.JOBSTATUS);
		idexxjob.setJobStatusDescription(IdexxDicomTestConstants.JOBSTATUSDESCRIPTION);
		idexxjob.setRetriesCount(IdexxDicomTestConstants.RETRIESCOUNT);
		idexxjob.setS3ImageUrl(IdexxDicomTestConstants.S3IMAGEURL);
		idexxjob.setScheduleTimestamp(IdexxDicomTestConstants.SCHEDULETIMESTAMP);
		idexxjob.setUpdatedDateTime(IdexxDicomTestConstants.UPDATEDDATETIME);
		idexxjob.getScheduleTimestamp();
		idexxjob.getSendingAETitle();
		resultList.add(idexxjob);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test_get pending jobs.
	 */
	@Test
	public void testGetPendingJobs() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.setMaxResults(1)).thenReturn(query);
		when(query.setLockMode(LockModeType.PESSIMISTIC_WRITE)).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		List<IdexxSendImageJob> originalList = objInTest.getPendingJobs("1");
		verify(entityManager, atLeast(1)).createQuery(anyString());
		assertEquals(originalList, resultList);
	}

	/**
	 * Test_update all_ inprogress_ jobs.
	 */
	@Test
	public void testUpdateAllInprogressJobs() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		objInTest.updateAllInProgressJobs("1");
		verify(entityManager, atLeast(1)).createQuery(anyString());
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_get job_by_ id.
	 */
	@Test
	public void testGetJobById() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(idexxjob);
		objInTest.getJobByJobId(IdexxDicomTestConstants.TESTJOBID);
		verify(entityManager, atLeast(1)).createQuery(anyString());
	}

	/**
	 * Test_update_jobs_to_ inprogress.
	 */
	@Test
	public void testUpdateJobstoInprogress() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		objInTest.updateJobsToInProgressStatus();
		verify(entityManager, atLeast(1)).createQuery(anyString());
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_update_list_of_jobs_to_ inprogress.
	 */
	@Test
	public void testUpdateInprogresslist() {

		objInTest.updateJobsToInProgressStatus(resultList);
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_update_job.
	 */
	@Test
	public void testUpdateJob() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(idexxjob);
		objInTest.updateJob(idexxjob);
		verify(entityManager, atLeast(1)).persist(anyObject());
	}
}
