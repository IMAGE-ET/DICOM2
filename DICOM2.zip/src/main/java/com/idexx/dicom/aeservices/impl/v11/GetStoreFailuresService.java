/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v11;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.v11.StoreFailureServiceValidator;
import com.idexx.dicom.aeservices.v11.GetStoreFailuresServiceIntf;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.util.CommonUtil;

/**
 * The Class GetStoreFailuresService.
 *
 * @author rmalla
 */
@Service("getStoreFailuresServiceV11")
public class GetStoreFailuresService implements GetStoreFailuresServiceIntf {

	/** The validator. */
	@Autowired
	@Qualifier("getStoreFailuresValidatorV11")
	private StoreFailureServiceValidator validator;

	/** The dtos. */
	private List<IdexxFailureLogDTO> dtos;

	/** The failure log dao. */
	@Autowired
	private FailureServiceDao failureLogDAO;

	/** The ae title dao. */
	@Autowired
	private AETitleDao aeTitleDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.aeservices.AEService#performService()
	 */
	@Transactional
	@Override
	public final List<IdexxFailureLogDTO> performService(final IdexxFailureLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		this.validate(dto);
		this.doService(dto);
		return dtos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
	 * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */

	/**
	 * Validate.
	 *
	 * @param dto
	 *            the dto
	 * @return the int
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	protected final int validate(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		IdexxFailureLogParamDTO failureParamDTO = (IdexxFailureLogParamDTO) dto;
		return validator.validate(failureParamDTO);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
	 * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */

	/**
	 * Do service.
	 *
	 * @param dto
	 *            the dto
	 * @return the int
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	protected final int doService(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		List<IdexxDicomServiceFailureLog> failureLogList = null;
		IdexxFailureLogParamDTO iflDto = (IdexxFailureLogParamDTO) dto;
		failureLogList = failureLogDAO.getFailureLog(CommonUtil.convertToDate(iflDto.getStartDate()),
				CommonUtil.convertToDate(iflDto.getEndDate()));
		setDTOList(failureLogList);
		return 1;
	}

	/**
	 * This method set the AETitles to IdexxDicomApplicationEntityDTO list.
	 *
	 * @param failureLogList
	 *            the new DTO list
	 */
	private void setDTOList(final List<IdexxDicomServiceFailureLog> failureLogList) {
		List<AETitle> aeTitles = aeTitleDao.getAllAETitles();
		dtos = new ArrayList<IdexxFailureLogDTO>();
		IdexxFailureLogDTO dto = null;
		Calendar calender = Calendar.getInstance();

		for (IdexxDicomServiceFailureLog failureLog : failureLogList) {
			if (isUnregisteredAeTitle(aeTitles, failureLog)) {
				dto = new IdexxFailureLogDTO();
				dto.setIpAddress(failureLog.getIpAddress());
				dto.setAeTitle(failureLog.getAeTitle());
				dto.setInstituteName(failureLog.getInstituteName());
				dto.setManufacturer(failureLog.getManufacturer());
				dto.setManufacturerModelName(failureLog.getManufacturerModelName());
				dto.setModality(failureLog.getModality());
				dto.setPatientName(failureLog.getPatientName());
				calender.setTime(failureLog.getFailedDateTime());
				dto.setFailedDateTime(CommonUtil.convertDateToUTCString(calender.getTime()));
				String responsiblePersonName = failureLog.getResponsiblePersonName();
				if (StringUtils.isEmpty(responsiblePersonName)) {
					responsiblePersonName = "";
				}
				dto.setResponsiblePersonName(responsiblePersonName);
				String hostName = failureLog.getHostName();
				if (StringUtils.isEmpty(hostName)) {
					hostName = "";
				}
				dto.setHostName(hostName);
				dtos.add(dto);
			}
		}
	}

	/**
	 * Checks if is unregistered ae title.
	 *
	 * @param aeTitles
	 *            the ae titles
	 * @param failureLog
	 *            the failure log
	 * @return true, if is unregistered ae title
	 */
	private boolean isUnregisteredAeTitle(List<AETitle> aeTitles, IdexxDicomServiceFailureLog failureLog) {
		boolean unregistered = true;
		for (AETitle aeTitle : aeTitles) {
			if (aeTitle.getAeTitle().trim().equals(failureLog.getAeTitle().trim())
					&& aeTitle.getInstituteName().trim().equals(failureLog.getInstituteName().trim())) {
				unregistered = false;
			}
		}
		return unregistered;
	}

}
