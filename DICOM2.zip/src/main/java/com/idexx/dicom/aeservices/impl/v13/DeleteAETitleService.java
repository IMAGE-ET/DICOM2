/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>DeleteAETitleService Implementation to delete AETitle Service Jobs</pre>
 * @author smallela
 * @version 1.3
 */

@Service("deleteAETitleServiceV13")
public class DeleteAETitleService extends AbstractAEServiceImpl {
	
	private static final Logger LOG = Logger.getLogger(DeleteAETitleService.class);
	
	@Autowired
    @Qualifier("deleteAETitleValidatorV13")
    private AbstractAETitleValidator validator;
    
    @Autowired
    private AETitleDao aeTitleDao;
    
    /**
     * <pre>Validate apiKey,aeTitle,instituteName of delete AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    @Override
    @Transactional
    public int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }
    
    /**
     * <pre>To provide services of apiKey,aeTitle,instituteName for Delete AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
        
    @Override
    @Transactional
    public int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        
        AETitle aeTitle = null;
        List<AETitle> registeredAEList = null;
        try {
            registeredAEList = aeTitleDao.findAETitle(dto.getAeTitle());
            
            if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                aeTitle = registeredAEList.get(0);
                if (!aeTitle.isIdentifiedByaeTitleOnly()) {
                    registeredAEList = aeTitleDao.findAETitle(dto.getAeTitle(), dto.getInstituteName());
                    if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                        aeTitle = registeredAEList.get(0);
                    }
                }
                
            }
            if (null != aeTitle) {
                
                aeTitleDao.deleteAETitle(aeTitle);
            }
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
        	throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }
        
        return 1;
    }
    
    
}
