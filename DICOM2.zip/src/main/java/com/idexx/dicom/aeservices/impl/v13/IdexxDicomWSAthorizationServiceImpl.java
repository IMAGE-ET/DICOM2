/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.ae.validator.AETitleValidator;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * Class to authorize and validate api key 
 * @author vvanjarana
 * @version 1.3
 */
@Service("idexxDicomWSAthorizationServiceImplV13")
public class IdexxDicomWSAthorizationServiceImpl {
    
    public static final String MISSING_MANDATORY = AETitleValidator.MISSING_MANDATORY;
    public static final String INVALID_API_KEY = "ERR_invalid_api_key";
    
    @Autowired
    private AETitleDao aeTitleDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService#authorize(
     * java.lang.String)
     */
    @Transactional
    public boolean authorize(final String apiKey) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(apiKey)) {
            throw new IdexxDicomAEConfigServiceException(
        	    IdexxDicomWSAthorizationServiceImpl.MISSING_MANDATORY, IdexxDicomWSAthorizationServiceImpl.MISSING_MANDATORY);
        }
        IdexxAPIKey idxApiKey = aeTitleDao.getIdexxAPIKey(apiKey);
        boolean validApiKey = false;
        if (null != idxApiKey) {
            validApiKey = true;
        } else {
            throw new IdexxDicomAEConfigServiceException(
        	    IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY, IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY);
        }
        return validApiKey;
    }
    
}
