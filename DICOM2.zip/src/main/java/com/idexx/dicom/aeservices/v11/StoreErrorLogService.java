package com.idexx.dicom.aeservices.v11;

import java.util.List;

import com.idexx.dicom.services.dto.v11.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

public interface StoreErrorLogService {
	List<IdexxFailureLogDTO> performService(IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
