/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>SetAETitleStatusService Implementation to set AETitle Service Jobs</pre>
 * @author smallela
 * @version 1.3
 */

@Service("setAETitleStatusServiceV13")
public class SetAETitleStatusService extends AbstractAEServiceImpl {
    
	private static final Logger LOG = Logger.getLogger(SetAETitleStatusService.class);
	
	@Autowired
    @Qualifier("deleteAETitleValidatorV13")
    private AbstractAETitleValidator validator;
    
    @Autowired
    private AETitleDao aeTitleDao;
    
    /**
     * <pre>Validate apiKey,aeTitle,instituteName of set AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    @Override
    @Transactional
    public int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }
    
    /**
     * <pre>To provide services of apiKey,aeTitle,instituteName for Set AETitleStatus service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    @Override
    @Transactional
    public int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        
        SetEnabledAETitleDTO setEnabledAETitleDTO = (SetEnabledAETitleDTO) dto;
        
        AETitle aeTitle = null;
        List<AETitle> registeredAEList = null;
        try {
            registeredAEList = aeTitleDao.findAETitle(setEnabledAETitleDTO.getAeTitle());
            
            if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                aeTitle = registeredAEList.get(0);
                if (!aeTitle.isIdentifiedByaeTitleOnly()) {
                    aeTitle = null;
                    registeredAEList = aeTitleDao.findAETitle(setEnabledAETitleDTO.getAeTitle(), setEnabledAETitleDTO.getInstituteName());
                    if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                        aeTitle = registeredAEList.get(0);
                    }
                }
                
            }
            if (null != aeTitle) {
                aeTitle.setEnabled(setEnabledAETitleDTO.isEnabled());
                aeTitleDao.updateAETitle(aeTitle);
            }
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
        	throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }
        return 1;
    }
    
    
}
