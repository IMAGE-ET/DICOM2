/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>AbstractAEService Implementation to provide services for AETitle web Service</pre>
 * @author smallela
 * @version 1.3
 */

@Service("readAETitleServiceV13")
public abstract class AbstractAEServiceImpl {
    
	 String GENERAL_DB_FAILURE = "ERR_general_db_fail";
	 String NO_RECORD_FOUND = "ERR_no_record_found";
	
	 @Autowired
    private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

     
    /**
     * <pre>Implementation to perform apiKey,aeTitle,instituteName for AETitles web services</pre>
     * @param dto
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    @Transactional
    public void performService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        boolean authorized = false;
        authorized = isAPIKeyValid(dto.getApiKey());
        if (authorized) {
            this.validate(dto);
            this.doService(dto);
        }

    }
    /**
     * <pre>Validate apiKey,aeTitle,instituteName of AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    protected abstract int validate(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    /**
     * <pre>To provide services of apiKey,aeTitle,instituteName for AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    protected abstract int doService(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    /**
     * <pre>Implementation to provide send response job</pre>
     * @return Object
     * 
     */
    public Object sendResponse() {
        return new Integer(0);
    }
    /**
     * <pre>Implementation to provide services for AETitles web services</pre>
     * @param apiKey
     * @return boolean
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    public boolean isAPIKeyValid(final String apiKey) throws IdexxDicomAEConfigServiceException {
        return idexxDicomWsAuthorizeService.authorize(apiKey);
    }

}
