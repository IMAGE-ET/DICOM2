/**
 * Implementation to cancel the Send Image Service Jobs.
 */
package com.idexx.dicom.aeservices.impl.v13;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.impl.v13.CancelSendJobServiceValidatorImpl;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.CancelSendJobParamDTO;


/**
 * <pre>Implementation to cancel the Send Image Service Jobs.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@Service("cancelSendJobServiceImplV13")
public class CancelSendJobServiceImpl  {

	private static final Logger LOG = Logger.getLogger(CancelSendJobServiceImpl.class);
	
	@Autowired
    @Qualifier("cancelSendJobServiceValidatorV13")
    private CancelSendJobServiceValidatorImpl validator;

    @Autowired
    private IdexxSendImageJobDao cancelSendImageJobDao;
	
	/**
	 * 
	 * <pre>Implementation to cancel the Send Image Service Jobs.</pre>
	 * @param dto
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	@Transactional
	public String performService(CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
		  this.validate(dto);
          String message = this.doService(dto);
          return message;
      }
	
	
	 /**
	  * Validate Job Id of send image service Job.
	  * @param dto
	  * @return
	  * @throws IdexxDicomAEConfigServiceException
	  */
	 protected  int validate(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
	        return validator.validate(dto);
	    }

	 
	 /**
	  * Process send image service Job cancellation.
	  * @param dto
	  * @return
	  * @throws IdexxDicomAEConfigServiceException
	  */
	 protected  String doService(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
	        String message = null;
	        try {
	            List<String> jobIdList = new ArrayList<String>();
	            jobIdList.add(dto.getJobId());
	            List<IdexxSendImageJob> jobList = cancelSendImageJobDao.getJob(jobIdList);
	            if (!jobList.isEmpty()) {
	                IdexxSendImageJob idexxCancelJob = jobList.get(0);
	                idexxCancelJob.setJobStatus(SendImageJobConstants.JOB_STATUS_CANCEL);
	                message = cancelSendImageJobDao.cancelSendJob(idexxCancelJob);
	            } else {
	                message = "JobId " + dto.getJobId() + " does not exists.";
	            }
	        } catch (Exception exp) {
	            LOG.error(exp.getLocalizedMessage(), exp);
	            throw new IdexxDicomAEConfigDbException(exp);
	        }
	        return message;
	    }
}
