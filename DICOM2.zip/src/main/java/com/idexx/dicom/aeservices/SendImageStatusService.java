/**
 * 
 */
package com.idexx.dicom.aeservices;

import java.util.List;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface SendImageStatusService {
    List<IdexxSendImageJobStatusDTO> performService(SendImageStatusParamDTO dto)
            throws IdexxDicomAEConfigServiceException;
}
