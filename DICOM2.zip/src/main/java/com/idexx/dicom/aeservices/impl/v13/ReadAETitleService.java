/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v13.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>ReadAETitleService Implementation to read AETitle Service Jobs</pre>
 * @author smallela
 * @version 1.3
 */

@Service("readAETitleServiceV13")
public class ReadAETitleService extends AbstractAEServiceImpl {
	
	private static final Logger LOG = Logger.getLogger(ReadAETitleService.class);
		
    private static final int AE_TITLE_CASE = 1;
    private static final int AE_INSTITUTE_NAME_CASE = 2;
    private static final int AE_SAP_ID_CASE = 4;
    @Autowired
    @Qualifier("readAETitleValidatorV13")
    private AbstractAETitleValidator validator;
    
    private List<IdexxDicomApplicationEntityDTO> dtos;

    @Autowired
    private AETitleDao aeTitleDao;

    /**
     * <pre>Validate apiKey,aeTitle,instituteName of Read AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    @Override
    protected int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        ReadAETitleDTO radDTO = (ReadAETitleDTO) dto;
        return validator.validate(radDTO);
    }

    /**
     * <pre>To provide services of apiKey,aeTitle,instituteName for Read AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */    
    @Override
    protected int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        // Cases
        final int aeAndInstituteName = 3;
        final int onlySap = 4;
        final int aeAndSap = 5;
        final int aeSapIn = 6;
        List<AETitle> aeTitleList = null;
        ReadAETitleDTO readAEDTO = (ReadAETitleDTO) dto;
        int queryCase = getQueryCase(readAEDTO);
        try {
            switch (queryCase) {
                case 1:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle());
                    break;
                case aeAndInstituteName:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle(), readAEDTO.getInstituteName());
                    break;
                case onlySap:
                    aeTitleList = aeTitleDao.findAETitleBySapId(readAEDTO.getSapId());
                    break;
                case aeAndSap:
                    aeTitleList = aeTitleDao.findAETitleByAETitleAndSapId(readAEDTO.getAeTitle(), readAEDTO.getSapId());
                    break;
                case aeSapIn:
                    aeTitleList = aeTitleDao.findAETitleBySapIdAndInstituteName(readAEDTO.getSapId(),
                            readAEDTO.getInstituteName());
                    break;

                default:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle(), readAEDTO.getInstituteName(),
                            readAEDTO.getSapId());
                    break;
            }
            if ((null == aeTitleList) || (aeTitleList.isEmpty())) {
                throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND, NO_RECORD_FOUND);
            }
            setDTOList(aeTitleList);

        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
        	throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }

        return 1;
    }

    /**
     * This method set the AETitles to IdexxDicomApplicationEntityDTO list
     * 
     * @param aeTitleList
     */
    private void setDTOList(final List<AETitle> aeTitleList) {
        dtos = new ArrayList<IdexxDicomApplicationEntityDTO>();
        IdexxDicomApplicationEntityDTO dto=null;
        for (AETitle aeTitle : aeTitleList) {
            dto = new IdexxDicomApplicationEntityDTO();
            dto.setAeTitle(aeTitle.getAeTitle());
            dto.setApiKey(aeTitle.getApiKey());
            dto.setInstituteName(aeTitle.getInstituteName());
            dto.setIdentifiedByAeTitleOnly(aeTitle.isIdentifiedByaeTitleOnly());
            dto.setSapId(aeTitle.getSapId());
            dto.setModalityTypeCode(aeTitle.getModalityTypeCode());
            if (aeTitle.getLastAccessedDateTime() != null) {
                dto.setLastAccessed(aeTitle.getLastAccessedDateTime());
            }
            dto.setCreatedDateTime(aeTitle.getCreatedDateTime());
            dto.setEnabled(aeTitle.isEnabled());
            dtos.add(dto);
        }
    }

    /**
     * This method checks aeTitle,instituteName,SapId are empty or not
     * @param dto
     * @return int
     */
    protected int getQueryCase(final ReadAETitleDTO dto) {
        int caseNumber = 0;
        if (!StringUtils.isEmpty(dto.getAeTitle())) {
            caseNumber += AE_TITLE_CASE;
        }
        if (!StringUtils.isEmpty(dto.getInstituteName())) {
            caseNumber += AE_INSTITUTE_NAME_CASE;
        }
        if (!StringUtils.isEmpty(dto.getSapId())) {
            caseNumber += AE_SAP_ID_CASE;
        }
        return caseNumber;
    }

    /**
     * <pre>Implementation to provide send response job</pre>
     * @see com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#sendResponse(com
     * .idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
     * @return Object
     */
    
    @Override
    public Object sendResponse() {

        return dtos;
    }

}
