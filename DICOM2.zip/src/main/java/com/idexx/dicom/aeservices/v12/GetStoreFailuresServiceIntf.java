/**
 * 
 */
package com.idexx.dicom.aeservices.v12;

import java.util.List;

import com.idexx.dicom.services.dto.v12.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v12.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface GetStoreFailuresServiceIntf {
    List<IdexxFailureLogDTO> performService(IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
