/**
 * 
 */
package com.idexx.dicom.aeservices.v11;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;

/**
 * @author anarayana
 * 
 */
public interface CancelSendJobService {
    String performService(CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
