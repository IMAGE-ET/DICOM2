package com.idexx.dicom.sendimage.impl;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.imageio.codec.Decompressor;
import org.dcm4che3.io.DicomInputStream;
import org.dcm4che3.io.DicomInputStream.IncludeBulkData;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.DataWriter;
import org.dcm4che3.net.DataWriterAdapter;
import org.dcm4che3.net.IncompatibleConnectionException;
import org.dcm4che3.net.InputStreamDataWriter;
import org.dcm4che3.net.Priority;
import org.dcm4che3.net.Status;
import org.dcm4che3.net.pdu.AAssociateRQ;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicCStoreSCU;
import org.dcm4che3.net.service.BasicCStoreSCUResp;
import org.dcm4che3.net.service.InstanceLocator;
import org.dcm4che3.util.SafeClose;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.dicom.util.ConnectionUtil;

/**
 * SendImage DICOM service to send image from one DICOM modality to another
 * modality
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service("sendImage")
public final class SendImageImpl implements SendImage {
	
	private static final Logger LOG = Logger.getLogger(SendImageImpl.class);

	private ApplicationEntity ae = null;
	private Connection conn = null;
	
	@Autowired
	private ConnectionUtil connectionUtil;

	public void init(ApplicationEntity ae, Connection conn) {
		this.ae = ae;
		this.conn = conn;
	}

	/**
	 * Send Image to the Destination AE
	 * 
	 * @param SendImagePendingJobDTO
	 *            Pending Job
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 * @throws IncompatibleConnectionException
	 */
	@Override
	public void sendImage(final SendImagePendingJobDTO dto)
			throws SendImageException, InterruptedException, IOException {
		LOG.info("SendImage Job Started: ");
		String destinationAET = dto.getDestinationAETitle();
		String destinationHost = dto.getDestinationHostName();
		int destinationPort = dto.getDestinationPort();
		String filePath = dto.getDownloadedIMFilePath();
		File dcmFile = new File(filePath);
		LOG.info("Send Image File Path: " + filePath);

		Connection remote = new Connection();
		remote.setHostname(destinationHost);
		remote.setPort(destinationPort);
		remote.setTlsCipherSuites(conn.getTlsCipherSuites());
		remote.setTlsProtocols(conn.getTlsProtocols());
		connectionUtil.addTimeouts(remote);

		AAssociateRQ rq = new AAssociateRQ();
		rq.setCalledAET(destinationAET);
		rq.setCallingAET(dto.getSendingAETitle());

		List<InstanceLocator> instances = new ArrayList<InstanceLocator>(1);

		try (DicomInputStream in = new DicomInputStream(dcmFile)) {
			LOG.info("checking the input file is supported by destinationAET" + in.toString());
			
			in.setIncludeBulkData(IncludeBulkData.NO);
            Attributes fmi = in.readFileMetaInformation();
            Attributes ds = in.readDataset(-1, Tag.PixelData);
            if (fmi == null || !fmi.containsValue(Tag.TransferSyntaxUID)
                    || !fmi.containsValue(Tag.MediaStorageSOPClassUID)
                    || !fmi.containsValue(Tag.MediaStorageSOPInstanceUID)) {
                fmi = ds.createFileMetaInformation(in.getTransferSyntax());
            }
            String cuid = fmi.getString(Tag.MediaStorageSOPClassUID);
            String iuid = fmi.getString(Tag.MediaStorageSOPInstanceUID);
            String ts = fmi.getString(Tag.TransferSyntaxUID);
            if (cuid == null || iuid == null) {
    			throw new SendImageException("cuid or iuid missing "
    					+ destinationAET + " - skipping file: " + dcmFile.getAbsolutePath());
            }
            instances.add(new InstanceLocator(cuid, iuid, ts, dcmFile.toURI().toString()));
            
            if (!rq.containsPresentationContextFor(cuid, ts)) {
 	            if (!rq.containsPresentationContextFor(cuid)) {
	                if (!ts.equals(UID.ExplicitVRLittleEndian))
	                    rq.addPresentationContext(new PresentationContext(rq
	                            .getNumberOfPresentationContexts() * 2 + 1, cuid,
	                            UID.ExplicitVRLittleEndian));
	                if (!ts.equals(UID.ImplicitVRLittleEndian))
	                    rq.addPresentationContext(new PresentationContext(rq
	                            .getNumberOfPresentationContexts() * 2 + 1, cuid,
	                            UID.ImplicitVRLittleEndian));
	            }
	            rq.addPresentationContext(new PresentationContext(rq
	                    .getNumberOfPresentationContexts() * 2 + 1, cuid, ts));
            }
		} catch (IOException exp) {
			LOG.warn("exception while reading file: "+dcmFile.getAbsolutePath(), exp);
			throw new SendImageException("Failed to parse dicom file for "
					+ destinationAET + " - skipping file: " + dcmFile.getAbsolutePath());
		}

		BasicCStoreSCU<InstanceLocator> basicCStoreSCU = new BasicCStoreSCU<InstanceLocator>(){
		    protected String selectTransferSyntaxFor(Association storeas, InstanceLocator inst)
		            throws Exception {
		        Set<String> tss = storeas.getTransferSyntaxesFor(inst.cuid);
		        if (tss.contains(inst.tsuid))
		            return inst.tsuid;

		        if (tss.contains(UID.ExplicitVRLittleEndian))
		            return UID.ExplicitVRLittleEndian;

		        return UID.ImplicitVRLittleEndian;
		    }

		    protected DataWriter createDataWriter(InstanceLocator inst, String ts)
		            throws Exception {
		    	
            	DicomInputStream in = new DicomInputStream(inst.getFile());
		    	if (ts.equals(inst.tsuid)) {
	    		    in.readFileMetaInformation();
    		        return new InputStreamDataWriter(in);
	            } else {
	                try {
	                    in.setIncludeBulkData(IncludeBulkData.URI);
	                    Attributes data = in.readDataset(-1, -1);
	                    if (!ts.equals(inst.tsuid)) {
	                        Decompressor.decompress(data, inst.tsuid);
	                    }
	                    return new DataWriterAdapter(data);
	                } finally {
	                    SafeClose.close(in);
	                }
	            }
		    }
		};
		
		Association as = null;
		BasicCStoreSCUResp resp = null;
		try {
			as = ae.connect(remote, rq);
			resp = basicCStoreSCU.cstore(instances, as, Priority.NORMAL);
		} catch (Exception exc) {
			throw new SendImageException("unable to send image: " + exc.getMessage());
		} finally {
			try {
				if (as!=null) {
					as.release();
				}
			} catch(IOException e) {
				LOG.error("Unable to release association", e);	
			}
		}
		if (resp!=null && resp.getStatus() != Status.Success) {
			// DICOM send failed
			throw new SendImageException("Status: "+Integer.toHexString(resp.getStatus())+"H");
		}
	}

}
