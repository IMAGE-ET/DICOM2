package com.idexx.dicom.sendimage;

import java.util.List;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;

/**
 * @author vkandagatla
 * 
 */
public interface SendImageJobProvider {
    /**
     * @return All pending jobs which are available for processing next
     *         iteration for scheduler These jobs retry count should be greater
     *         than zero
     */
    List<IdexxSendImageJob> getPendingJobs(String jobCount);
    
    /**
     *  Updated all Jobs whose status In Progress to PENDING
     */
    void updateInProgressJobs(String oldRecordsCount);
    
    /**
     * Updating all Pending jobs to In Progress 
     */
    void updateJobsToInProgressStatus(List<IdexxSendImageJob> jobs);
}
