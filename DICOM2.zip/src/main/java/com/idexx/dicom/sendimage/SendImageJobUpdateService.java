/**
 * Updates the Send Image Job Status
 */
package com.idexx.dicom.sendimage;

/**
 * @author vkandagatla
 * 
 */
public interface SendImageJobUpdateService {
    
    /**
     * @param jobId
     * @param description
     *            Update status to Pending of given Job ID Also updates the
     *            description for job
     */
    void updateJobStatusToPending(String jobId, String description);
    
    /**
     * @param jobId    
     *    Update status to Failed of given Job ID 
     *    
     */
    void updateJobStatusToFailed(String jobId);
    
    /**
     * @param jobId
     * @param description
     *            Update status to InProgress of given Job ID Also updates the
     *            description for job
     */
    void updateJobStatusToInProgress(String jobId, String description);
    
    /**
     * @param jobId
     * @param description
     *            Update status to SUCCESS of given Job ID Also updates the
     *            description as null for job
     */
    void updateJobStatusToSuccess(String jobId);
    
    /**
     * @param jobId
     * @param filePath
     *            The path of the file will be updated, which was successfully
     *            downloaded from S3
     */
    void updateImageFilePath(String jobId, String filePath);
    
    /**
     * @param jobId
     * @param url
     *            The Image S3 URL will be updated, Which was recieved from
     *            ImageManger web service
     */
    void updateImageUrl(String jobId, String url);
    
    /**
     * @param jobId
     * Updates retry count for a job
     */
    void increaseRetryCount(String jobId);
}
