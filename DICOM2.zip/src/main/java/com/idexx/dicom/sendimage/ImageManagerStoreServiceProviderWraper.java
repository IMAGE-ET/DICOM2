/**
 * Wraper interface for ImageManagerStoreServiceProvider
 */
package com.idexx.dicom.sendimage;

import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;

/**
 * @author vkandagatla
 *
 */
public interface ImageManagerStoreServiceProviderWraper {
    IDEXXImageManagerServices getService();
}
