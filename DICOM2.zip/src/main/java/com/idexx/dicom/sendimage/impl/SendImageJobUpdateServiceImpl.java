/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;

/**
 * @author vkandagatla
 * 
 */
@Service
public class SendImageJobUpdateServiceImpl implements SendImageJobUpdateService {
    @Autowired
    private DicomJobDao dicmJobDao;
    
    /*
     *  Constructor
     */
    private void setJobStatus(final String jobId, final String status, final String description) {
        IdexxSendImageJob job = this.dicmJobDao.getJobByJobId(jobId);
        job.setJobStatus(status);
        job.setJobStatusDescription(description);
        dicmJobDao.updateJob(job);
    }
    
    /*
     *  Overloaded Constructor
     */
    private void setJobStatus(final String jobId, final String status) {
        IdexxSendImageJob job = this.dicmJobDao.getJobByJobId(jobId);
        job.setJobStatus(status);
        dicmJobDao.updateJob(job);
    }
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.SendImageJobUpdateService#updateJobStatusToPending
     * (java.lang.String, java.lang.String)
     */
    @Override
    @Transactional
    public final void updateJobStatusToPending(final String jobId, final String description) {
        setJobStatus(jobId, SendImageJobConstants.JOB_STATUS_PENDING, description);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.SendImageJobUpdateService#updateJobStatusToFailed
     * (java.lang.String, java.lang.String)
     */
    @Override
    @Transactional
    public final void updateJobStatusToFailed(final String jobId) {
        this.setJobStatus(jobId, SendImageJobConstants.JOB_STATUS_FAILED);
        
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.sendimage.SendImageJobUpdateService#
     * updateJobStatusToInProgress(java.lang.String, java.lang.String)
     */
    @Override
    @Transactional
    public final void updateJobStatusToInProgress(final String jobId, final String description) {
        this.setJobStatus(jobId, SendImageJobConstants.JOB_STATUS_PROGRESS, description);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.SendImageJobUpdateService#updateJobStatusToSuccess
     * (java.lang.String)
     */
    @Override
    @Transactional
    public final void updateJobStatusToSuccess(final String jobId) {
        this.setJobStatus(jobId, SendImageJobConstants.JOB_STATUS_SUCCESS, "");
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.SendImageJobUpdateService#updateImageFilePath
     * (java.lang.String, java.lang.String)
     */
    @Override
    @Transactional
    public final void updateImageFilePath(final String jobId, final String filePath) {
        IdexxSendImageJob job = this.dicmJobDao.getJobByJobId(jobId);
        job.setDownloadedIMFilePath(filePath);
        this.dicmJobDao.updateJob(job);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.SendImageJobUpdateService#updateImageUrl(java
     * .lang.String, java.lang.String)
     */
    @Override
    @Transactional
    public final void updateImageUrl(final String jobId, final String url) {
        IdexxSendImageJob job = this.dicmJobDao.getJobByJobId(jobId);
        job.setS3ImageUrl(url);
        this.dicmJobDao.updateJob(job);
    }

    /* (non-Javadoc)
     * @see com.idexx.dicom.sendimage.SendImageJobUpdateService#increaseRetryCount(java.lang.String)
     */
    @Override
    @Transactional
    public final void increaseRetryCount(final String jobId) {
        IdexxSendImageJob job = this.dicmJobDao.getJobByJobId(jobId);
        job.setRetriesCount(job.getRetriesCount() + 1);
    }
    
}
