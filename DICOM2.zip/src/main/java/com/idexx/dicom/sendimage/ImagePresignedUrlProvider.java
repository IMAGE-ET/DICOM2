/**
 * 
 */
package com.idexx.dicom.sendimage;

import com.idexx.dicom.sendimage.impl.SendImageException;
import com.idexx.imaging.imagemanager.soap.PatientDTO;


/**
 * @author vkandagatla
 *
 */
public interface ImagePresignedUrlProvider {
    PatientDTO getPresignedUrl(String imageAssetId) throws SendImageException;
}
