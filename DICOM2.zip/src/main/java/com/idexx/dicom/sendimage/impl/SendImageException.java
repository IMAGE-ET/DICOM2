package com.idexx.dicom.sendimage.impl;

public class SendImageException extends Exception {
    
    /**
     * Default Searial Version
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * Custom exception for handling Send Image error conditions
     * 
     * @param message
     */
    public SendImageException(final String message) {
        super(message);
    }

    /**
     * @param message
     * @param exceptoin
     */
    public SendImageException(final String message, final Throwable exceptoin) {
        super(message, exceptoin);
    }
    
    
}
