/**
 * 
 */
package com.idexx.dicom.sendimage;

/**
 * @author vkandagatla
 * 
 */
public final class SendImageJobConstants {

    public static final String JOB_STATUS_CANCEL = "CANCEL";
    public static final String JOB_STATUS_PENDING = "PENDING";
    public static final String JOB_STATUS_FAILED = "FAILED";
    public static final String JOB_STATUS_PROGRESS = "IN PROGRESS";
    public static final String JOB_STATUS_SUCCESS = "SUCCESS";
    public static final String JOB_STATUS_DESC_PENDING_RETRY = "Pending for Retry";
    public static final String JOB_STATUS_DESC_PROGRESS = "PROCESSING";
    public static final String JOB_RETRY_COUNT_CONFIG_VALUE = "sendRetriesCount";
    public static final int DEFAULT_JOB_RETRY_COUNT = 5;
    public static final String JOB_STATUS_DESC_RETRY_COUNT_EXCEED = "RETRY COUNT EXCEEDED";
    public static final int DEFAULT_QUARTZ_THREAD_COUNT = 10;
    public static final String QUARTZ_THREAD_COUNT_CONFIG_NAME = "quartzThreadCount";
    public static final String SEND_IMAGE_SCHEDULER_STATE_CONFIG_NAME = "SEND_IMAGE_STATE";
    public static final String SEND_IMAGE_SEND_IMAGE_STATE_SCHEDULED = "SCHEDULE";
    public static final String SEND_IMAGE_SEND_IMAGE_STATE_STOP = "STOP";
    public static final String SEND_IMAGE_SCHEDULER_SLEEP_TIME_CONFIG_VALUE = "quartzSleepTime";
    public static final int DEFAULT_SEND_IMAGE_SCHEDULER_SLEEP_TIME = 60000;
    public static final String SEND_IMAGE_CRON_EXPRESSION = "SEND_IMAGE_CRON_EXPRESSION";
    public static final String DEFAULT_SEND_IMAGE_CRON_EXPRESSION = "30 * * * *";
    public static final int CONNECTION_TIME_OUT = 6000;
    public static final int STORE_CONNECTION_TIME_OUT = 60000;
    public static final int HTTP_RESPONSE_FAILED_STATUS_CODE = 200;
    public static final int FILE_READ_BUFFER_SIZE = 4096;
    public static final int SEND_IMAGE_JOB_PAUSE_TIME = 1000;
    public static final String IMAGE_MGR_CONFIG_NAME = "imageManagerURL";
    public static final String DEFAULT_IMG_MGR_URL = 
            "http://aws-imgmgr-tc-qa01.imgmgr.idexxi.com:8080/AssetManagerWar/soap/img-mgr-api-1.1";
    public static final String IMG_MGR_API_KEY_CONFIG_VALUE = "apiKey";
    public static final String DEFAULT_IMG_MGR_API_KEY = "4KWZKF914D15UOE759AM92131LCG5U712RFH05481IIO3E7H69406K29Q4DQAXK2";
    public static final String DEFAULT_SCHEDULER_RUN_HOST = "aws-dico-jboss-qa01-01.dicom.idexxi.com";
    public static final String SCHEDULER_RUN_HOST_CONFIG_NAME = "SCHEDULER_RUN_HOST_NAME";
    public static final String SEND_IMAGE_BASE_DIR_CONFIG_NAME = "SEND_IMAGE_BASE_DIR";
    public static final String SEND_IMAGE_DEFAULT_BASE_DIR = "dicom-images";
    public static final String IDEXX_DICOM_PREFIX = "1.2.826.0.1.3680043.2.950";
    public static final String SIMPLE_DATE_FORMAT = "yyyyMMddHHmmssSSS";   
    public static final String CREATE_PATIENT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String PATIENT_DOB_FORMAT = "yyyy-MM-dd";

    
    public static final String SEND_IMAGE_COUNT_PROCESS = "SEND_IMAGE_COUNT";
    public static final String SEND_IMAGE_INPROGRESS = "SEND_IMAGE_PATCH_INTERVAL";
    
    public static final String CLEAN_TEMP_CRON_EXPRESSION = "CLEAN_TEMP_CRON_EXPRESSION";
    public static final String DEFAULT_CLEAN_TEMP_CRON_EXPRESSION = "0 0 12 1/1 * ?";
    
    private SendImageJobConstants() {
    }

}
