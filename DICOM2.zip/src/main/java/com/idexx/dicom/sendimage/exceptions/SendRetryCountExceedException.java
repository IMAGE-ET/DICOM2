/**
 * 
 */
package com.idexx.dicom.sendimage.exceptions;

/**
 * @author vkandagatla
 *
 */
public class SendRetryCountExceedException extends Exception {
    
    /**
     * 
     */
    private static final long serialVersionUID = -1839655502632443079L;
    
    /**
     * @param message
     */
    public SendRetryCountExceedException(final String message) {
        super(message);
    }
    
}
