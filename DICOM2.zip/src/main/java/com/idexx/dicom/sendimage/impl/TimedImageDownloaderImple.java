/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.util.CommonUtil;

/**
 * @author vkandagatla
 * 
 */
@Service
public class TimedImageDownloaderImple implements TimedImageDownloader {

	private static final Logger LOG = Logger.getLogger(TimedImageDownloaderImple.class);
	
    /**
     * Default Constructor
     */
    public TimedImageDownloaderImple() {
    }

    private String getFileNameExtension(final String extension) {
        return "." + CommonUtil.getFileNameExtension(extension, IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.TimedImageDownloader#downloadImage(java.lang
     * .String)
     */
    @Override
    public final File downloadImage(final String imageUrl, final String fileNameExtension, final String baseDir)
            throws SendImageException {
        DefaultHttpClient httpClient = null;
        ByteArrayOutputStream byteOutStream = null;
        FileOutputStream outStream = null;
        BufferedInputStream bis = null;
        File downLoadFile = null;
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmssS");
        java.util.Date date = new java.util.Date();
        String fileName = IdexxDicomServiceConstants.DOWNLOAD_FILE_PREFIX + sDateFormat.format(date)                
                + getFileNameExtension(fileNameExtension);
        try {
            String dir = System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + "/" + IdexxDicomServiceConstants.DOWNLOADED_IMAGES_DIR;
            LOG.info("SendImage downloaded to the temp folder: " + dir);
            CommonUtil.createDir(dir);

            downLoadFile = CommonUtil.createFile(dir, fileName);

            outStream = new FileOutputStream(downLoadFile);
            httpClient = new DefaultHttpClient();
            HttpParams params = httpClient.getParams();
            HttpConnectionParams.setConnectionTimeout(params, SendImageJobConstants.CONNECTION_TIME_OUT);
            HttpConnectionParams.setSoTimeout(params, SendImageJobConstants.CONNECTION_TIME_OUT);
            HttpGet getRequest = new HttpGet(imageUrl);
            HttpResponse response = httpClient.execute(getRequest);

            if (response.getStatusLine().getStatusCode() != SendImageJobConstants.HTTP_RESPONSE_FAILED_STATUS_CODE) {
                throw new SendImageException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
            }

            byteOutStream = new ByteArrayOutputStream();
            bis = new BufferedInputStream(response.getEntity().getContent());

            byte[] bytes = new byte[SendImageJobConstants.FILE_READ_BUFFER_SIZE];
            int bytesRead = 0;

            while ((bytesRead = bis.read(bytes, 0, SendImageJobConstants.FILE_READ_BUFFER_SIZE)) != -1) {
                byteOutStream.write(bytes, 0, bytesRead);
            }
            byteOutStream.writeTo(outStream);
            byteOutStream.flush();

        } catch (ClientProtocolException e) {
            LOG.error(e.getLocalizedMessage(), e);
            throw new SendImageException(e.getLocalizedMessage(), e);

        } catch (IOException e) {
            LOG.error(e.getLocalizedMessage(), e);
            throw new SendImageException(e.getLocalizedMessage(), e);
        } finally {
            closeObjects(httpClient, byteOutStream, outStream, bis);

        }
        return downLoadFile;
    }

	/**
	 * <pre>Add description for the method</pre>
	 * @param httpClient
	 * @param byteOutStream
	 * @param outStream
	 * @param bis
	 * 
	 */
	private void closeObjects(DefaultHttpClient httpClient, ByteArrayOutputStream byteOutStream,
			FileOutputStream outStream, BufferedInputStream bis) {
		try {
		    if (httpClient != null) {
		        httpClient.getConnectionManager().shutdown();
		    }
		} catch (Exception ex) {
		    LOG.error(ex.getLocalizedMessage(), ex);
		}
		try {
		    if (bis != null) {
		        bis.close();
		    }
		} catch (Exception ex) {
		    LOG.error(ex.getLocalizedMessage(), ex);
		}
		try {
		    if (byteOutStream != null) {
		        byteOutStream.close();
		    }

		} catch (Exception ex) {
		    LOG.error(ex.getLocalizedMessage(), ex);
		}
		try {
		    if (outStream != null) {
		        outStream.close();
		    }
		} catch (Exception ex) {
		    LOG.error(ex.getLocalizedMessage(), ex);
		}
	}

}
