/**
 * Thread Controller should get the Number of threads runnable from DB Config.
 * This should invoke only the fixed number for threads
 * All other Runnable will be in queue
 */
package com.idexx.dicom.sendimage;


/**
 * @author vkandagatla
 * 
 */
public interface ThreadController {
    /**
     * @return
     */
    boolean isThreadAvailable();
    
    /**
     * @param runner
     */
    void start();
}
