/**
 * Wraper for S# Image DOwnloader, which handles timeout
 */
package com.idexx.dicom.sendimage;

import java.io.File;

import com.idexx.dicom.sendimage.impl.SendImageException;

/**
 * @author vkandagatla
 * 
 */
public interface TimedImageDownloader {
    File downloadImage(String s3Url, String fileNameExtension, String baseDir) throws SendImageException;
}
