/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public class StudyDateExtractor extends AbstractExtractor {

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeExtractorFromDicomElement#
     * exractAtribute(org.dcm4che.data.Dataset)
     */
    @Override
    public final String exractAtribute(final Attributes dataset) {
        String value1 = this.getTagValueAsString(Tag.StudyDate, dataset);

        String value2 = this.getTagValueAsString(Tag.StudyTime, dataset);
        
        if (value1 != null && "00000000".equals(value1.trim())) {
            return null;
        }
        if ((value1 != null && !value1.trim().equals("")) && (value2 == null || "".equals(value2.trim()))) {
            value2 = "000000";
        }
        return value1 + " " + value2;
    }

    /**
     * @param mapping
     */
    public StudyDateExtractor(final List<DicomImageManagerMapping> mapping) {
        super(mapping);
    }

}
