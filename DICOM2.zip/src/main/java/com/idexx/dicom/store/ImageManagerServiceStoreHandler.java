/**
 * Responsible to call ImageManager Store Service
 */
package com.idexx.dicom.store;

import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.UploadImageDTO;

/**
 * @author vkandagatla
 * 
 */
public interface ImageManagerServiceStoreHandler {
    /**
     * @param dto
     * @return
     * @throws IdexxServiceException_Exception
     */
    String storeImgMetaData(StoreImageMetaDataDTO dto) throws IdexxServiceException_Exception;

    /**
     * @param dto
     * @return
     * @throws IdexxServiceException_Exception
     */
    String storeUploadImg(UploadImageDTO dto) throws IdexxServiceException_Exception;
}
