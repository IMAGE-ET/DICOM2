/**
 * Extract all of the tags required for the ImageManager
 */
package com.idexx.dicom.store;

import java.util.Map;

import org.dcm4che3.data.Attributes;

/**
 * @author vkandagatla
 * 
 */
public interface DicomDcmElementExtractorForImagerManager {
    /**
     * @param dataset
     * @return
     */
    Map<String, String> extractDcmElements(Attributes dataset);
}
