/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.store;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * <pre>Description of the class</pre>
 * @author vvanjarana
 * @version 1.3
 */
public class ExtractorFactory {
    private static ExtractorFactory factory;

    public static ExtractorFactory createInstance() {
        if (null == factory) {
            factory = new ExtractorFactory();
        }
        return factory;
    }

    private ExtractorFactory() {
        super();
    }

    /**
     * @return
     */
    private Map<String, ImageManagerAttributeExtractorFromDicomElement> getMappingTagAttributes(
            final List<DicomImageManagerMapping> imFieldMap) {
        Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributesMap 
        = new HashMap<String, ImageManagerAttributeExtractorFromDicomElement>();

        tagAttributesMap.put("StudyDTO.studyDate", new StudyDateExtractor(imFieldMap));

        tagAttributesMap.put("aquisitionTimestamp1", new AquisitionDateExtractor(imFieldMap));

        tagAttributesMap.put("dateCaptured", new DateCapturedExtractor(imFieldMap));

        tagAttributesMap.put("aquisitionTimestamp", new AquisitionTimestampExtractor(imFieldMap,
                new DateTimeStampProvider()));
        tagAttributesMap.put("PatientDTO.dob", new PatientDobExtractor(imFieldMap));
        tagAttributesMap.put("ImageDTO.imageTitle", new ImageTitleExtractor(imFieldMap));
        return tagAttributesMap;
    }

    /**
     * @param imFieldName
     * @param tag
     * @return
     */
    public ImageManagerAttributeExtractorFromDicomElement createExtractor(
            final List<DicomImageManagerMapping> imFieldMap, final String fieldName) {
        ImageManagerAttributeExtractorFromDicomElement extractor = null;
        Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributesMap = this
                .getMappingTagAttributes(imFieldMap);
        if (null != fieldName) {
            extractor = tagAttributesMap.get(fieldName);
        }
        if (null == extractor) {
            extractor = this.createDefaultExtractor(imFieldMap, fieldName);
        }
        return extractor;
    }

    private ImageManagerAttributeExtractorFromDicomElement createDefaultExtractor(
            final List<DicomImageManagerMapping> imFieldMap, final String fieldName) {
        ImageManagerAttributeExtractorFromDicomElement extractor = null;
        if (isMapForSingleTag(imFieldMap)) {
            extractor = ExtractDicomTagsAsAttributesForImageManager.createInstance(imFieldMap, imFieldMap.get(0)
                    .getDcmTagId());
        }
        return extractor;
    }

    private boolean isMapForSingleTag(final List<DicomImageManagerMapping> imFieldMap) {
        return null != imFieldMap && !imFieldMap.isEmpty() && imFieldMap.size() == 1;
    }
}
