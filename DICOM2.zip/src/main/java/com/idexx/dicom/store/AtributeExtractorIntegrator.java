/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.store;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * <pre>Description of the class</pre>
 * @author vvanjarana
 * @version 1.3
 */
@Service
public class AtributeExtractorIntegrator {
    
    
    private Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributes;
    
    @Autowired
    ImageManagerAttributeProvider attributeProvider;

    public AtributeExtractorIntegrator() {

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.AtributeExtractorIntegrator#createExtractor()
     */
    public DicomDcmElementExtractorForImagerManager createExtractor() {      
        
        tagAttributes = attributeProvider.getMappingTagAttributes();        
        return new DicomDcmElementExtractorForImagerManagerImpl(tagAttributes);
    }
}
