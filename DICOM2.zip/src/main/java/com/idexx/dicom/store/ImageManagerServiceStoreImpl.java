/**
 * 
 */
package com.idexx.dicom.store;

import org.apache.log4j.Logger;

import com.idexx.dicom.ImageManagerStoreServiceProvider;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.UploadImageDTO;

/**
 * @author vkandagatla
 * 
 */
public class ImageManagerServiceStoreImpl implements ImageManagerServiceStoreHandler {

	private static final Logger LOG = Logger.getLogger(ImageManagerServiceStoreImpl.class);

	ImageManagerStoreServiceProvider storeServiceProvider;

	public ImageManagerServiceStoreImpl(final ImageManagerStoreServiceProvider storeServiceProvider) {
		this.storeServiceProvider = storeServiceProvider;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.store.ImageManagerServiceStoreHandler#store(com.idexx
	 * .imaging.imagemanager.soap.ImageStoreRequestDTO)
	 */
	@Override
	public final String storeImgMetaData(final StoreImageMetaDataDTO dto) throws IdexxServiceException_Exception {
		String uuId = "";
		try {
			IDEXXImageManagerServices idexxImService = storeServiceProvider.getService();
			uuId = "UID=" + idexxImService.storeImageMetaData(dto);
			LOG.info("Image Manager Response: " + uuId);

		} catch (IdexxServiceException_Exception exp) {
			IdexxServiceException idexxServiceException = exp.getFaultInfo();
			String errorCode = idexxServiceException.getErrorCode();
			LOG.error(
					"Image Manager Response Exception : " + idexxServiceException.getMessage() + "ERROR=" + errorCode);
			throw exp;
		} catch (Exception exp1) {
			LOG.error("Image Manager Response Exception : " + exp1);
			throw new IdexxServiceException_Exception(exp1.getMessage(), null);
		}
		return uuId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.store.ImageManagerServiceStoreHandler#store(com.idexx
	 * .imaging.imagemanager.soap.ImageStoreRequestDTO)
	 */
	@Override
	public final String storeUploadImg(final UploadImageDTO dto) throws IdexxServiceException_Exception {
		String uuId = "";
		try {
			IDEXXImageManagerServices idexxImService = storeServiceProvider.getService();
			uuId = "UID=" + idexxImService.uploadImage(dto);
			LOG.info("Image Manager Response: " + uuId);

		} catch (Exception exp1) {
			LOG.error("Image Manager Response Exception : " + exp1.getMessage(), exp1);
			// uuId = "ERROR=" + exp1.getMessage();
			throw new IdexxServiceException_Exception(exp1.getMessage(), null);
		}
		return uuId;
	}

}
