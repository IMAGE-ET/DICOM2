/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.dao.store.IdexxDicomAuthenticationDao;
import com.idexx.dicom.store.authorization.AuthorizationFailureService;

/**
 * @author vkandagatla
 * 
 */
@Service
public class IdexxDicomAuthorizationFailureServiceImpl implements AuthorizationFailureService {
    @Autowired
    private IdexxDicomAuthenticationDao dao;

    /**
     * 
     */
    public IdexxDicomAuthorizationFailureServiceImpl(final IdexxDicomAuthenticationDao dao) {
        this.dao = dao;
    }
    
    public IdexxDicomAuthorizationFailureServiceImpl() {
     
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.authorization.AuthorizationFailureService
     * #logIdexxAuthorizationFailure
     * (com.idexx.dicom.store.authorization.IdexxAuthorization)
     */
    @Override
    public final void logIdexxAuthorizationFailure(final String aeTitle, final String instituteName, final String ip,
            final String hostName, final String manufacturer, final String manufacturerModelName,
            final String modality, final String patientName, final String respPersonName) {
        IdexxDicomServiceFailureLog log = new IdexxDicomServiceFailureLog();
        log.setAeTitle(aeTitle);
        log.setInstituteName(instituteName);
        log.setIpAddress(ip);
        log.setHostName(hostName);
        log.setManufacturer(manufacturer);
        log.setManufacturerModelName(manufacturerModelName);
        log.setModality(modality);
        log.setPatientName(patientName);
        log.setResponsiblePersonName(respPersonName);
        log.setErrorType("AE_ERROR");
        log.setErrorMessage("Authentication error");
        this.dao.logDicomServiceAuthorizationFailure(log);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.authorization.AuthorizationFailureService
     * #logIdexxAuthorizationFailure
     * (com.idexx.dicom.store.authorization.IdexxAuthorization)
     */
    @Override
    public final void logIdexxStoreFailure(final String aeTitle, final String instituteName, final String ip,
            final String hostName, final String manufacturer, final String manufacturerModelName,
            final String modality, final String patientName, final String respPersonName) {
        IdexxDicomServiceFailureLog log = new IdexxDicomServiceFailureLog();
        log.setAeTitle(aeTitle);
        log.setInstituteName(instituteName);
        log.setIpAddress(ip);
        log.setHostName(hostName);
        log.setManufacturer(manufacturer);
        log.setManufacturerModelName(manufacturerModelName);
        log.setModality(modality);
        log.setPatientName(patientName);
        log.setResponsiblePersonName(respPersonName);
        log.setErrorType("STORAGE_ERROR");
        log.setErrorMessage("Error while storing image");
        this.dao.logDicomServiceAuthorizationFailure(log);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.authorization.AuthorizationFailureService
     * #logIdexxAuthorizationFailure
     * (com.idexx.dicom.store.authorization.IdexxAuthorization)
     */
    @Override
    public final void logIdexxUploadFailure(final String aeTitle, final String instituteName, final String ip,
            final String hostName, final String manufacturer, final String manufacturerModelName,
            final String modality, final String patientName, final String respPersonName) {
        IdexxDicomServiceFailureLog log = new IdexxDicomServiceFailureLog();
        log.setAeTitle(aeTitle);
        log.setInstituteName(instituteName);
        log.setIpAddress(ip);
        log.setHostName(hostName);
        log.setManufacturer(manufacturer);
        log.setManufacturerModelName(manufacturerModelName);
        log.setModality(modality);
        log.setPatientName(patientName);
        log.setResponsiblePersonName(respPersonName);
        log.setErrorType("UPLOAD_ERROR");
        log.setErrorMessage("Error while uploading image");
        this.dao.logDicomServiceAuthorizationFailure(log);
    }
}
