/**
 * AuthorizationFailureService.java
 */
package com.idexx.dicom.store.authorization;

/**
 * @author vkandagatla
 * 
 */
public interface AuthorizationFailureService {
    /**
     * @param aeTitle
     * @param instituteName
     * @param ip
     * @param hostName
     * @param manufacturer
     * @param manufacturerModelName
     * @param modality
     * @param patientName
     * @param respPersonName
     */
    void logIdexxAuthorizationFailure(String aeTitle, String instituteName, String ip, String hostName,
            String manufacturer, String manufacturerModelName, String modality, String patientName,
            String respPersonName);
    /**
     * 
     * @param aeTitle
     * @param instituteName
     * @param ip
     * @param hostName
     * @param manufacturer
     * @param manufacturerModelName
     * @param modality
     * @param patientName
     * @param respPersonName
     */
    public void logIdexxStoreFailure(final String aeTitle, final String instituteName, final String ip,
            final String hostName, final String manufacturer, final String manufacturerModelName,
            final String modality, final String patientName, final String respPersonName);
    
    /**
     * 
     * @param aeTitle
     * @param instituteName
     * @param ip
     * @param hostName
     * @param manufacturer
     * @param manufacturerModelName
     * @param modality
     * @param patientName
     * @param respPersonName
     */
    public void logIdexxUploadFailure(final String aeTitle, final String instituteName, final String ip,
            final String hostName, final String manufacturer, final String manufacturerModelName,
            final String modality, final String patientName, final String respPersonName);
    
}
