/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.store;

import org.dcm4che3.data.Attributes;

/**
 * <pre>Description of the class</pre>
 * @author vvanjarana
 * @version 1.3
 */
public interface ImageManagerAttributeExtractorFromDicomElement {
    Integer DEFAULT_BUFFER_LENGTH = 64;
    /**
     * @param dcmElement
     * @param tag
     * @return ImageManagerAttribute
     */
    String exractAtribute(Attributes dataset);
}
