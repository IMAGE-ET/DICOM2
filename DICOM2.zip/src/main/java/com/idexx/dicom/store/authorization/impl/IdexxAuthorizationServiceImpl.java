/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.dao.store.IdexxDicomAuthenticationDao;
import com.idexx.dicom.exceptions.IdexxDicomAuthorizationException;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.authorization.IdexxAuthorizationBuilder;
import com.idexx.dicom.store.authorization.IdexxAuthorizationService;

/**
 * @author vkandagatla
 * 
 */
@Service
public class IdexxAuthorizationServiceImpl implements IdexxAuthorizationService {
    
    @Autowired
    private IdexxDicomAuthenticationDao dao;
    
    @Autowired
    private IdexxAuthorizationBuilder authorizationBuilder;
    
    /**
     * @param dao
     */
    public IdexxAuthorizationServiceImpl() {}
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.authorization.IdexxAuthorizationService#authorize
     * (java.lang.String, java.lang.String)
     */
    @Override
    public final IdexxAuthorization authorize(final String aeTitle, final String instituteName)
            throws IdexxDicomAuthorizationException {
        IdexxAuthorization auth = null;
        List<AETitle> aeTitles = dao.getAeTitle(aeTitle);
        boolean isAETitleIdentifiedByAeOnly = this.isAETitleIdentifiedAeTitleOnly(aeTitles);
        if (isAETitleIdentifiedByAeOnly) {
            // Authorizae based on AETitle
            auth = this.authorizaeByAETitleOnly(aeTitles.get(0));
        } else {
            // Authorize based on AETitle and InstituteName
            aeTitles = dao.getAeTitle(aeTitle, instituteName);
            auth = this.authorizeAeByAETitleAndInstituteName(aeTitles);
        }
        return auth;
    }
    
    /**
     * @param aeTitles
     * @return
     */
    private IdexxAuthorization authorizeAeByAETitleAndInstituteName(final List<AETitle> aeTitles) throws IdexxDicomAuthorizationException {
        AETitle aeTitle = null;
        if (isAETitlesExists(aeTitles) && aeTitles.size() >= 1) {
            aeTitle = aeTitles.get(0);
        } else {
            throw new IdexxDicomAuthorizationException("AETitle Does not exists");
        }
        IdexxAuthorization auth = null;
        if (!aeTitle.isIdentifiedByaeTitleOnly()) {
            auth = this.authorizaeByAETitleOnly(aeTitle);
        }
        return auth;
    }
    
    /**
     * @param aeTitle
     * @return
     */
    private IdexxAuthorization authorizaeByAETitleOnly(final AETitle aeTitle) throws IdexxDicomAuthorizationException {
        IdexxAuthorization auth = null;
        if (aeTitle.isEnabled()) {
            // Build Authorization Object
            auth = authorizationBuilder.createAuthorization(true, aeTitle.getAeTitle(),
                    aeTitle.getInstituteName(), aeTitle.getApiKey(), aeTitle.isIdentifiedByaeTitleOnly(), aeTitle.getSapId());
            this.updateLastAccessedTime(aeTitle);
        } else {
            throw new IdexxDicomAuthorizationException("AETitle Not enabled");
        }
        return auth;
    }
    
    /**
     * @param aeTitle
     */
    private void updateLastAccessedTime(final AETitle aeTitle) {
        aeTitle.setLastAccessedDateTime(new Timestamp(System.currentTimeMillis()));
        this.dao.updateAETitle(aeTitle);
    }
    
    /**
     * @param aeTitles
     * @return
     */
    private boolean isAETitleIdentifiedAeTitleOnly(final List<AETitle> aeTitles) throws IdexxDicomAuthorizationException {
        boolean aeOnly = false;
        if (isAETitlesExists(aeTitles) && aeTitles.size() >= 1) {
            AETitle aeTitle = aeTitles.get(0);
            aeOnly = aeTitle.isIdentifiedByaeTitleOnly();
        } else {
            throw new IdexxDicomAuthorizationException("AETitle Does not exists");
        }
        return aeOnly;
    }
    
    /**
     * @param aeTitles
     * @return
     */
    private boolean isAETitlesExists(final List<AETitle> aeTitles) {
        return null != aeTitles && !aeTitles.isEmpty();
    }
    
}
