/**
 * 
 */
package com.idexx.dicom.store.authorization;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxAuthorizationBuilder {
    IdexxAuthorization createAuthorization(final boolean isAuthenticated,
            final String aeTitle, final String instituteName,
            final String apiKey, final boolean isIdentifiedByAEOnly, final String sapId);
}
