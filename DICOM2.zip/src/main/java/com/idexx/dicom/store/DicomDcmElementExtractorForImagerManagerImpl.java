/**
 * 
 */
package com.idexx.dicom.store;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.dcm4che3.data.Attributes;

/**
 * @author vkandagatla
 * 
 */
public class DicomDcmElementExtractorForImagerManagerImpl implements DicomDcmElementExtractorForImagerManager {

    private Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributes;

    /**
     * @param attributeProvider
     * @param extractor
     */
    public DicomDcmElementExtractorForImagerManagerImpl(
            final Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributes) {
        super();
        this.tagAttributes = tagAttributes;
    }

    @Override
    public final Map<String, String> extractDcmElements(final Attributes dataset) {
        Set<Map.Entry<String, ImageManagerAttributeExtractorFromDicomElement>> tagEntrySet = tagAttributes.entrySet();
        Map<String, String> resultMap = new HashMap<String, String>();
        for (Entry<String, ImageManagerAttributeExtractorFromDicomElement> tagEntry : tagEntrySet) {
            String attribute = tagEntry.getKey();
            ImageManagerAttributeExtractorFromDicomElement extractor = tagEntry.getValue();
            resultMap.put(attribute, extractor.exractAtribute(dataset));

        }
        return resultMap;
    }

}
