/**
 * 
 */
package com.idexx.dicom.dto;

/**
 * @author vkandagatla
 * 
 */
public class IdexxAuthorizationObject {
    private String aeTitle;
    private String instituteName;
    private String apiKey;
    private boolean identifiedByAeTitleOnly;
    private String sapId;
    
    /**
     * Default
     */
    public IdexxAuthorizationObject() {
    }
    
    /**
     * @param aeTitle
     * @param instituteName
     * @param apiKey
     * @param identifiedByAeTitleOnly
     */
    public IdexxAuthorizationObject(final String aeTitle, final String instituteName, final String apiKey,
            final boolean identifiedByAeTitleOnly, final String sapId) {
        this.aeTitle = aeTitle;
        this.instituteName = instituteName;
        this.apiKey = apiKey;
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
        this.sapId = sapId;
    }
    
    /**
     * @return the aeTitle
     */
    public final String getAeTitle() {
        return aeTitle;
    }
    
    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public final void setAeTitle(final String aeTitle) {
        this.aeTitle = aeTitle;
    }
    
    /**
     * @return the instituteName
     */
    public final String getInstituteName() {
        return instituteName;
    }
    
    /**
     * @param instituteName
     *            the instituteName to set
     */
    public final void setInstituteName(final String instituteName) {
        this.instituteName = instituteName;
    }
    
    /**
     * @return the apiKey
     */
    public final String getApiKey() {
        return apiKey;
    }
    
    /**
     * @param apiKey
     *            the apiKey to set
     */
    public final void setApiKey(final String apiKey) {
        this.apiKey = apiKey;
    }
    
    /**
     * @return the identifiedByAeTitleOnly
     */
    public final boolean isIdentifiedByAeTitleOnly() {
        return identifiedByAeTitleOnly;
    }
    
    /**
     * @param identifiedByAeTitleOnly
     *            the identifiedByAeTitleOnly to set
     */
    public final void setIdentifiedByAeTitleOnly(final boolean identifiedByAeTitleOnly) {
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
    }
    
    public final String getSapId() {
        return sapId;
    }
    
    public final void setSapId(final String sapId) {
        this.sapId = sapId;
    }
    
}
