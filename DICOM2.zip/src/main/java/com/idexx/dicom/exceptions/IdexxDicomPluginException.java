/**
 * 
 */
package com.idexx.dicom.exceptions;

/**
 * @author vkandagatla
 *
 */
public class IdexxDicomPluginException extends Throwable {
    
    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = 4410927477011271804L;

    /**
     * Default
     */
    public IdexxDicomPluginException() {
    }
    
    /**
     * @param message
     */
    public IdexxDicomPluginException(final String message) {
        super(message);
    }
    
    /**
     * @param cause
     */
    public IdexxDicomPluginException(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message
     * @param cause
     */
    public IdexxDicomPluginException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
}
