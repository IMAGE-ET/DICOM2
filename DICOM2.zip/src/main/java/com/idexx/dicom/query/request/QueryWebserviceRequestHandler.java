/**
 * 
 */
package com.idexx.dicom.query.request;

import org.dcm4che3.data.Attributes;

import com.idexx.dicom.query.soap.ArrayOfQRDataSet;
import com.idexx.dicom.query.soap.ArrayOfstring;
import com.idexx.dicom.query.soap.QRService11DicomQRRoot;
/**
 * @author vkandagatla
 * 
 */
public interface QueryWebserviceRequestHandler {
    long WEBSERVICE_TIMOUT = 60000L;
    ArrayOfQRDataSet search(Attributes dataset, QRService11DicomQRRoot qRService11DicomQRRoot, String requestingAETILE);
    ArrayOfstring getRequestTokens(Attributes dataset, String requestingAETILE);
}
