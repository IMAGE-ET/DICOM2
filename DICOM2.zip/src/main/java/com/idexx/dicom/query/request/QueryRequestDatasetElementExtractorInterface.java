package com.idexx.dicom.query.request;

import java.util.Map;

import org.dcm4che3.data.Attributes;

/**
 * 
 * @author apinninti
 * 
 */
public interface QueryRequestDatasetElementExtractorInterface {
    /**
     * Abstract method that extract data from dataset
     * 
     * @param dataset
     * @return
     */
    Map<String, String> getElementsExtractedFromDataset(final Attributes dataset);
}
