/**
 * 
 */
package com.idexx.dicom.query.response;

import org.dcm4che3.data.Attributes;

/**
 * @author vkandagatla
 *
 */
public interface DataSetTagCreator {
    void createTag(Attributes dataSet, int tag, String tagValue);
}
