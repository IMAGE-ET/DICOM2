/**
 * 
 */
package com.idexx.dicom.query.common;

import java.util.Map;

/**
 * @author vkandagatla
 *
 */
public interface TagsElementMappingService {
    String IMAGE_QUERY_COMPONENT_NAME = "IMAGE_QUERY";
    int IMAGE_QUERY_COMPONENT_REQUEST_TYPE = 1;
    Map<String, Integer> getMappings();
}
