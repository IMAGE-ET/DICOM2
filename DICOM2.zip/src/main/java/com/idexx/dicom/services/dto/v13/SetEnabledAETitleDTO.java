/**
 * 
 */
package com.idexx.dicom.services.dto.v13;

/**
 * <pre>SetEnabledAETitleDTO hold information About AE Title enabled</pre>
 * @author smallela
 * @version 1.3
 */
public class SetEnabledAETitleDTO extends AETitleDTO {
    private boolean enabled;
    
    /**
     * @return the enabled
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * @param enabled
     *            the enabled to set
     */
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
}