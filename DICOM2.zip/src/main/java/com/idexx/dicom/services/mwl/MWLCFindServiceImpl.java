/**
 * 
 */
package com.idexx.dicom.services.mwl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dcm4che3.tool.dcmqrscp.PatientQueryBuilder;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.AETitleRepository;
import com.idexx.dicom.repo.MPPSNCreateRepository;
import com.idexx.dicom.services.requestservice.dto.SearchDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

// TODO: Auto-generated Javadoc
/**
 * The Class MWLCFindServiceImpl.
 *
 * @author rkaranam
 * @version 1.3
 */
@Service("mwlCFindService")
public class MWLCFindServiceImpl {

	/** The mpps n create repository. */
	@Autowired
	private MPPSNCreateRepository mppsNCreateRepository;

	/** The ae title respository. */
	@Autowired
	private AETitleRepository aeTitleRespository;

	/** The patient query builder. */
	@Autowired
	private PatientQueryBuilder patientQueryBuilder;

	/** The entity mapper. */
	@Autowired
	@Qualifier("entityMapper")
	private EntityMapper entityMapper;

	/**
	 * Find sequence.
	 *
	 * @param studyInstanceUID
	 *            the study instance uid
	 * @return the list
	 */
	public List<MPPSNCreate> findSequence(final String studyInstanceUID) {
		return mppsNCreateRepository.findByStudyInstanceUID(studyInstanceUID);
	}

	/**
	 * Find distinct ae title by sap id.
	 *
	 * @param aeTitle
	 *            the ae title
	 * @return the list
	 */
	public List<String> findDistinctAeTitleBySapId(String aeTitle) {
		return aeTitleRespository.findDistinctAeTitleBySapId(aeTitle);
	}

	/**
	 * Find request details.
	 *
	 * @param searchDetails
	 *            the search details
	 * @return the list
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 */
	public List<RequestDetails> findRequestDetails(final SearchDetailsDTO searchDetails)
			throws IdexxServiceException_Exception {
		return patientQueryBuilder.buildSearchPatientQuery(searchDetails);
	}

	/**
	 * Gets the external patient id list.
	 *
	 * @param extPatients
	 *            the ext patients
	 * @return the external patient id list
	 */
	public List<ExternalPatientIdDTO> getExternalPatientIdList(final List<ExternalPatient> extPatients) {
		return entityMapper.convertExternalPatientsListToDto(extPatients);
	}

}
