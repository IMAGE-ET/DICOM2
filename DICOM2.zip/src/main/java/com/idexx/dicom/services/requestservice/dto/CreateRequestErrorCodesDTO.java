/**
 * <h1>Create Request Service Error codes DTO.</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

import java.util.List;

import com.idexx.dicom.services.requestservice.validator.ErrorDTO;

public class CreateRequestErrorCodesDTO {
	
	private List<ErrorDTO> errors;

	/**
	 * @return the errors
	 */
	public List<ErrorDTO> getErrors() {
	    return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<ErrorDTO> errors) {
	    this.errors = errors;
	}


}
