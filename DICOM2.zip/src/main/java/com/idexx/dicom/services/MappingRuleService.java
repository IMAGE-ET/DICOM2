package com.idexx.dicom.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.domain.MappingRule;
import com.idexx.dicom.domain.MappingRuleAction;
import com.idexx.dicom.domain.MappingRuleTrigger;
import com.idexx.dicom.dto.MappingRuleActionDTO;
import com.idexx.dicom.dto.MappingRuleDTO;
import com.idexx.dicom.dto.MappingRuleTriggerDTO;
import com.idexx.dicom.repo.MappingRuleRepo;
import com.idexx.dicom.util.MappingUtil;

@Service
@Transactional
public class MappingRuleService {

	@Autowired
	private MappingRuleRepo mappingRuleRepo;
	
	/**
	 * Save or update mapping rules
	 * @param ruleDTOs
	 */
	public void saveOrUpdate(List<MappingRuleDTO> ruleDTOs) {
		for (MappingRuleDTO ruleDTO:ruleDTOs) {
			MappingRule mappingRule = null;
			if (StringUtils.isNotBlank(ruleDTO.getId())) {
				mappingRule = mappingRuleRepo.findById(ruleDTO.getId());			    
			}
			mappingRuleRepo.save(copyRuleDTO(ruleDTO, mappingRule));
		}
	}
	
	/**
	 * Get all mapping rules associated with sap id.
	 * @param sapId
	 * @return
	 */
	public List<MappingRuleDTO> getRulesBySapId(String sapId) {
		List<MappingRule> rules = mappingRuleRepo.findBySapId(sapId);
		List<MappingRuleDTO> dtos = new ArrayList<MappingRuleDTO>(rules.size());
		for (MappingRule rule: rules) {
			dtos.add(copyRule(rule));
		}
		return dtos;
	}
	
	/**
	 * delete rule based on ruleDTO.id
	 * @param ruleDTO
	 */
	public void deleteRule(MappingRuleDTO ruleDTO) {
		if (StringUtils.isNotBlank(ruleDTO.getId())) {
			MappingRule mappingRule = mappingRuleRepo.findById(ruleDTO.getId());
			if(mappingRule!=null) {
			    mappingRuleRepo.delete(mappingRule);
			}
		}
	}
	
	
	
	/*
	 *  DTO from entity mappings
	 */
	
	private MappingRuleDTO copyRule(MappingRule rule) {
		MappingRuleDTO dto = new MappingRuleDTO();
		dto.setId(rule.getId());
		copyRuleActions(rule.getMappingRuleActions(), dto.getMappingRuleActions());
		copyRuleTriggers(rule.getMappingRuleTriggers(), dto.getMappingRuleTriggers());
		dto.setName(rule.getName());
		dto.setSapId(rule.getSapId());
		return dto;
	}
	
	private void copyRuleTriggers(Set<MappingRuleTrigger> mappingRuleTriggers,
			Set<MappingRuleTriggerDTO> mappingRuleTriggerDTOs) {
		mappingRuleTriggerDTOs.clear();
		for (MappingRuleTrigger trigger:mappingRuleTriggers) {
			MappingRuleTriggerDTO dto = new MappingRuleTriggerDTO();
			dto.setId(trigger.getId());
			dto.setTagKey(trigger.getTagKey());
			dto.setTagValue(trigger.getTagValue());
			mappingRuleTriggerDTOs.add(dto);
		}
	}

	private void copyRuleActions(Set<MappingRuleAction> mappingRuleActions,
			Set<MappingRuleActionDTO> mappingRuleActionDTOs) {
		mappingRuleActionDTOs.clear();
		for (MappingRuleAction action:mappingRuleActions) {
			MappingRuleActionDTO dto = new MappingRuleActionDTO();
			dto.setId(action.getId());
			dto.setTagKey(action.getTagKey());
			dto.setActionType(action.getActionType());
			dto.setDoActionIfNull(action.getDoActionIfNull());
			dto.setReplaceValue(action.getReplaceValue());
			mappingRuleActionDTOs.add(dto);
		}
	}

	/*
	 *  DTO to entity mappings
	 */

	private MappingRule copyRuleDTO(MappingRuleDTO ruleDTO, MappingRule rule) {
		MappingRule temp = rule;
		if (temp==null) {
			temp = new MappingRule();
		}		
		temp.setName(ruleDTO.getName());
		temp.setSapId(ruleDTO.getSapId());
		copyRuleActionDTOs(ruleDTO.getMappingRuleActions(), temp);
		copyRuleTriggerDTOs(ruleDTO.getMappingRuleTriggers(), temp);
		return temp;
		
	}

	private void copyRuleTriggerDTOs(Set<MappingRuleTriggerDTO> mappingRuleTriggers,
			MappingRule rule) {

		// remove non-existent
		Set<MappingRuleTrigger> toRemove = new HashSet<MappingRuleTrigger>();
		for (MappingRuleTrigger trigger: rule.getMappingRuleTriggers()) {
			boolean found = false;
			for (MappingRuleTriggerDTO dto: mappingRuleTriggers) {
				if (trigger.getId().equals(dto.getId())) {
					found = true;
					break;
				}
			}
			if (!found) {
				toRemove.add(trigger);
			}
		}
		rule.getMappingRuleTriggers().removeAll(toRemove);
		
		Set<MappingRuleTrigger> toAdd = new HashSet<MappingRuleTrigger>();
		// update existing
		for (MappingRuleTriggerDTO dto: mappingRuleTriggers) {
			boolean found = false;
			for (MappingRuleTrigger trigger: rule.getMappingRuleTriggers()) {
				if (trigger.getId().equals(dto.getId())) {
					found = true;
					copyTriggerDTO(dto, trigger);
					break;
				}
			}
			if (!found) {
				MappingRuleTrigger trigger = new MappingRuleTrigger();
				trigger.setMappingRule(rule);
				copyTriggerDTO(dto, trigger);
				toAdd.add(trigger);
			}
		}
		
		rule.getMappingRuleTriggers().addAll(toAdd);
		
	}

	/**
	 * @param dto
	 * @param trigger
	 */
	private void copyTriggerDTO(MappingRuleTriggerDTO dto, MappingRuleTrigger trigger) {
		trigger.setTagKey(dto.getTagKey());
		trigger.setTagValue(dto.getTagValue());
		// validate dicom mapping tags before save
		MappingUtil.getTag(dto.getTagKey());
	}

	private void copyRuleActionDTOs(Set<MappingRuleActionDTO> mappingRuleActions,
			MappingRule rule) {
		// remove non-existent
		Set<MappingRuleAction> toRemove = new HashSet<MappingRuleAction>();
		for (MappingRuleAction trigger: rule.getMappingRuleActions()) {
			boolean found = false;
			for (MappingRuleActionDTO dto: mappingRuleActions) {
				if (trigger.getId().equals(dto.getId())) {
					found = true;
					break;
				}
			}
			if (!found) {
				toRemove.add(trigger);
			}
		}
		rule.getMappingRuleActions().removeAll(toRemove);
		
		Set<MappingRuleAction> toAdd = new HashSet<MappingRuleAction>();
		
		// update existing
		for (MappingRuleActionDTO dto: mappingRuleActions) {
			boolean found = false;
			for (MappingRuleAction action: rule.getMappingRuleActions()) {
				if (action.getId().equals(dto.getId())) {
					found = true;
					copyActionDTO(dto, action);
					break;
				}
			}
			if (!found) {
				MappingRuleAction action = new MappingRuleAction();
				action.setMappingRule(rule);
				copyActionDTO(dto, action);
				toAdd.add(action);
			}
		}
		rule.getMappingRuleActions().addAll(toAdd);
	}

	/**
	 * @param dto
	 * @param action
	 */
	private void copyActionDTO(MappingRuleActionDTO dto, MappingRuleAction action) {
		action.setTagKey(dto.getTagKey());
		action.setActionType(dto.getActionType());
		action.setDoActionIfNull(dto.getDoActionIfNull());
		action.setReplaceValue(dto.getReplaceValue());
		// validate dicom mapping tags before save
		MappingUtil.getTag(dto.getTagKey());
		if (MappingUtil.REPLACE_BY_TAG.equalsIgnoreCase(action.getActionType())) {
			MappingUtil.getTag(dto.getReplaceValue());
		}
	}

}
