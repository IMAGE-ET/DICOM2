/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

/**
 * <pre>Description of the class</pre>
 * @author smallela
 * @version 1.3
 */
public class OwnersDTO {
	
	private String id;
	private Boolean primaryOwner;
	private String email;
	private String clientFirstName;
	private String clientLastName;
	private String applicationClientId;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the primaryOwner
	 */
	public Boolean getPrimaryOwner() {
		return primaryOwner;
	}
	/**
	 * @param primaryOwner the primaryOwner to set
	 */
	public void setPrimaryOwner(Boolean primaryOwner) {
		this.primaryOwner = primaryOwner;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the clientFirstName
	 */
	public String getClientFirstName() {
		return clientFirstName;
	}
	/**
	 * @param clientFirstName the clientFirstName to set
	 */
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}
	/**
	 * @return the clientLastName
	 */
	public String getClientLastName() {
		return clientLastName;
	}
	/**
	 * @param clientLastName the clientLastName to set
	 */
	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}
	/**
	 * @return the applicationClientId
	 */
	public String getApplicationClientId() {
		return applicationClientId;
	}
	/**
	 * @param applicationClientId the applicationClientId to set
	 */
	public void setApplicationClientId(String applicationClientId) {
		this.applicationClientId = applicationClientId;
	}
	
	
	

}
