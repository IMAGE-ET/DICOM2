/**
 * IDEXX DICOM Web services.
 * This Implementation provides following services:
 * 1. Create AE Title - Creates new AE Title with given parameters
 * 2. Delete AE Title - delete given AE Title
 * 3. Read AE Title - read list of AE Titles for given AE Title name, inistitute name and with other params
 * 4. Set Enable AE Title - update AE Title, as enable/disable
 * 5. Details of the authorization failure instances for Store image.
 * 6. Send Image to third party AE
 * 7. Get the status of the C-move job requested through SendImage service
 */
package com.idexx.dicom.services;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.idexx.dicom.aeservices.v12.AEService;
import com.idexx.dicom.aeservices.v12.AssumedIssuerService;
import com.idexx.dicom.aeservices.v12.CancelSendJobService;
import com.idexx.dicom.aeservices.v12.GetStoreFailuresServiceIntf;
import com.idexx.dicom.aeservices.v12.SendImageJobService;
import com.idexx.dicom.aeservices.v12.SendImageStatusService;
import com.idexx.dicom.aeservices.v12.StoreErrorLogService;
import com.idexx.dicom.echo.v12.DicomEchoService;
import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.dto.v12.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v12.CreateAETitleDTO;
import com.idexx.dicom.services.dto.v12.EchoDTO;
import com.idexx.dicom.services.dto.v12.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v12.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v12.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.dto.v12.ReadAETitleDTO;
import com.idexx.dicom.services.dto.v12.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v12.SetAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v12.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.CancelSendJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v12.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageStatusParamDTO;

/**
 * The Class IdexxDicomAEConfigServicesV1_2.
 *
 * @author anarayana
 */
@WebService(targetNamespace = "http://idexx.services.dicom.idexx.com/", portName = "IdexxDicomAEConfigServiceImplPortV1_2", serviceName = "IdexxDicomAEConfigServicesV1_2")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
@Service("IdexxDicomAEConfigServicesV1_2")
public class IdexxDicomAEConfigServicesV1_2 extends SpringBeanAutowiringSupport {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(IdexxDicomAEConfigServicesV1_2.class);

	/** The create service. */
	@Autowired
	@Qualifier("createAETitleServiceV12")
	private AEService createService;

	/** The delete service. */
	@Autowired
	@Qualifier("deleteAETitleServiceV12")
	private AEService deleteService;

	/** The read service. */
	@Autowired
	@Qualifier("readAETitleServiceV12")
	private AEService readService;

	/** The set enabled ae service. */
	@Autowired
	@Qualifier("setAETitleStatusServiceV12")
	private AEService setEnabledAEService;

	/** The get store failures service. */
	@Autowired
	@Qualifier("getStoreFailuresServiceV12")
	private GetStoreFailuresServiceIntf getStoreFailuresService;

	/** The get store error log. */
	@Autowired
	@Qualifier("storeErrorLogServiceV12")
	private StoreErrorLogService getStoreErrorLog;

	/** The send image job service. */
	@Autowired
	@Qualifier("getIdexxSendImageValidatorV12")
	private SendImageJobService sendImageJobService;

	/** The send image status service. */
	@Autowired
	@Qualifier("getSendImageStatusServiceV12")
	private SendImageStatusService sendImageStatusService;

	/** The cancel send job service. */
	@Autowired
	@Qualifier("cancelSendJobServiceImplV12")
	private CancelSendJobService cancelSendJobService;

	/** The dicom echo service. */
	@Autowired
	@Qualifier("dicomEchoServiceImplV12")
	private DicomEchoService dicomEchoService;

	/** The assumed issuer service. */
	@Autowired
	@Qualifier("assumedIssuerServiceV12")
	private AssumedIssuerService assumedIssuerService;

	/**
	 * Echo.
	 *
	 * @param echoDTO
	 *            the echo dto
	 * @return true, if successful
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final boolean echo(final EchoDTO echoDTO) throws IdexxDicomAEConfigServiceException {
		boolean isEcho = Boolean.FALSE;
		try {
			if (!echoDTO.isEmpty()) {
				isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getCalledAeTitle(), echoDTO.getHostName(),
						echoDTO.getPortNumber());
			} else {
				isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getHostName(), echoDTO.getPortNumber());
			}
		} catch (NumberFormatException e) {
			LOG.error(e);
		} catch (InterruptedException e) {
			LOG.error(e);
		}
		return isEcho;
	}

	/**
	 * Register the AE or Add DVMSpecialist to AE list.
	 *
	 * @param aeDTO
	 *            the ae dto
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final void createAETitle(final CreateAETitleDTO aeDTO) throws IdexxDicomAEConfigServiceException {

		createService.performService(aeDTO);
	}

	/**
	 * Read the details of the registered AE.
	 *
	 * @param aeTitle
	 *            the ae title
	 * @return the list
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<IdexxDicomApplicationEntityDTO> readAETitle(final ReadAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {

		readService.performService(aeTitle);
		@SuppressWarnings("unchecked")
		List<IdexxDicomApplicationEntityDTO> dtos = (List<IdexxDicomApplicationEntityDTO>) readService.sendResponse();

		return dtos;
	}

	/**
	 * Delete the registered AE title.
	 *
	 * @param aeTitle
	 *            the ae title
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 * @Param aeTitle
	 */
	@WebMethod
	public final void deleteAETitle(final AETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
		deleteService.performService(aeTitle);
	}

	/**
	 * Enable/Disable the registered AE.
	 *
	 * @param aeTitle
	 *            the new enable ae title
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final void setEnableAETitle(final SetEnabledAETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
		setEnabledAEService.performService(aeTitle);
	}

	/**
	 * Details of the authorization failure instances for Store image.
	 *
	 * @param dto
	 *            the dto
	 * @return List of AEAuthorizationFailureLogDTO
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<com.idexx.dicom.services.dto.v12.IdexxFailureLogDTO> getFailures(
			final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		return getStoreFailuresService.performService(dto);
	}

	/**
	 * Gets the failure error logs.
	 *
	 * @param dto
	 *            the dto
	 * @return the failure error logs
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<com.idexx.dicom.services.dto.v12.IdexxFailureLogDTO> getFailureErrorLogs(
			final IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		return getStoreErrorLog.performService(dto);
	}

	/**
	 * Request to send Image to third party AE .
	 *
	 * @param dto
	 *            the dto
	 * @return the string
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final String sendImage(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
		return sendImageJobService.performService(dto);
	}

	/**
	 * Get the status of the C-move job requested through SendImage service.
	 *
	 * @param dto
	 *            the dto
	 * @return the c move job status
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<IdexxSendImageJobStatusDTO> getCMoveJobStatus(final SendImageStatusParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		List<IdexxSendImageJobStatusDTO> aeResponse = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
				.performService(dto);
		return aeResponse;
	}

	/**
	 * Cancel send job.
	 *
	 * @param dto
	 *            the dto
	 * @return the string
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final String cancelSendJob(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
		return cancelSendJobService.performService(dto);
	}

	/**
	 * Sets the assumed issuer.
	 *
	 * @param aiDTO
	 *            the ai dto
	 * @return the string
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final String setAssumedIssuer(final SetAssumedIssuerDTO aiDTO) throws IdexxDicomAEConfigServiceException {
		return assumedIssuerService.setAssumedIssuer(aiDTO);
	}

	/**
	 * Read assumed issuer.
	 *
	 * @param dto
	 *            the dto
	 * @return the assumed issuer entity dto
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final AssumedIssuerEntityDTO readAssumedIssuer(final ReadAssumedIssuerDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return assumedIssuerService.readAssumedIssuer(dto);
	}
}
