package com.idexx.dicom.services.dto.v13;

import javax.xml.bind.annotation.XmlElement;

public class IdexxErrorLogParamDTO {

    private String startDate;
    private String endDate;
    private String errorType;
    private String aeTitle;
    private String instituteName;

    @XmlElement(nillable = true, required = false)
    public String getAeTitle() {
        return aeTitle;
    }

    public void setAeTitle(String aeTitle) {
        this.aeTitle = aeTitle;
    }

    @XmlElement(nillable = true, required = false)
    public String getInstituteName() {
        return instituteName;
    }

    public void setInstituteName(String instituteName) {
        this.instituteName = instituteName;
    }

    /**
     * @return the startDate
     */
    @XmlElement(nillable = true, required = true)
    public final String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public final void setStartDate(final String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    @XmlElement(nillable = true, required = true)
    public final String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public final void setEndDate(final String endDate) {
        this.endDate = endDate;
    }

    @XmlElement(nillable = true, required = false)
	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
}
