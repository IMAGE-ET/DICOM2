/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v12;

/**
 * @author anarayana
 * 
 */
public class CancelSendJobParamDTO {

    private String jobId;
    private String jobStatusDescription;

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobStatusDescription() {
        return jobStatusDescription;
    }

    public void setJobStatusDescription(String jobStatusDescription) {
        this.jobStatusDescription = jobStatusDescription;
    }
}
