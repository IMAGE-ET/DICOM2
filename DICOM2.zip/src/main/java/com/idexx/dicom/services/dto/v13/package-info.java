/**
 * 
 */
/**
 * @author vvanjarana
 *
 */
package com.idexx.dicom.services.dto.v13;