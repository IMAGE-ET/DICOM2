/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v13;

/**
 * @author nayeemuddin
 *
 */
public class AbstractIdexxSendImageJobDTO {

	private String jobId;
	private String jobStatusCode;
	private String jobStatusDescription;

	/**
	 * Default Constructor
	 */
	public AbstractIdexxSendImageJobDTO() {
	}

	/**
	 * 
	 * @param jobId
	 * @param jobStatusCode
	 * @param jobStatusDescription
	 */
	public AbstractIdexxSendImageJobDTO(final String jobId, final String jobStatusCode,
			final String jobStatusDescription) {
		this.jobId = jobId;
		this.jobStatusCode = jobStatusCode;
		this.jobStatusDescription = jobStatusDescription;
	}

	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}

	/**
	 * @param jobId
	 *            the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the jobStatusCode
	 */
	public String getJobStatusCode() {
		return jobStatusCode;
	}

	/**
	 * @param jobStatusCode
	 *            the jobStatusCode to set
	 */
	public void setJobStatusCode(String jobStatusCode) {
		this.jobStatusCode = jobStatusCode;
	}

	/**
	 * @return the jobStatusDescription
	 */
	public String getJobStatusDescription() {
		return jobStatusDescription;
	}

	/**
	 * @param jobStatusDescription
	 *            the jobStatusDescription to set
	 */
	public void setJobStatusDescription(String jobStatusDescription) {
		this.jobStatusDescription = jobStatusDescription;
	}

}
