package com.idexx.dicom.services.dto.v12;

import org.apache.commons.lang.StringUtils;

public class AssumedIssuerEntityDTO {

    private String sapId;

    private String assumedIssuerValue;
    
    private String createdDateTime;

    private String lastUpdatedDateTime;
    
    public final String getSapId() {
        return sapId;
    }
    
    public final void setSapId(final String sapId) {
        this.sapId = StringUtils.trimToNull(sapId);
    }
    
    public final String getAssumedIssuerValue() {
        return assumedIssuerValue;
    }
    
    public final void setAssumedIssuerValue(final String assumedIssuerValue) {
        this.assumedIssuerValue = StringUtils.trimToNull(assumedIssuerValue);
    }
    
    public String getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(final String createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(final String lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }
}
