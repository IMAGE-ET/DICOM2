/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

/**
 * <pre>Description of the class</pre>
 * @author vvanjarana
 * @version 1.3
 */
public class CancelResponseDTO {
    
    private String response;
    
    public CancelResponseDTO(String response){
	this.response = response;
    }

    /**
     * @return the response
     */
    public String getResponse() {
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }
    
    

}
