/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v12;

import java.util.List;

import com.idexx.dicom.services.dto.v12.IdexxAuthenticationDTO;

/**
 * @author vkandagatla
 * 
 */
public class SendImageStatusParamDTO extends IdexxAuthenticationDTO {
    private List<String> jobId;
    
    /**
     * Default DTO
     */
    public SendImageStatusParamDTO() {
    }
    
    /**
     * @param apiKey
     *            From Super Class
     */
    public SendImageStatusParamDTO(final String apiKey) {
        super(apiKey);
    }
    
    /**
     * @param jobId
     */
    public SendImageStatusParamDTO(final String apiKey, final List<String> jobId) {
        this(apiKey);
        this.jobId = jobId;
    }

    /**
     * @return the jobId
     */
    public final List<String> getJobId() {
        return jobId;
    }

    /**
     * @param jobId the jobId to set
     */
    public final void setJobId(final List<String> jobId) {
        this.jobId = jobId;
    }
    
}
