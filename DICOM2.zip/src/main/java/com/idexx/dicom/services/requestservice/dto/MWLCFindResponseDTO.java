package com.idexx.dicom.services.requestservice.dto;

import java.util.Date;
import java.util.List;

import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class MWLCFindResponseDTO.
 *
 * @author rkaranam
 * @version 1.3
 */
public class MWLCFindResponseDTO {
	
	/** The patient id. */
	// Patient Module
	private String patientId;
	
	/** The patient name. */
	private String patientName;
	
	/** The date of birth. */
	private Date dateOfBirth;
	
	/** The species. */
	private String species;
	
	/** The breed. */
	private String breed;
	
	/** The gender. */
	private String gender;
	
	/** The application patient id. */
	private String applicationPatientId;
	
	/** The sap id. */
	private String sapId;
	
	/** The weight. */
	private int weight;
	
	/** The last modified date. */
	private Date lastModifiedDate;
	
	/** The requested procedure description. */
	private String requestedProcedureDescription;
	
	/** The requested procedure id. */
	private String requestedProcedureId;
	
	/** The study instance uid. */
	private String studyInstanceUID;
	
	/** The accession number. */
	private String accessionNumber;
	
	/** The responsible peron. */
	// Client Module
	private String responsiblePeron;
	
	/** The responsible organization. */
	private String responsibleOrganization;	
	
	/** The other patient id. */
	// Other Patient ID Sequence
	private String otherPatientId;
	
	/** The other issuer of patient id. */
	private String otherIssuerOfPatientId;
	
	/** The scheduled procedure step id. */
	// Sequence
	private String scheduledProcedureStepId;
	
	/** The scheduled procedure step start date. */
	private Date scheduledProcedureStepStartDate;
	
	/** The scheduled procedure step status. */
	private String scheduledProcedureStepStatus;
	
	/** The modality. */
	private String modality;
	
	private String requestingDoctor;
	
	/** The external patient id dto. */
	List<ExternalPatientIdDTO> externalPatientIdDTO;
	
	/**
	 * Gets the patient id.
	 *
	 * @return the patient id
	 */
	public String getPatientId() {
		return patientId;
	}
	
	/**
	 * Sets the patient id.
	 *
	 * @param patientId the new patient id
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	
	/**
	 * Gets the patient name.
	 *
	 * @return the patient name
	 */
	public String getPatientName() {
		return patientName;
	}
	
	/**
	 * Sets the patient name.
	 *
	 * @param patientName the new patient name
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	/**
	 * Gets the date of birth.
	 *
	 * @return the date of birth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	
	/**
	 * Sets the date of birth.
	 *
	 * @param dateOfBirth the new date of birth
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	/**
	 * Gets the species.
	 *
	 * @return the species
	 */
	public String getSpecies() {
		return species;
	}
	
	/**
	 * Sets the species.
	 *
	 * @param species the new species
	 */
	public void setSpecies(String species) {
		this.species = species;
	}
	
	/**
	 * Gets the breed.
	 *
	 * @return the breed
	 */
	public String getBreed() {
		return breed;
	}
	
	/**
	 * Sets the breed.
	 *
	 * @param breed the new breed
	 */
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	/**
	 * Gets the gender.
	 *
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	
	/**
	 * Sets the gender.
	 *
	 * @param gender the new gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	/**
	 * Gets the application patient id.
	 *
	 * @return the application patient id
	 */
	public String getApplicationPatientId() {
		return applicationPatientId;
	}
	
	/**
	 * Sets the application patient id.
	 *
	 * @param applicationPatientId the new application patient id
	 */
	public void setApplicationPatientId(String applicationPatientId) {
		this.applicationPatientId = applicationPatientId;
	}
	
	/**
	 * Gets the sap id.
	 *
	 * @return the sap id
	 */
	public String getSapId() {
		return sapId;
	}
	
	/**
	 * Sets the sap id.
	 *
	 * @param sapId the new sap id
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	
	/**
	 * Gets the weight.
	 *
	 * @return the weight
	 */
	public int getWeight() {
		return weight;
	}
	
	/**
	 * Sets the weight.
	 *
	 * @param weight the new weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	/**
	 * Gets the last modified date.
	 *
	 * @return the last modified date
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	
	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate the new last modified date
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	/**
	 * Gets the responsible peron.
	 *
	 * @return the responsible peron
	 */
	public String getResponsiblePeron() {
		return responsiblePeron;
	}
	
	/**
	 * Sets the responsible peron.
	 *
	 * @param responsiblePeron the new responsible peron
	 */
	public void setResponsiblePeron(String responsiblePeron) {
		this.responsiblePeron = responsiblePeron;
	}
	
	/**
	 * Gets the responsible organization.
	 *
	 * @return the responsible organization
	 */
	public String getResponsibleOrganization() {
		return responsibleOrganization;
	}
	
	/**
	 * Sets the responsible organization.
	 *
	 * @param responsibleOrganization the new responsible organization
	 */
	public void setResponsibleOrganization(String responsibleOrganization) {
		this.responsibleOrganization = responsibleOrganization;
	}
	
	/**
	 * Gets the requested procedure description.
	 *
	 * @return the requested procedure description
	 */
	public String getRequestedProcedureDescription() {
		return requestedProcedureDescription;
	}
	
	/**
	 * Sets the requested procedure description.
	 *
	 * @param requestedProcedureDescription the new requested procedure description
	 */
	public void setRequestedProcedureDescription(String requestedProcedureDescription) {
		this.requestedProcedureDescription = requestedProcedureDescription;
	}
	
	/**
	 * Gets the requested procedure id.
	 *
	 * @return the requested procedure id
	 */
	public String getRequestedProcedureId() {
		return requestedProcedureId;
	}
	
	/**
	 * Sets the requested procedure id.
	 *
	 * @param requestedProcedureId the new requested procedure id
	 */
	public void setRequestedProcedureId(String requestedProcedureId) {
		this.requestedProcedureId = requestedProcedureId;
	}
	
	/**
	 * Gets the study instance uid.
	 *
	 * @return the study instance uid
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}
	
	/**
	 * Sets the study instance uid.
	 *
	 * @param studyInstanceUID the new study instance uid
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}
	
	/**
	 * Gets the accession number.
	 *
	 * @return the accession number
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}
	
	/**
	 * Sets the accession number.
	 *
	 * @param accessionNumber the new accession number
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}
	
	/**
	 * Gets the other patient id.
	 *
	 * @return the other patient id
	 */
	public String getOtherPatientId() {
		return otherPatientId;
	}
	
	/**
	 * Sets the other patient id.
	 *
	 * @param otherPatientId the new other patient id
	 */
	public void setOtherPatientId(String otherPatientId) {
		this.otherPatientId = otherPatientId;
	}
	
	/**
	 * Gets the other issuer of patient id.
	 *
	 * @return the other issuer of patient id
	 */
	public String getOtherIssuerOfPatientId() {
		return otherIssuerOfPatientId;
	}
	
	/**
	 * Sets the other issuer of patient id.
	 *
	 * @param otherIssuerOfPatientId the new other issuer of patient id
	 */
	public void setOtherIssuerOfPatientId(String otherIssuerOfPatientId) {
		this.otherIssuerOfPatientId = otherIssuerOfPatientId;
	}
	
	/**
	 * Gets the scheduled procedure step id.
	 *
	 * @return the scheduled procedure step id
	 */
	public String getScheduledProcedureStepId() {
		return scheduledProcedureStepId;
	}
	
	/**
	 * Sets the scheduled procedure step id.
	 *
	 * @param scheduledProcedureStepId the new scheduled procedure step id
	 */
	public void setScheduledProcedureStepId(String scheduledProcedureStepId) {
		this.scheduledProcedureStepId = scheduledProcedureStepId;
	}
	
	/**
	 * Gets the scheduled procedure step start date.
	 *
	 * @return the scheduled procedure step start date
	 */
	public Date getScheduledProcedureStepStartDate() {
		return scheduledProcedureStepStartDate;
	}
	
	/**
	 * Sets the scheduled procedure step start date.
	 *
	 * @param scheduledProcedureStepStartDate the new scheduled procedure step start date
	 */
	public void setScheduledProcedureStepStartDate(Date scheduledProcedureStepStartDate) {
		this.scheduledProcedureStepStartDate = scheduledProcedureStepStartDate;
	}
	
	/**
	 * Gets the scheduled procedure step status.
	 *
	 * @return the scheduled procedure step status
	 */
	public String getScheduledProcedureStepStatus() {
		return scheduledProcedureStepStatus;
	}
	
	/**
	 * Sets the scheduled procedure step status.
	 *
	 * @param scheduledProcedureStepStatus the new scheduled procedure step status
	 */
	public void setScheduledProcedureStepStatus(String scheduledProcedureStepStatus) {
		this.scheduledProcedureStepStatus = scheduledProcedureStepStatus;
	}
	
	/**
	 * Gets the modality.
	 *
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}
	
	/**
	 * Sets the modality.
	 *
	 * @param modality the new modality
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}
	
	/**
	 * Gets the external patient id dto.
	 *
	 * @return the external patient id dto
	 */
	public List<ExternalPatientIdDTO> getExternalPatientIdDTO() {
		return externalPatientIdDTO;
	}
	
	/**
	 * Sets the external patient id dto.
	 *
	 * @param externalPatientIdDTO the new external patient id dto
	 */
	public void setExternalPatientIdDTO(List<ExternalPatientIdDTO> externalPatientIdDTO) {
		this.externalPatientIdDTO = externalPatientIdDTO;
	}
	
	public String getRequestingDoctor() {
		return requestingDoctor;
	}
	
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}
	
}
