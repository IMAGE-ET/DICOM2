/**
 * 
 */
package com.idexx.dicom.services.dto.v11;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author vkandagatla
 * 
 */
public abstract class IdexxAuthenticationDTO {
    private String apiKey;

    /**
     * Default Constructor
     */
    public IdexxAuthenticationDTO() {
    }

    /**
     * @param apiKey
     */
    public IdexxAuthenticationDTO(final String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * @return the apiKey
     */
    @XmlElement(nillable = true, required = true)
    public final String getApiKey() {
        return apiKey;
    }

    /**
     * @param apiKey
     *            the apiKey to set
     */
    public final void setApiKey(final String apiKey) {
        this.apiKey = apiKey;
    }
}
