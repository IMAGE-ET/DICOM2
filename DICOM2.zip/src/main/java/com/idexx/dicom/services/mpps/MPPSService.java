package com.idexx.dicom.services.mpps;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.service.DicomServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.MPPSNCreateRepository;
import com.idexx.dicom.repo.MPPSNSetRepository;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.mpps.dto.MPPSNCreateDTO;
import com.idexx.dicom.services.mpps.dto.MPPSNSetDTO;

/**
 * <pre>
 * Service to create and update MPPS request.
 * </pre>
 * 
 * @author sbitla
 * @version 1.3
 */
@Service("mppsService")
public class MPPSService {

    private static final Logger LOG = Logger.getLogger(MPPSService.class);

    @Autowired
    private MPPSNCreateRepository mppsNCreateRepo;

    @Autowired
    private MPPSNSetRepository mppsNSetRepo;

    @Autowired
    private RequestDetailsRepository requestDetailsRepo;

    @Autowired
    @Qualifier("entityMapper")
    EntityMapper entityMapper;

    @Transactional
    public Attributes processMPPSNCreate(Association as, Attributes rq, Attributes rqAttrs, Attributes rsp)
	    throws DicomServiceException {

	boolean checkValidationFailure = validateFields(rqAttrs, rsp);
	if (checkValidationFailure) {
	    return null;
	}

	String mppsSopInstanceUID = rqAttrs.getString(Tag.SOPInstanceUID);
	
	if (StringUtils.isBlank(mppsSopInstanceUID)) {
		mppsSopInstanceUID = rq.getString(Tag.AffectedSOPInstanceUID);
	}
	if (StringUtils.isBlank(mppsSopInstanceUID)) {
		mppsSopInstanceUID = rqAttrs.getString(Tag.AffectedSOPInstanceUID);
	}

	if (StringUtils.isBlank(mppsSopInstanceUID)) {
		mppsSopInstanceUID = generateMPPSInstanceUid();
	}
	
	String patientId = rqAttrs.getString(Tag.PatientID);// optional
	String performedStationAETitle = rqAttrs.getString(Tag.PerformedStationAETitle);// required
	Date performedProcedureStepStartDate = rqAttrs.getDate(Tag.PerformedProcedureStepStartDate);// required

	String performedStationName = rqAttrs.getString(Tag.PerformedStationName);// optional
	String performedLocation = rqAttrs.getString(Tag.PerformedLocation);// optional
	String ppsStatus = rqAttrs.getString(Tag.PerformedProcedureStepStatus);// required
	Attributes scheduledSeq = rqAttrs.getNestedDataset(Tag.ScheduledStepAttributesSequence);// required

	String studyInstanceUID = scheduledSeq.getString(Tag.StudyInstanceUID);// required
	String scheduledProcedureStepID = scheduledSeq.getString(Tag.ScheduledProcedureStepID);// optional
	if (studyInstanceUID == null) {
	    rsp.setInt(Tag.Status, VR.US, 120);
	    rsp.setString(Tag.ErrorComment, VR.LO,
		    "Required attribute Study Instance UID is missing while creating N-CREATE request");
	    LOG.error("Validation failed for MPPS N-CREATE request, Study Instance UID is missing");
	    return null;
	}
	// Check if studyInstanceUID is existing in request details table
	List<RequestDetails> listReqDetails = requestDetailsRepo.findByStudyInstanceUID(studyInstanceUID);
	if (listReqDetails == null || listReqDetails.isEmpty()) {
	    rsp.setInt(Tag.Status, VR.US, 42753);
	    rsp.setString(Tag.ErrorComment, VR.LO, "A request with given Study Instance UID does not exist");
	    LOG.error("A request with given Study Instance UID does not exist");
	    return null;
	}

	MPPSNCreateDTO request = new MPPSNCreateDTO();
	request.setMppsSOPInstanceUID(mppsSopInstanceUID);
	request.setPatientId(patientId);
	request.setPerformedStationAETitle(performedStationAETitle);
	request.setPerformedProcedureStepStartDate(new Timestamp(performedProcedureStepStartDate.getTime()));
	request.setPerformedStationName(performedStationName);
	request.setPerformedLocation(performedLocation);
	request.setPerformedProcedureStepStatus(ppsStatus);
	request.setStudyInstanceUID(studyInstanceUID);
	request.setScheduledProcedureStepId(scheduledProcedureStepID);
	request.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));
	request.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
	try {
	    this.newMPPSNCreate(request);
	} catch (Exception exc) {
	    rsp.setInt(Tag.Status, VR.US, 42753);
	    rsp.setString(Tag.ErrorComment, VR.LO, "Error while processing MPPS-N-CREATE request");
	    LOG.error("Error while processing MPPS-N-CREATE request", exc);
	    return null;
	}

	for (RequestDetails requestDetails : listReqDetails) {
	    requestDetails.setStatus("MPPS_" + ppsStatus);
	    requestDetails.setUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
	    try {
		requestDetailsRepo.save(requestDetails);
	    } catch (Exception exc) {
		LOG.error("Error while updating status in N-SET request: " + exc.getMessage());
		DicomServiceException dEXC = new DicomServiceException(0x0106, exc);
		dEXC.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
		dEXC.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
		rsp.setString(Tag.ErrorComment, VR.LO, exc.getMessage());
		throw dEXC;
	    }
	    LOG.debug("REQUEST_DETAILS status updated for ID : " + requestDetails.getId());
	}

	LOG.debug("MPPS MPPS-N-CREATE request is successfully created");
	rsp.setString(Tag.AffectedSOPInstanceUID, VR.UI, mppsSopInstanceUID);
	if (StringUtils.isNotBlank(rq.getString(Tag.AffectedSOPClassUID, ""))) {
		rsp.setString(Tag.AffectedSOPClassUID, VR.UI, rq.getString(Tag.AffectedSOPClassUID));
	}
	rsp.setInt(Tag.Status, VR.US, 0);
	LOG.debug("Sending 0 status code");
	return null;
    }

	private static String generateMPPSInstanceUid() {
		StringBuffer buffer = new StringBuffer(64);
		return buffer.append(SendImageJobConstants.IDEXX_DICOM_PREFIX).append(".")
				.append(Math.abs(new Random().nextInt(Integer.MAX_VALUE) + 1)).append(".")
				.append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())).toString();
	}

	/**
     * Process MPPS NSet
     * @param as
     * @param rq
     * @param rqAttrs
     * @param rsp
     * @return
     * @throws DicomServiceException
     * 
     */
    @Transactional
    public Attributes processMPPSNSet(Association as, Attributes rq, Attributes rqAttrs, Attributes rsp)
	    throws DicomServiceException {
	String mppsSopInstanceUID = rqAttrs.getString(Tag.SOPInstanceUID);
	if (StringUtils.isBlank(mppsSopInstanceUID)) {
		mppsSopInstanceUID = rq.getString(Tag.RequestedSOPInstanceUID);
	}
	if (StringUtils.isBlank(mppsSopInstanceUID)) {
		mppsSopInstanceUID = rqAttrs.getString(Tag.RequestedSOPInstanceUID);
	}

	MPPSNCreateDTO mppsNCreateDTO = null;
	try {
	    mppsNCreateDTO = findMPPSNCreate(mppsSopInstanceUID);
	} catch (DicomServiceException exc) {
	    exc.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
	    exc.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
	    throw exc;
	}
	if (!"IN PROGRESS".equalsIgnoreCase(mppsNCreateDTO.getPerformedProcedureStepStatus())) {
	    DicomServiceException exc = new DicomServiceException(0x0110,
		    "No matching N-CREATE record for the supplied Sop Instance UID found");
	    exc.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
	    exc.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
	    throw exc;
	}
	LOG.debug("MPPS-N-CREATE request is Found ");
	String ppsStatus = rqAttrs.getString(Tag.PerformedProcedureStepStatus);
	Date performedProcedureStepEndDate = rqAttrs.getDate(Tag.PerformedProcedureStepEndDate);// Optional

	// Update status in MPPS-N-CREATE table
	mppsNCreateDTO.setPerformedProcedureStepStatus(ppsStatus);
	if (performedProcedureStepEndDate != null) {
	    mppsNCreateDTO.setPerformedProcedureStepEndDate(new Timestamp(performedProcedureStepEndDate.getTime()));
	}
	mppsNCreateDTO.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
	try {
	    updateMPPSNCreate(mppsNCreateDTO);
	} catch (Exception exc) {
	    LOG.error("Error while updating status in N-Create request: " + exc.getMessage());
	    DicomServiceException dEXC = new DicomServiceException(42753, exc);
	    dEXC.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
	    dEXC.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
	    rsp.setString(Tag.ErrorComment, VR.LO, exc.getMessage());
	    throw dEXC;
	}
	LOG.debug("MPPS-N-CREATE status updated");

	updateRequestDetailsStatus(rsp, mppsNCreateDTO, ppsStatus);

	createNSet(rqAttrs, rsp, mppsNCreateDTO);

	LOG.debug("MPPS MPPS-N-SET request is successfully processed");
	rsp.setString(Tag.AffectedSOPInstanceUID, VR.UI, mppsSopInstanceUID);
	if (StringUtils.isNotBlank(rq.getString(Tag.RequestedSOPClassUID, ""))) {
		rsp.setString(Tag.AffectedSOPClassUID, VR.UI, rq.getString(Tag.RequestedSOPClassUID));
	}
	rsp.setInt(Tag.Status, VR.US, 0);
	LOG.debug("Sending 0 status code");
	return null;
    }

    /**
     * Saving the record to MPPS-N-Set
     * 
     * @param rqAttrs
     * @param rsp
     * @param mppsNCreateDTO
     * @throws DicomServiceException
     * 
     */
    private void createNSet(Attributes rqAttrs, Attributes rsp, MPPSNCreateDTO mppsNCreateDTO)
	    throws DicomServiceException {
	Attributes performedSeriesSequence = rqAttrs.getNestedDataset(Tag.PerformedSeriesSequence);// optional
	String retrieveAETitle = null;
	String performingPhysicianName = null;
	String protocolName = null;
	String operatorsName = null;
	String seriesInstanceUID = null;
	String seriesDescription = null;
	Sequence referencedImageSequence = null;
	if (performedSeriesSequence != null) {
	    retrieveAETitle = performedSeriesSequence.getString(Tag.RetrieveAETitle);
	    performingPhysicianName = performedSeriesSequence.getString(Tag.PerformingPhysicianName);
	    protocolName = performedSeriesSequence.getString(Tag.ProtocolName);
	    operatorsName = performedSeriesSequence.getString(Tag.OperatorsName);
	    seriesInstanceUID = performedSeriesSequence.getString(Tag.SeriesInstanceUID);
	    seriesDescription = performedSeriesSequence.getString(Tag.SeriesDescription);
	    referencedImageSequence = performedSeriesSequence.getSequence(Tag.ReferencedImageSequence);
	}

	String referencedSOPInstanceUIDs = "";
	if (referencedImageSequence != null) {
	    for (int i = 0; i < referencedImageSequence.size(); i++) {
		Attributes referencedImageSequenceAttributes = referencedImageSequence.get(i);
		String tagValue = referencedImageSequenceAttributes.getString(Tag.ReferencedSOPInstanceUID);
		if (i == 0) {
		    referencedSOPInstanceUIDs = tagValue;
		} else {
		    referencedSOPInstanceUIDs = referencedSOPInstanceUIDs + "," + tagValue;
		}
	    }
	}

	MPPSNSetDTO request = new MPPSNSetDTO();
	request.setMppsNCreateId(mppsNCreateDTO.getId());
	request.setRetrieveAETitle(retrieveAETitle);
	request.setReferencedSOPInstanceUIDs(referencedSOPInstanceUIDs);
	request.setSeriesDescription(seriesDescription);
	request.setPerformingPhysicianName(performingPhysicianName);
	request.setProtocolName(protocolName);
	request.setOperatorsName(operatorsName);
	request.setSeriesInstanceUID(seriesInstanceUID);
	request.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));
	request.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

	try {
	    this.newMPPSNSet(request);
	} catch (Exception exc) {
	    LOG.error("Error while processsing N-SET request", exc);
	    DicomServiceException dEXC = new DicomServiceException(42753, exc);
	    dEXC.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
	    dEXC.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
	    rsp.setString(Tag.ErrorComment, VR.LO, exc.getMessage());
	    throw dEXC;
	}
    }

    /**
     * Update status in REQUEST_DETAILS table
     * 
     * @param rsp
     * @param mppsNCreateDTO
     * @param ppsStatus
     * @throws DicomServiceException
     * 
     */
    private void updateRequestDetailsStatus(Attributes rsp, MPPSNCreateDTO mppsNCreateDTO, String ppsStatus)
	    throws DicomServiceException {

	List<RequestDetails> listReqDetails = requestDetailsRepo
		.findByStudyInstanceUID(mppsNCreateDTO.getStudyInstanceUID());
	if (listReqDetails != null && !listReqDetails.isEmpty()) {
	    for (RequestDetails requestDetails : listReqDetails) {
		requestDetails.setStatus("MPPS_" + ppsStatus);
		requestDetails.setUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
		try {
		    requestDetailsRepo.save(requestDetails);
		} catch (Exception exc) {
		    LOG.error("Error while updating status in N-SET request: " + exc.getMessage());
		    DicomServiceException dEXC = new DicomServiceException(42753, exc);
		    dEXC.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
		    dEXC.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
		    rsp.setString(Tag.ErrorComment, VR.LO, exc.getMessage());
		    throw dEXC;
		}
		LOG.debug("REQUEST_DETAILS status updated for ID : " + requestDetails.getId());
	    }
	}
    }

    /**
     * validate N-Create Request fields
     * 
     * @param rqAttrs
     * @param rsp
     * @return
     * 
     */
    private boolean validateFields(Attributes rqAttrs, Attributes rsp) {

	boolean flagValidateFails = true;

	String performedStationAETitle = rqAttrs.getString(Tag.PerformedStationAETitle);// required
	Date performedProcedureStepStartDate = rqAttrs.getDate(Tag.PerformedProcedureStepStartDate);// required

	String ppsStatus = rqAttrs.getString(Tag.PerformedProcedureStepStatus);// required
	Attributes scheduledSeq = rqAttrs.getNestedDataset(Tag.ScheduledStepAttributesSequence);// required

	if (performedStationAETitle == null) {
	    rsp.setInt(Tag.Status, VR.US, 120);
	    rsp.setString(Tag.ErrorComment, VR.LO,
		    "Required attribute Performed Station AE Title is missing while creating N-CREATE request");
	    LOG.error("Validation failed for MPPS N-CREATE request, Performed Station AE Title is missing");
	    return flagValidateFails;
	}
	if (performedProcedureStepStartDate == null) {
	    rsp.setInt(Tag.Status, VR.US, 120);
	    rsp.setString(Tag.ErrorComment, VR.LO,
		    "Required attribute Performed Procedure Step Start Date is missing while creating N-CREATE request");
	    LOG.error("Validation failed for MPPS N-CREATE request, Performed Procedure Step Start Date is missing");
	    return flagValidateFails;
	}
	if (ppsStatus == null) {
	    rsp.setInt(Tag.Status, VR.US, 120);
	    rsp.setString(Tag.ErrorComment, VR.LO,
		    "Required attribute Performed Procedure Status is missing while creating N-CREATE request");
	    LOG.error("Validation failed for MPPS N-CREATE request, Performed Procedure Status is missing");
	    return flagValidateFails;
	}
	if (scheduledSeq == null) {
	    rsp.setInt(Tag.Status, VR.US, 120);
	    rsp.setString(Tag.ErrorComment, VR.LO,
		    "Required attribute Scheduled Seq is missing while creating N-CREATE request");
	    LOG.error("Validation failed for MPPS N-CREATE request, Scheduled Seq is missing");
	    return flagValidateFails;
	}

	return false;
    }

    /**
     * Saving N-Create record
     * @param createDetails
     * @return
     * 
     */
    public String newMPPSNCreate(MPPSNCreateDTO createDetails) {
	return mppsNCreateRepo.save(entityMapper.dtoToEntityMapper(createDetails)).getId();
    }

    /**
     * Updating N-Create record
     * @param createDetails
     * 
     */
    public void updateMPPSNCreate(MPPSNCreateDTO createDetails) {
	mppsNCreateRepo.save(entityMapper.dtoToEntityMapper(createDetails));
    }

    /**
     * Finding N-create record to process
     * @param mppsSopInstanceUID
     * @return
     * @throws DicomServiceException
     * 
     */
    public MPPSNCreateDTO findMPPSNCreate(String mppsSopInstanceUID) throws DicomServiceException {
	List<MPPSNCreate> list = mppsNCreateRepo.findByMppsSOPInstanceUID(mppsSopInstanceUID);
	if (list == null || list.isEmpty()) {
	    throw new DicomServiceException(0x0110, "No N-CREATE request found for the supplied Sop Instance UID");
	}
	if (list.size() > 1) {
	    throw new DicomServiceException(0x0110,
		    "Multiple N-CREATE requests found for the supplied Sop Instance UID");
	}
	return entityMapper.entityToDTOMapper(list.get(0));
    }

    /**
     * Creating new N-Set record
     * @param setDetails
     * @return
     * 
     */
    public String newMPPSNSet(MPPSNSetDTO setDetails) {
	return mppsNSetRepo.save(entityMapper.dtoToEntityMapper(setDetails)).getId();
    }
}
