package com.idexx.dicom.services.dto.v12;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

public class SetAssumedIssuerDTO extends IdexxAuthenticationDTO {

    private String sapId;

    private String assumedIssuerValue;
    
    @XmlElement(required = true)
    public final String getSapId() {
        return sapId;
    }
    
    public final void setSapId(final String sapId) {
        this.sapId = StringUtils.trimToNull(sapId);
    }
    
    @XmlElement(required = true)
    public final String getAssumedIssuerValue() {
        return assumedIssuerValue;
    }
    
    public final void setAssumedIssuerValue(final String assumedIssuerValue) {
        this.assumedIssuerValue = StringUtils.trimToNull(assumedIssuerValue);
    }
}
