/**
 * 
 */
package com.idexx.dicom.services.dto.v12;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

/**
 * @author vkandagatla
 * 
 */
public class ReadAETitleDTO extends AETitleDTO {
    private String sapId;

    /**
     * @return the sapId
     */
    @XmlElement(nillable = true, required = true)
    public final String getSapId() {
        return sapId;
    }

    /**
     * @param sapId
     *            the sapId to set
     */
    public final void setSapId(final String sapId) {
        this.sapId = StringUtils.trimToNull(sapId);
    }
}
