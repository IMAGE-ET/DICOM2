/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v13;


/**
 * @author nayeemuddin
 *
 */
public class CancelSendJobParamDTO {
	 
	 private String jobId;
	 private String jobStatusDescription;
	 
	/**
	 * @return the jobId
	 */
	  
	public String getJobId() {
		return jobId;
	}
	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	/**
	 * @return the jobStatusDescription
	 */
	public String getJobStatusDescription() {
		return jobStatusDescription;
	}
	/**
	 * @param jobStatusDescription the jobStatusDescription to set
	 */
	public void setJobStatusDescription(String jobStatusDescription) {
		this.jobStatusDescription = jobStatusDescription;
	}
	 
	 

}
