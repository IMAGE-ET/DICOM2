package com.idexx.dicom.services.dto.v13;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;


public class ReadAssumedIssuerDTO extends IdexxAuthenticationDTO {

    private String sapId;

    @XmlElement(required = true)
    public final String getSapId() {
        return sapId;
    }
    
    public final void setSapId(final String sapId) {
        this.sapId = StringUtils.trimToNull(sapId);
    }
}
