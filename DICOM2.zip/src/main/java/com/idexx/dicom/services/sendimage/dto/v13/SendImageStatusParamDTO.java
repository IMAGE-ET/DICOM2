/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v13;

import java.util.List;

import com.idexx.dicom.services.dto.v13.IdexxAuthenticationDTO;


/**
 * @author nayeemuddin
 *
 */

public class SendImageStatusParamDTO extends IdexxAuthenticationDTO {
	
	private List<String> jobId;
    
    
	/**
	 * Default Constructor
	 */
	public SendImageStatusParamDTO(){
	}
	
	/**
	 * 
	 * @param apiKey form Super Class
	 */
	public SendImageStatusParamDTO(final String apiKey){
		super(apiKey);
	}
	
	/**
	 * 
	 * @param apiKey
	 * @param jobId
	 */
	public SendImageStatusParamDTO(final String apiKey, final List<String>jobId){
		this(apiKey);
		this.jobId = jobId;
	}

	/**
	 * @return the jobId
	 */
	public List<String> getJobId() {
		return jobId;
	}

	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(List<String> jobId) {
		this.jobId = jobId;
	}
	
}
