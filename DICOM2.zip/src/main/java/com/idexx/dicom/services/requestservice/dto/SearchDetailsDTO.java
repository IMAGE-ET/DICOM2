package com.idexx.dicom.services.requestservice.dto;

import java.util.Date;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class SearchDetailsDTO.
 *
 * @author rkaranam
 * @version 1.3
 */
public class SearchDetailsDTO {

	/** The patient name. */
	private String patientName;

	/** The patient id. */
	private String patientId;

	/** The modalities. */
	private List<String> modalities;

	/** The start date. */
	private Date startDate;

	/** The end date. */
	private Date endDate;

	/** The status. */
	private List<String> status;

	/** The sap id. */
	private String sapId;

	/**
	 * Gets the patient name.
	 *
	 * @return the patient name
	 */
	public String getPatientName() {
		return patientName;
	}

	/**
	 * Sets the patient name.
	 *
	 * @param patientName
	 *            the new patient name
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	/**
	 * Gets the patient id.
	 *
	 * @return the patient id
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * Sets the patient id.
	 *
	 * @param patientId
	 *            the new patient id
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	/**
	 * Gets the modalities.
	 *
	 * @return the modalities
	 */
	public List<String> getModalities() {
		return modalities;
	}

	/**
	 * Sets the modalities.
	 *
	 * @param modalities
	 *            the new modalities
	 */
	public void setModalities(List<String> modalities) {
		this.modalities = modalities;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate
	 *            the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate
	 *            the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public List<String> getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status
	 *            the new status
	 */
	public void setStatus(List<String> status) {
		this.status = status;
	}

	/**
	 * Gets the sap id.
	 *
	 * @return the sap id
	 */
	public String getSapId() {
		return sapId;
	}

	/**
	 * Sets the sap id.
	 *
	 * @param sapId
	 *            the new sap id
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

}
