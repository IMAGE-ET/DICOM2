package com.idexx.dicom.services.dto.v11;

import org.apache.commons.lang.StringUtils;

public class EchoDTO {

    private String aeTitle;
    private String hostName;
    private int portNumber;
    private String calledAeTitle;

    public String getCalledAeTitle() {
        return calledAeTitle;
    }

    public void setCalledAeTitle(String calledAeTitle) {
        this.calledAeTitle = calledAeTitle;
    }

    public String getAeTitle() {
        return aeTitle;
    }

    public void setAeTitle(String aeTitle) {
        this.aeTitle = aeTitle;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public int getPortNumber() {
        return portNumber;
    }

    public void setPortNumber(int portNumber) {
        this.portNumber = portNumber;
    }
    
    public boolean isEmpty() {
        if (StringUtils.isEmpty(this.getCalledAeTitle())) {
            return true;
        }

        if (StringUtils.isEmpty(this.getAeTitle())) {
            return true;
        }

        if (StringUtils.isEmpty(this.getHostName())) {
            return true;
        }

        if (this.getPortNumber() <= 0) {
            return true;
        }

        return false;
    }
}
