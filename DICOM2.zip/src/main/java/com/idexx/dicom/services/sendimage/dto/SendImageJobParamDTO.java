/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto;

import javax.xml.bind.annotation.XmlElement;

import com.idexx.dicom.services.dto.IdexxAuthenticationDTO;
/**
 * @author vkandagatla
 * 
 */
public class SendImageJobParamDTO extends IdexxAuthenticationDTO {
    private String destinationAETitle;
    private String destinationHost;
    private int destinationPort;
    private String imageAssetId;
    private String sendingAETitle;
    
    /**
     * Default Constructor
     */
    public SendImageJobParamDTO() {
    }
    
    /**
     * @param destinationAETitle
     * @param destinationHostName
     * @param destinationPort
     * @param imageAssetId
     * @param sendingAETitle
     */
    public SendImageJobParamDTO(final String destinationAETitle,
            final String destinationHostName,
            final int destinationPort,
            final String imageAssetId,
            final String sendingAETitle,
            final String apiKey) {
        super(apiKey);
        this.destinationAETitle = destinationAETitle;
        this.destinationHost = destinationHostName;
        this.destinationPort = destinationPort;
        this.imageAssetId = imageAssetId;
        this.sendingAETitle = sendingAETitle;
    }
    
    /**
     * @return the destinationAETitle
     */
    @XmlElement(nillable = true, required = true)
    public final String getDestinationAETitle() {
        return destinationAETitle;
    }
    
    /**
     * @param destinationAETitle
     *            the destinationAETitle to set
     */
    public final void setDestinationAETitle(final String destinationAETitle) {
        this.destinationAETitle = destinationAETitle;
    }
    
    /**
     * @return the destinationHost
     */
    public final String getDestinationHost() {
        return destinationHost;
    }
    
    /**
     * @param destinationHostName
     *            the destinationHost to set
     */
    public final void setDestinationHost(final String destinationHostName) {
        this.destinationHost = destinationHostName;
    }
    
    /**
     * @return the destinationPort
     */
    public final int getDestinationPort() {
        return destinationPort;
    }
    
    /**
     * @param destinationPort
     *            the destinationPort to set
     */
    public final void setDestinationPort(final int destinationPort) {
        this.destinationPort = destinationPort;
    }
    
    /**
     * @return the imageAssetId
     */
    public final String getImageAssetId() {
        return imageAssetId;
    }
    
    /**
     * @param imageAssetId
     *            the imageAssetId to set
     */
    public final void setImageAssetId(final String imageAssetId) {
        this.imageAssetId = imageAssetId;
    }
    
    /**
     * @return the sendingAETitle
     */
    public final String getSendingAETitle() {
        return sendingAETitle;
    }
    
    /**
     * @param sendingAETitle
     *            the sendingAETitle to set
     */
    public final void setSendingAETitle(final String sendingAETitle) {
        this.sendingAETitle = sendingAETitle;
    }
    
}
