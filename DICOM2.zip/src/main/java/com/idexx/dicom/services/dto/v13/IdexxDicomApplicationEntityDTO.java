/**
 * 
 */
package com.idexx.dicom.services.dto.v13;

import java.sql.Timestamp;

/**
 * <pre>IdexxDicomApplicationEntityDTO hold information About AETitle enabled state,createdDateTime,lastAccessed and identifiedByAeTitleOnly</pre>
 * @author smallela
 * @version 1.3
 */
public class IdexxDicomApplicationEntityDTO extends ReadAETitleDTO {

    private boolean enabled;

    private String createdDateTime;

    private String lastAccessed;

    private boolean identifiedByAeTitleOnly;

    /**
     * @return the identifiedByAeTitleOnly
     */
    public boolean isIdentifiedByAeTitleOnly() {
        return identifiedByAeTitleOnly;
    }

    /**
     * @param identifiedByAeTitleOnly
     *            the identifiedByAeTitleOnly to set
     */
    public void setIdentifiedByAeTitleOnly(final boolean identifiedByAeTitleOnly) {
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
    }

    public IdexxDicomApplicationEntityDTO() {
        enabled = true;
    }

    /**
     * @return the enabled
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled
     *            the enabled to set
     */
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }

    public String getCreatedDateTime() {
        return createdDateTime;
    }

    public  void setCreatedDateTime(final String createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public  void setCreatedDateTime(final Timestamp createdDateTime) {
        final int lengthOfString = 19;
        this.createdDateTime = createdDateTime.toString().substring(0, lengthOfString);
    }

    public  String getLastAccessed() {
        return lastAccessed;
    }

    public  void setLastAccessed(final String lastAccessed) {
        this.lastAccessed = lastAccessed;
    }

    public  void setLastAccessed(final Timestamp lastAccessed) {
        this.lastAccessed = lastAccessed.toString();
    }
}
