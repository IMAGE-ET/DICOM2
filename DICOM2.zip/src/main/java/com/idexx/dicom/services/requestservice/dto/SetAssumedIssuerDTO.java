package com.idexx.dicom.services.requestservice.dto;

import javax.xml.bind.annotation.XmlElement;


public class SetAssumedIssuerDTO extends IdexxAuthenticationDTO {

    private String sapId;

    private String assumedIssuerValue;
    
    @XmlElement(required = true)
    public final String getSapId() {
        return sapId;
    }
    
    public final void setSapId(final String sapId) {
        this.sapId = sapId;
    }
    
    @XmlElement(required = true)
    public final String getAssumedIssuerValue() {
        return assumedIssuerValue;
    }
    
    public final void setAssumedIssuerValue(final String assumedIssuerValue) {
        this.assumedIssuerValue = assumedIssuerValue;
    }
}