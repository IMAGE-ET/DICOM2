/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v12;

/**
 * @author vkandagatla
 * 
 */
public class AbstractIdexxSendImageJobDTO {
    private String jobId;
    private String jobStatusCode;
    private String jobStatusDescription;
    
    /**
     * Default Constructor
     */
    public AbstractIdexxSendImageJobDTO() {
    }
    
    /**
     * @param jobId
     * @param jobStatusCode
     * @param jobStatusDescription
     */
    public AbstractIdexxSendImageJobDTO(final String jobId,
            final String jobStatusCode,
            final String jobStatusDescription) {
        this.jobId = jobId;
        this.jobStatusCode = jobStatusCode;
        this.jobStatusDescription = jobStatusDescription;
    }
    
    /**
     * @return the jobId
     */
    public final String getJobId() {
        return jobId;
    }
    
    /**
     * @param jobId
     *            the jobId to set
     */
    public final void setJobId(final String jobId) {
        this.jobId = jobId;
    }
    
    /**
     * @return the jobStatusCode
     */
    public final String getJobStatusCode() {
        return jobStatusCode;
    }
    
    /**
     * @param jobStatusCode
     *            the jobStatusCode to set
     */
    public final void setJobStatusCode(final String jobStatusCode) {
        this.jobStatusCode = jobStatusCode;
    }
    
    /**
     * @return the jobStatusDescription
     */
    public final String getJobStatusDescription() {
        return jobStatusDescription;
    }
    
    /**
     * @param jobStatusDescription
     *            the jobStatusDescription to set
     */
    public final void setJobStatusDescription(final String jobStatusDescription) {
        this.jobStatusDescription = jobStatusDescription;
    }
}
