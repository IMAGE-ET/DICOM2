/**
 * @author nayeemuddin
 *
 */
package com.idexx.dicom.services.sendimage.dto.v13;