/**
 * 
 */
package com.idexx.dicom.services.dto.v13;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

/**
 * <pre>CreateAETitleDTO hold information About identifiedByAeTitleOnly,hostName,port and dvmSpecialist</pre>
 * @author smallela
 * @version 1.3
 */
public class CreateAETitleDTO extends ReadAETitleDTO {

    private boolean identifiedByAeTitleOnly;

    private String hostName;

    private int port;

    private boolean dvmSpecialist = false;

    /**
     * @return the dvmSpecialist
     */
    @XmlElement(nillable = true, required = true)
    public boolean isDvmSpecialist() {
        return dvmSpecialist;
    }

    /**
     * @param dvmSpecialist
     *            the dvmSpecialist to set
     */
    public void setDvmSpecialist(final boolean dvmSpecialist) {
        this.dvmSpecialist = dvmSpecialist;
    }

    /**
     * @return the hostName
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * @param hostName
     *            the hostName to set
     */
    public void setHostName(final String hostName) {
        this.hostName = StringUtils.trimToNull(hostName);
    }

    /**
     * @return the port
     */
    public int getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public void setPort(final int port) {
        this.port = port;
    }

    /**
     * @return the identifiedByAeTitleOnly
     */
    @XmlElement(nillable = true, required = true)
    public boolean isIdentifiedByAeTitleOnly() {
        return identifiedByAeTitleOnly;
    }

    /**
     * @param identifiedByAeTitleOnly
     *            the identifiedByAeTitleOnly to set
     */
    public void setIdentifiedByAeTitleOnly(final boolean identifiedByAeTitleOnly) {
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
    }
}
