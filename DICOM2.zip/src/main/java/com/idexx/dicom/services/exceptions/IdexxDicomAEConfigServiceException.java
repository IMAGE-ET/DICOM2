/**
 * 
 */
package com.idexx.dicom.services.exceptions;

import javax.xml.soap.SOAPException;

/**
 * @author vkandagatla
 * 
 */
public class IdexxDicomAEConfigServiceException extends SOAPException {

    /**
     * 
     */
    private static final long serialVersionUID = -6396673933902121952L;
    private String errorCode;

    public IdexxDicomAEConfigServiceException() {
        super();
    }

    public IdexxDicomAEConfigServiceException(final Throwable cause) {
        super(cause);
    }

    public IdexxDicomAEConfigServiceException(final String message) {
        super(message);
    }

    public IdexxDicomAEConfigServiceException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public IdexxDicomAEConfigServiceException(final String message, final String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public IdexxDicomAEConfigServiceException(final Throwable cause, final String errorCode) {
        super(cause);
        this.errorCode = errorCode;
    }

    public IdexxDicomAEConfigServiceException(final String message, final Throwable cause, final String errorCode) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public final String getErrorCode() {
        return errorCode;
    }

    public final void setErrorCode(final String errorCode) {
        this.errorCode = errorCode;
    }
}
