package com.idexx.dicom.dao.query;

public interface QueryBuilder {
	String getSelectQuery(String aeTitle, String instituteName, String errorType);
}
