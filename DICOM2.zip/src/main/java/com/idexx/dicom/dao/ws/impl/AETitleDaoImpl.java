/**
 * Database Paeristance for AE Title Related CRUD Operations.
 * Every Method will throw a run time exception IdexxDicomAEConfigDbException
 * Because, A functional requirement is explicitly stating, the software need to show DB related exceptions.
 */
package com.idexx.dicom.dao.ws.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;

/**
 * @author vkandagatla
 * 
 */
@Repository
@SuppressWarnings("unchecked")
public class AETitleDaoImpl implements AETitleDao {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(AETitleDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	private static final String AET_PARAM1 = "AETITLE";
	private static final String AET_PARAM2 = "INSTITUTE_NAME";
	private static final String AET_PARAM3 = "SAP_ID";
	private static final String AET_PARAM4 = "API_KEY";
	private static final String AET_PARAM5 = "aet";
	private static final String AET_PARAM6 = "MODALITY_TYPE_CODE";
	private static final String QUERY_ALL_AE_TITLES = "SELECT AET FROM AETitle AET";
	private static final String QUERY_PREFIX = "SELECT AET FROM AETitle AET WHERE AET.aeTitle=:";
	private static final String QUERY_PREFIX_AE = "SELECT AE FROM AEEntity AE WHERE AE.aeTitle=:";

	public AETitleDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public AETitleDaoImpl() {
		super();
	}

	@Override
	public List<AETitle> getAllAETitles() {
		try {
			Query query = entityManager.createQuery(QUERY_ALL_AE_TITLES);
			query.setMaxResults(Integer.MAX_VALUE);
			return query.getResultList();
		} catch (Exception e) {
			throw new IdexxDicomAEConfigDbException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitle(final String aeTitle) {
		try {
			final String query = QUERY_PREFIX + AET_PARAM1;
			return entityManager.createQuery(query).setParameter("AETITLE", aeTitle).getResultList();
		} catch (Exception e) {
			throw new IdexxDicomAEConfigDbException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitle(final String aeTitle, final String instituteName) {
		try {
			final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.instituteName=:" + AET_PARAM2;
			return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle)
					.setParameter(AET_PARAM2, instituteName).getResultList();
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitle(final String aeTitle, final String instituteName, final String sapId) {
		try {
			final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.instituteName=:" + AET_PARAM2
					+ " AND AET.sapId=:SAP_ID";
			return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle)
					.setParameter(AET_PARAM2, instituteName).setParameter(AET_PARAM3, sapId).getResultList();
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#findAE(java.lang.String)
	 */
	@Override
	public List<AEEntity> findAE(final String aeTitle) {
		try {
			final String query = QUERY_PREFIX_AE + AET_PARAM5;
			return entityManager.createQuery(query).setParameter(AET_PARAM5, aeTitle).getResultList();
		} catch (Exception e) {
			throw new IdexxDicomAEConfigDbException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#createAETitle(com.idexx.dicom.ae.
	 * entities .AETitle)
	 */
	@Override
	public void createAETitle(final AETitle aeTitle) {
		try {
			entityManager.merge(aeTitle);
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#createAE(com.idexx.dicom.ae.entities
	 * .AEEntity)
	 */
	@Override
	public void createAE(final AEEntity aeEntity) {
		try {
			entityManager.persist(aeEntity);
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#deleteAETitle(com.idexx.dicom.ae.
	 * entities .AETitle)
	 */
	@Override
	public void deleteAETitle(final AETitle aeTitle) {
		try {
			entityManager.remove(aeTitle);
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.dao.ws.AETitleDao#updateAETitle(com.idexx.dicom.ae.
	 * entities .AETitle)
	 */
	@Override
	public void updateAETitle(final AETitle aeTitle) {
		try {
			entityManager.merge(aeTitle);
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#getInvalidAETitle(java.lang.String)
	 */
	@Override
	public IdexxInvalidAE getInvalidAETitle(final String aeTitle) {
		IdexxInvalidAE iae = null;
		try {
			final String query = "SELECT AET FROM IdexxInvalidAE AET WHERE AET.aeTitle=:" + AET_PARAM1;
			iae = (IdexxInvalidAE) entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle).getSingleResult();
		} catch (NoResultException e) {
			LOG.error("NoResultException in getInvalidAETitle: " + e);
			iae = null;
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
		return iae;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#getInvalidAETitle(java.lang.String)
	 */
	@Override
	public IdexxAPIKey getIdexxAPIKey(final String apiKey) {
		IdexxAPIKey apiKeyObj = null;
		try {
			final String query = "SELECT IAPI FROM IdexxAPIKey IAPI WHERE IAPI.apiKey=:" + AET_PARAM4;
			apiKeyObj = (IdexxAPIKey) entityManager.createQuery(query).setParameter(AET_PARAM4, apiKey)
					.getSingleResult();
		} catch (NoResultException e) {
			LOG.error("NoResultException in getIdexxAPIKey: " + e);
			apiKeyObj = null;
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
		return apiKeyObj;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitleByAETitleAndSapId(final String aeTitle, final String sapId) {
		try {
			final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.sapId=:" + AET_PARAM3;
			return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle).setParameter(AET_PARAM3, sapId)
					.getResultList();
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitleBySapIdAndInstituteName(final String sapId, final String instituteName) {
		try {
			final String query = "SELECT AET FROM AETitle AET WHERE AET.instituteName=:" + AET_PARAM2
					+ " AND AET.sapId=:" + AET_PARAM3;
			return entityManager.createQuery(query).setParameter(AET_PARAM2, instituteName)
					.setParameter(AET_PARAM3, sapId).getResultList();
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}
	
	@Override
	public List<ErrorDTO> validateSapIdAndModality(final String sapId, final String modalityTypeCode) {
		List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
		List<AETitle> aeTitleList = new ArrayList<AETitle>();
		try {
			final String query = "SELECT AET FROM AETitle AET WHERE AET.modalityTypeCode=:" + AET_PARAM6
					+ " AND AET.sapId=:" + AET_PARAM3;
			aeTitleList = entityManager.createQuery(query).setParameter(AET_PARAM6, modalityTypeCode)
					.setParameter(AET_PARAM3, sapId).getResultList();
			if (aeTitleList.isEmpty()) {
				listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.UNREGISTERED_MODALITY_ERROR_CODE,
						CreateRequestErrorCodesConstants.UNREGISTERED_MODALITY_ERROR_CODE_MSG));
			}
		} catch (Exception e) {
			listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.UNREGISTERED_MODALITY_ERROR_CODE,
					CreateRequestErrorCodesConstants.UNREGISTERED_MODALITY_ERROR_CODE_MSG));
		}
		return listOfErrors;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public List<AETitle> findAETitleBySapId(final String sapId) {
		try {
			final String query = "SELECT AET FROM AETitle AET WHERE AET.sapId=:" + AET_PARAM3;
			return entityManager.createQuery(query).setParameter(AET_PARAM3, sapId).getResultList();
		} catch (Exception e) {

			throw new IdexxDicomAEConfigDbException(e);
		}
	}

}
