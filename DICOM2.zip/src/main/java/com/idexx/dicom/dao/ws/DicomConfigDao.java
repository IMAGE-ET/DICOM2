/**
 * DAO for dicom configuration
 */
package com.idexx.dicom.dao.ws;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;

/**
 * @author vkandagatla
 * 
 */
public interface DicomConfigDao {
    
    BaseDicomImPluginConfig getConfig(String configName);
}
