/**
 * DAO for Failure Service
 */
package com.idexx.dicom.dao.ws.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.dao.query.QueryBuilder;
import com.idexx.dicom.dao.query.impl.QueryBuilderImpl;
import com.idexx.dicom.dao.ws.FailureServiceDao;

/**
 * @author anarayana
 * 
 */
@Repository
@SuppressWarnings("unchecked")
public class FailureServiceDaoImpl implements FailureServiceDao {
	
	private static final Logger LOG = Logger.getLogger(FailureServiceDaoImpl.class);
	
    @PersistenceContext
    private EntityManager entityManager;
    
    private static final String FAILURE_LOG_QUERY = "FROM IdexxDicomServiceFailureLog IDFL WHERE "
            + "IDFL.failedDateTime >= :START_DATE "
            + "AND IDFL.failedDateTime <= :END_DATE";

    private static final int MAX_RECORDS = 500;
    /*
     * @see
     * com.idexx.dicom.dao.ws.FailureServiceDao#getFailureLog(java.lang.String,
     * java.util.Date, java.util.Date)
     */
    @Override
    public List<IdexxDicomServiceFailureLog> getFailureLog(
            final Date startDate,
            final Date endDate) {
        LOG.info( "Getting AE Authorization Failure LOGs from table: idx_failure_log::Start Date: " 
            + startDate + " ::: END Date:" + endDate);
        return entityManager.createQuery(FAILURE_LOG_QUERY)
                .setParameter("START_DATE", startDate)
                .setParameter("END_DATE", endDate).getResultList();
    }

    /*
     * @see 
     * com.idexx.dicom.dao.ws.FailureServiceDao#getFailureLog(java.util.Date, java.util.Date, 
     * java.lang.String, java.lang.String)
     * 
     */
    @Override
    public List<IdexxDicomServiceFailureLog> getFailureLogErrorMessages (
            final Date startDate,
            final Date endDate,
    		final String aeTitle,
    		final String instituteName,
    		final String errorType) {
		LOG.info( "Getting Failure LOGs from table: idx_failure_log::Start Date: " 
	            + startDate + " ::: END Date:" + endDate + " ::: AE_TITLE:" + aeTitle + " ::: INSTITUTE NAME:" + instituteName);
		QueryBuilder queryBuilder = new QueryBuilderImpl();
		
		Query query = entityManager.createQuery(queryBuilder.getSelectQuery(aeTitle, instituteName, errorType));
		query.setMaxResults(MAX_RECORDS);
		query.setParameter("START_DATE", startDate);
		query.setParameter("END_DATE", endDate);
		
		if (!StringUtils.isEmpty(errorType)) {
			query.setParameter("ERROR_TYPE", errorType);
		}
		
		if (!StringUtils.isEmpty(aeTitle)) {
			query.setParameter("AE_TITLE", aeTitle);
		}
		
		if (!StringUtils.isEmpty(instituteName)) {
			query.setParameter("INSTITUTE_NAME", instituteName);
		}
		
		return query.getResultList();
	}

}
