/**
 * DAO Implementation for Dicom Image Send Services
 */
package com.idexx.dicom.dao.ws.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;

/**
 * @author anarayana
 *
 */
@Repository
public class IdexxSendImageJobDaoImpl implements IdexxSendImageJobDao {
    
	private static final Logger LOG = Logger.getLogger(IdexxSendImageJobDaoImpl.class);
	
    @PersistenceContext
    private EntityManager entityManager;
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.IdexxSendImageJobDao#createJob(com.idexx.dicom
     * .ae.entities.IdexxSendImageJob)
     */
    @Override
    public String createJob(final IdexxSendImageJob job) {
        try {
            Timestamp ts = new Timestamp(System.currentTimeMillis());
            job.setCreatedDateTime(ts);
            entityManager.persist(job);
        } catch (Exception exp) {
            LOG.error(exp.getLocalizedMessage(), exp);
            throw new IdexxDicomAEConfigDbException(exp);
        }
        return job.getJobId();
    }
    
    
    /* (non-Javadoc)
     * @see com.idexx.dicom.dao.ws.IdexxSendImageJobDao#cancelSendJob(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String cancelSendJob(final IdexxSendImageJob cancelSendJob) {
        String message = "update successful";
       try {
           Timestamp ts = new Timestamp(System.currentTimeMillis());
           cancelSendJob.setCreatedDateTime(ts);
           entityManager.persist(cancelSendJob);
       } catch (Exception exp) {
           LOG.error(exp.getLocalizedMessage(), exp);
           throw new IdexxDicomAEConfigDbException(exp);
       }
       return message;
   }
    
    private static final String GET_JOBS_HQL = "SELECT JOB FROM IdexxSendImageJob JOB WHERE "
            + " JOB.jobId in (:JOBS)";
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.IdexxSendImageJobDao#getJob(java.util.List)
     */
    @Override
    public List<IdexxSendImageJob> getJob(final List<String> jobs) {
        @SuppressWarnings("unchecked")
        List<IdexxSendImageJob> jobBeans = (List<IdexxSendImageJob>) entityManager.createQuery(GET_JOBS_HQL)
                .setParameter("JOBS", jobs).getResultList();
        return jobBeans;
    }
    
}
