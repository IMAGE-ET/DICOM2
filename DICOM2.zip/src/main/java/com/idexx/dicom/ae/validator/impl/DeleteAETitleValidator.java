/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v11.CreateAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service("deleteAETitleValidator")
public class DeleteAETitleValidator extends AbstractAETitleValidator {
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(CreateAETitleValidator.class);

	@Autowired
	private AETitleDao aeTitleDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator#
	 * validateInputFields
	 * (com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */
	@Override
	protected final int validateInputFields(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
		if (StringUtils.isEmpty(dto.getAeTitle())) {
			throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);
		}

		return 1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator#
	 * validateDBFields
	 * (com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */
	@Override
	protected final int validateDBFields(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
		try {
			if (!isAETitleExistWithIdentifiedByAETitleOnly(dto.getAeTitle())) {
				if (StringUtils.isEmpty(dto.getInstituteName())) {
					throw new IdexxDicomAEConfigServiceException(MISSING_INSTITUTE_NAME, MISSING_INSTITUTE_NAME);
				} else if (!isAETitleExistWithInstituteName(dto.getAeTitle(), dto.getInstituteName())) {
					throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND, NO_RECORD_FOUND);
				}

			}

		} catch (IdexxDicomAEConfigDbException e) {
			LOG.error("Exception in validateDBFields: " + e);
			throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE);
		}
		return 1;
	}

	private boolean isAETitleExistWithIdentifiedByAETitleOnly(final String aeTitle)
			throws IdexxDicomAEConfigServiceException {
		boolean isExists = false;
		List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle);
		if (null == registeredAEList || registeredAEList.isEmpty()) {
			throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND, NO_RECORD_FOUND);
		}
		if ((registeredAEList.size() == 1) && (registeredAEList.get(0)).isIdentifiedByaeTitleOnly()) {
			isExists = true;
		}
		return isExists;
	}

	private boolean isAETitleExistWithInstituteName(final String aeTitle, final String institute) {
		boolean isExists = false;
		List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle, institute);
		if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
			isExists = true;
		}
		return isExists;
	}
}
