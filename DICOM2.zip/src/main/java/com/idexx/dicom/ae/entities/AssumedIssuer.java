package com.idexx.dicom.ae.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ASSUMED_ISSUER")
public class AssumedIssuer implements Serializable {

    private static final long serialVersionUID = 233280507738380671L;

    private String sapId;

    private String assumedIssuerValue;
    
    private Timestamp createdDateTime;

    private Timestamp lastUpdatedDateTime;


    /**
     * @return the sapId
     */
    @Id
    @Column(name = "SAP_ID")
    public String getSapId() {
        return sapId;
    }

    /**
     * @param sapId the sapId to set
     */
    public void setSapId(final String sapId) {
        this.sapId = sapId;
    }

    /**
     * @return the assumedIssuerValue
     */
    @Column(name = "ASSUMED_ISSUER_VALUE")
    public String getAssumedIssuerValue() {
        return assumedIssuerValue;
    }

    /**
     * @param assumedIssuerValue the assumedIssuerValue to set
     */
    public void setAssumedIssuerValue(final String assumedIssuerValue) {
        this.assumedIssuerValue = assumedIssuerValue;
    }

    /**
     * @return the createdDateTime
     */
    @Column(name = "CREATED_DATE_TIME")
    public Timestamp getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * @param createdDateTime
     *            the createdDateTime to set
     */
    public void setCreatedDateTime(final Timestamp createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    /**
     * @return the lastUpdatedDateTime
     */
    @Column(name = "LAST_UPDATED_DATE_TIME")
    public Timestamp getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    /**
     * @param lastUpdatedDateTime the lastUpdatedDateTime to set
     */
    public void setLastUpdatedDateTime(final Timestamp lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }
}
