package com.idexx.dicom.ae.validator.v12;

import com.idexx.dicom.ae.validator.IdexxValidator;
import com.idexx.dicom.services.dto.v12.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

public interface StoreErrorLogValidator extends IdexxValidator {
	boolean validate(IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
