/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * @author vkandagatla
 * 
 */
@Service("idexxSendImageStatusValidator")
public class IdexxSendImageStatusValidatorImpl implements IdexxSendImageStatusValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator
     * 
     * #validate(com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO)
     */
    @Override
    public final int validate(final SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getApiKey())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        if (StringUtils.isEmpty(dto.getJobId())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        
        if (dto.getJobId().size() == 1 && StringUtils.isEmpty(dto.getJobId().get(0))) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        return 1;
    }
    
}
