/**
 * 
 */
package com.idexx.dicom.ae.validator;

import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface StoreFailureServiceValidator extends IdexxValidator {
    
    int validate(IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
