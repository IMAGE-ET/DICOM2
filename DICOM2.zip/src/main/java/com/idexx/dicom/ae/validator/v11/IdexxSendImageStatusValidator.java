/**
 * 
 */
package com.idexx.dicom.ae.validator.v11;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface IdexxSendImageStatusValidator extends IdexxValidator {

    int validate(SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
