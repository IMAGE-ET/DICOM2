/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v13;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>ReadAETitleValidator Implementation to check input parameters for Read AETitle web Service</pre>
 * @author smallela
 * @version 1.3
 */

@Service("readAETitleValidatorV13")
public class ReadAETitleValidator extends AbstractAETitleValidator {
    
	/**
     * <pre>this method validates InputFields(AeTitle and SapId are empty or not) for Read AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */ 
	
    @Override
    protected final int validateInputFields(final AETitleDTO dto)
            throws IdexxDicomAEConfigServiceException {
        ReadAETitleDTO readDTO = (ReadAETitleDTO) dto;
        if (StringUtils.isEmpty(readDTO.getAeTitle())
                && StringUtils.isEmpty(readDTO.getSapId())) {
            throw new IdexxDicomAEConfigServiceException(
                    "Mandatory input missing", MISSING_MANDATORY);
        }
        
        return 1;
    }
    
    /**
     * @param dto
     * @return int
     *  
     */   
    @Override
    protected final int validateDBFields(final AETitleDTO dto) {
        // No DB validation needed
        return 1;
    }
    
}
