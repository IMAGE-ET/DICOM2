/**
 * Validate the mandatory parameter JobId from the request.
 */
package com.idexx.dicom.ae.validator.impl.v13;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.CancelSendJobParamDTO;

/**
 * @author nayeemuddin
 *
 */
@Service("cancelSendJobServiceValidatorV13")
public class CancelSendJobServiceValidatorImpl {
	
	public final static String MISSING_MANDATORY = "ERR_argument_missing_mandatory";
	public final static String MISSING_INSTITUTE_NAME = "ERR_argument_missing_institute";
	public final static String RECORD_ALREADY_EXISTS = "ERR_record_already_exists";
	public final static String NO_RECORD_FOUND = "ERR_no_record_found";
	public final static String GENERAL_DB_FAILURE = "ERR_general_db_fail";
	public final static String INVALID_AETITLE = "ERR_invalid_AE_title";
	public final static String INVALID_DATE_RANGE = "ERR_invalid_date_range";
	public final static String INVALID_START_DATE = "ERR_invalid_start_date";
	public final static String INVALID_END_DATE = "ERR_invalid_end_date";

	/**
	 * 
	 * <pre>Validate the mandatory parameter JobId from the request.</pre>
	 * @param dto
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	public int validate(CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
		 if (StringUtils.isEmpty(dto.getJobId())) {
	            throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);
	        }
	        return 1;
	}

}
