/**
 * Validator for Cancel job
 */
package com.idexx.dicom.ae.validator.v11;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;

/**
 * @author anarayana
 *
 */
public interface CancelSendJobServiceValidator extends IdexxValidator {
    int validate(CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
