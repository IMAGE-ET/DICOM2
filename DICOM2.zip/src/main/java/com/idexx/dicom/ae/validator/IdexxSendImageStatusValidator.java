/**
 * 
 */
package com.idexx.dicom.ae.validator;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface IdexxSendImageStatusValidator extends IdexxValidator {

    int validate(SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
