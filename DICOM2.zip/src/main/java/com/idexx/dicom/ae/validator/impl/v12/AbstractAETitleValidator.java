/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v12;

import com.idexx.dicom.ae.validator.v12.AETitleValidator;
import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public abstract class AbstractAETitleValidator implements AETitleValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.ae.validator.AETitleValidator#validate(com.idexx.dicom
     * .services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    public final int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        validateInputFields(dto);
        validateDBFields(dto);
        return 1;
    }
    
    protected abstract int validateInputFields(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    
    protected abstract int validateDBFields(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    
}
