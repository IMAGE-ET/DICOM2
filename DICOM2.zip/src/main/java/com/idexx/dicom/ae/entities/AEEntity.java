/**
 * Entity for AE Table (PACSDB inbuilt table)
 */
package com.idexx.dicom.ae.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author sbitla
 * 
 */
@Entity
@Table(name = "ae")
public class AEEntity implements Serializable {

    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = 7509451381082593797L;

    private int id;
    private String aeTitle;
    private String hostName;
    private int port;

    /**
     * @return the id
     */
    @Id
    @Column(name = "pk")
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the aeTitle
     */
    @Column(name = "aet")
    public String getAeTitle() {
        return aeTitle;
    }

    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public void setAeTitle(String aeTitle) {
        this.aeTitle = aeTitle;
    }

    /**
     * @return the hostName
     */
    @Column(name = "hostname")
    public String getHostName() {
        return hostName;
    }

    /**
     * @param hostName
     *            the hostName to set
     */
    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    /**
     * @return the port
     */
    @Column(name = "port")
    public int getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public void setPort(int port) {
        this.port = port;
    }

}
