/**
 * 
 */
package com.idexx.dicom.ae.validator.v11;

import com.idexx.dicom.services.dto.v11.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface StoreFailureServiceValidator extends IdexxValidator {
    
    int validate(IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
