/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v13;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>DeleteAETitleValidator Implementation to check input parameters for Delete AETitle web Service</pre>
 * @author smallela
 * @version 1.3
 */

@Service("deleteAETitleValidatorV13")
public class DeleteAETitleValidator extends AbstractAETitleValidator {
	
	private static final Logger LOG = Logger.getLogger(DeleteAETitleValidator.class);

    @Autowired
    private AETitleDao aeTitleDao;
    
    /**
     * <pre>Validate apiKey,aeTitle,instituteName of AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    @Override
    protected final int validateInputFields(final AETitleDTO dto)
            throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getAeTitle())) {
            throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY,
                    MISSING_MANDATORY);
        }
        
        return 1;
    }
   
    /**
     * <pre>this method validates DBFields(MISSING_INSTITUTE_NAME,INVALID_AETITLE,GENERAL_DB_FAILURE) for delete AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */   
    
    @Override
    protected final int validateDBFields(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        try {
            if (!isAETitleExistWithIdentifiedByAETitleOnly(dto.getAeTitle())) {
                if (StringUtils.isEmpty(dto.getInstituteName())) {
                    throw new IdexxDicomAEConfigServiceException(MISSING_INSTITUTE_NAME,
                            MISSING_INSTITUTE_NAME);
                } else if (!isAETitleExistWithInstituteName(dto.getAeTitle(), dto.getInstituteName())) {
                    throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND,
                            NO_RECORD_FOUND);
                }
                
            }
            
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
        	throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE);
        }
        return 1;
    }
    
    private boolean isAETitleExistWithIdentifiedByAETitleOnly(
            final String aeTitle) throws IdexxDicomAEConfigServiceException {
        boolean isExists = false;
        List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle);
        if (null == registeredAEList || registeredAEList.isEmpty()) {
            throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND,
                    NO_RECORD_FOUND);
        }
        if ((registeredAEList.size() == 1)
                && (registeredAEList.get(0)).isIdentifiedByaeTitleOnly()) {
            isExists = true;
        }
        return isExists;
    }
    
    private boolean isAETitleExistWithInstituteName(
            final String aeTitle, final String institute) {
        boolean isExists = false;
        List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle, institute);
        if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
            isExists = true;
        }
        return isExists;
    }
}
