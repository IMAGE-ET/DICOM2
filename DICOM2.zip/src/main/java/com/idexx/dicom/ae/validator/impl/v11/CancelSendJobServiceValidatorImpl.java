/**
 * Validator Implementation to chack input parameters for Send Image Web Service
 */
package com.idexx.dicom.ae.validator.impl.v11;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.validator.v11.CancelSendJobServiceValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;

/**
 * @author anarayana
 * 
 */
@Service("cancelSendJobServiceValidatorV11")
public class CancelSendJobServiceValidatorImpl implements CancelSendJobServiceValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.ae.validator.IdexxSendImageValidator#validate(com.idexx
     * .dicom.services.sendimage.dto.SendImageJobParamDTO)
     */
    @Override
    public final int validate(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getJobId())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        return 1;
    }
    
}
