package com.idexx.dicom.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "MPPS_N_CREATE")
public class MPPSNCreate implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String id;

	@Column(name="MPPS_SOP_INSTANCE_UID")
	private String mppsSOPInstanceUID;

	@NotNull
	@Column(name="PATIENT_ID")
	private String patientId;

	@Column(name="PERFORMED_STATION_AE_TITLE")
	private String performedStationAETitle;

	@Column(name="PERFORMED_PROCEDURE_STEP_START_DATE")
	private Timestamp performedProcedureStepStartDate;

	@Column(name="PERFORMED_PROCEDURE_STEP_END_DATE")
	private Timestamp performedProcedureStepEndDate;

	@Column(name="PERFORMED_STATION_NAME")
	private String performedStationName;

	@Column(name="PERFORMED_LOCATION")
	private String performedLocation;

	@Column(name="PERFORMED_PROCEDURE_STEP_STATUS")
	private String performedProcedureStepStatus;

	@Column(name="STUDY_INSTANCE_UID")
	private String studyInstanceUID;

	@Column(name="SCHEDULED_PROCEDURE_STEP_ID")
	private String scheduledProcedureStepId;

	@Column(name="CREATE_TIMESTAMP")
	private Timestamp createTimestamp;

	@Column(name="UPDATE_TIMESTAMP")
	private Timestamp updateTimestamp;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the mppsSOPInstanceUID
	 */
	public String getMppsSOPInstanceUID() {
		return mppsSOPInstanceUID;
	}

	/**
	 * @param mppsSOPInstanceUID the mppsSOPInstanceUID to set
	 */
	public void setMppsSOPInstanceUID(String mppsSOPInstanceUID) {
		this.mppsSOPInstanceUID = mppsSOPInstanceUID;
	}

	/**
	 * @return the patientId
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	/**
	 * @return the performedStationAETitle
	 */
	public String getPerformedStationAETitle() {
		return performedStationAETitle;
	}

	/**
	 * @param performedStationAETitle the performedStationAETitle to set
	 */
	public void setPerformedStationAETitle(String performedStationAETitle) {
		this.performedStationAETitle = performedStationAETitle;
	}

	/**
	 * @return the performedProcedureStepStartDate
	 */
	public Timestamp getPerformedProcedureStepStartDate() {
		return performedProcedureStepStartDate;
	}

	/**
	 * @param performedProcedureStepStartDate the performedProcedureStepStartDate to set
	 */
	public void setPerformedProcedureStepStartDate(Timestamp performedProcedureStepStartDate) {
		this.performedProcedureStepStartDate = performedProcedureStepStartDate;
	}

	/**
	 * @return the performedProcedureStepEndDate
	 */
	public Timestamp getPerformedProcedureStepEndDate() {
		return performedProcedureStepEndDate;
	}

	/**
	 * @param performedProcedureStepEndDate the performedProcedureStepEndDate to set
	 */
	public void setPerformedProcedureStepEndDate(Timestamp performedProcedureStepEndDate) {
		this.performedProcedureStepEndDate = performedProcedureStepEndDate;
	}

	/**
	 * @return the performedStationName
	 */
	public String getPerformedStationName() {
		return performedStationName;
	}

	/**
	 * @param performedStationName the performedStationName to set
	 */
	public void setPerformedStationName(String performedStationName) {
		this.performedStationName = performedStationName;
	}

	/**
	 * @return the performedLocation
	 */
	public String getPerformedLocation() {
		return performedLocation;
	}

	/**
	 * @param performedLocation the performedLocation to set
	 */
	public void setPerformedLocation(String performedLocation) {
		this.performedLocation = performedLocation;
	}

	/**
	 * @return the performedProcedureStepStatus
	 */
	public String getPerformedProcedureStepStatus() {
		return performedProcedureStepStatus;
	}

	/**
	 * @param performedProcedureStepStatus the performedProcedureStepStatus to set
	 */
	public void setPerformedProcedureStepStatus(String performedProcedureStepStatus) {
		this.performedProcedureStepStatus = performedProcedureStepStatus;
	}

	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}

	/**
	 * @param studyInstanceUID the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the scheduledProcedureStepId
	 */
	public String getScheduledProcedureStepId() {
		return scheduledProcedureStepId;
	}

	/**
	 * @param scheduledProcedureStepId the scheduledProcedureStepId to set
	 */
	public void setScheduledProcedureStepId(String scheduledProcedureStepId) {
		this.scheduledProcedureStepId = scheduledProcedureStepId;
	}

	/**
	 * @return the createTimestamp
	 */
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	/**
	 * @param createTimestamp the createTimestamp to set
	 */
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	/**
	 * @return the updateTimestamp
	 */
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	/**
	 * @param updateTimestamp the updateTimestamp to set
	 */
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
