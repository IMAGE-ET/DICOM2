package com.idexx.dicom.domain;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "OWNER")
@IdClass(OwnerPK.class)
public class Owner implements Serializable {
    private static final long serialVersionUID = -3088509114902914234L;
    private String patientID;
    private String clientID;
    private boolean primaryOwner;
    private Patient patient;
    private Client client;

    /**
     * @return the patientID
     */
    @Id
    @Column(name = "PATIENT_ID")
    public String getPatientID() {
	return patientID;
    }

    /**
     * @param patientID
     *            the patientID to set
     */
    public void setPatientID(String patientID) {
	this.patientID = patientID;
    }

    /**
     * @return the clientID
     */
    @Id
    @Column(name = "CLIENT_ID")
    public String getClientID() {
	return clientID;
    }

    /**
     * @param clientID
     *            the clientID to set
     */
    public void setClientID(String clientID) {
	this.clientID = clientID;
    }

    /**
     * @return the patient
     */
    @ManyToOne(targetEntity = Patient.class)
    @JoinColumn(name = "PATIENT_ID", insertable = false, updatable = false)
    public Patient getPatient() {
	return patient;
    }

    /**
     * @param patient
     *            the patient to set
     */
    public void setPatient(Patient patient) {
	this.patient = patient;
    }

    /**
     * @return the client
     */
    @ManyToOne(targetEntity = Client.class)
    @JoinColumn(name = "CLIENT_ID", insertable = false, updatable = false)
    public Client getClient() {
	return client;
    }

    /**
     * @param client
     *            the client to set
     */
    public void setClient(Client client) {
	this.client = client;
    }

    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
	return serialVersionUID;
    }

    @Column(name = "PRIMARY_OWNER")
    public boolean isPrimaryOwner() {
	return primaryOwner;
    }

    public void setPrimaryOwner(boolean primaryOwner) {
	this.primaryOwner = primaryOwner;
    }
}
