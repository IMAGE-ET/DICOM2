package com.idexx.dicom.domain;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MPPSNSet.class)
public abstract class MPPSNSet_ {

	public static volatile SingularAttribute<MPPSNSet, String> seriesInstanceUID;
	public static volatile SingularAttribute<MPPSNSet, String> seriesDescription;
	public static volatile SingularAttribute<MPPSNSet, String> retrieveAETitle;
	public static volatile SingularAttribute<MPPSNSet, String> performingPhysicianName;
	public static volatile SingularAttribute<MPPSNSet, String> protocolName;
	public static volatile SingularAttribute<MPPSNSet, String> referencedSOPInstanceUIDs;
	public static volatile SingularAttribute<MPPSNSet, String> operatorsName;
	public static volatile SingularAttribute<MPPSNSet, String> id;
	public static volatile SingularAttribute<MPPSNSet, String> mppsNCreateId;
	public static volatile SingularAttribute<MPPSNSet, Timestamp> updateTimestamp;
	public static volatile SingularAttribute<MPPSNSet, Timestamp> createTimestamp;

}

