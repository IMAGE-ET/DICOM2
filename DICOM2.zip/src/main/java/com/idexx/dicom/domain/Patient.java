package com.idexx.dicom.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class Patient.
 */
@Entity
@Table(name = "PATIENT")
public class Patient implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The i d. */
	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "ID")
	private String iD;

	/** The patient name. */
	@Column(name = "NAME")
	private java.lang.String patientName;

	/** The dob. */
	@Column(name = "DOB")
	private Timestamp dob;

	/** The species. */
	@Column(name = "SPECIES")
	private java.lang.String species;

	/** The breed. */
	@Column(name = "BREED")
	private java.lang.String breed;

	/** The gender. */
	@Column(name = "GENDER")
	private java.lang.String gender;

	/** The application patient id. */
	@Column(name = "APPLICATION_PATIENT_ID")
	private java.lang.String applicationPatientId;

	/** The clinic id. */
	@Column(name = "SAP_ID")
	private java.lang.String clinicId;

	/** The weight. */
	@Column(name = "WEIGHT")
	private java.lang.Integer weight;

	/** The edhd number. */
	@Column(name = "EDHD_NUMBER")
	private java.lang.String edhdNumber;

	/** The weight unit. */
	@Column(name = "WEIGHT_UNIT")
	private java.lang.String weightUnit;

	/** The active flag. */
	@Column(name = "ACTIVE_FLAG")
	private java.lang.Integer activeFlag;

	/** The last modified date. */
	@Column(name = "LAST_MOD_DATE")
	private Timestamp lastModifiedDate;

	/** The owners with patient. */
	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<Owner> ownersWithPatient = new HashSet<Owner>(0);

	/** The external patient ids. */
	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<ExternalPatient> externalPatientIds = new ArrayList<ExternalPatient>(0);

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getID() {
		return iD;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD
	 *            the new id
	 */
	public void setID(String iD) {
		this.iD = iD;
	}

	/**
	 * Gets the patient name.
	 *
	 * @return the patientName
	 */
	public java.lang.String getPatientName() {
		return patientName;
	}

	/**
	 * Sets the patient name.
	 *
	 * @param patientName
	 *            the patientName to set
	 */
	public void setPatientName(java.lang.String patientName) {
		this.patientName = patientName;
	}

	/**
	 * Gets the dob.
	 *
	 * @return the dob
	 */
	public Timestamp getDob() {
		return dob;
	}

	/**
	 * Sets the dob.
	 *
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(Timestamp dob) {
		this.dob = dob;
	}

	/**
	 * Gets the species.
	 *
	 * @return the species
	 */
	public java.lang.String getSpecies() {
		return species;
	}

	/**
	 * Sets the species.
	 *
	 * @param species
	 *            the species to set
	 */
	public void setSpecies(java.lang.String species) {
		this.species = species;
	}

	/**
	 * Gets the breed.
	 *
	 * @return the breed
	 */
	public java.lang.String getBreed() {
		return breed;
	}

	/**
	 * Sets the breed.
	 *
	 * @param breed
	 *            the breed to set
	 */
	public void setBreed(java.lang.String breed) {
		this.breed = breed;
	}

	/**
	 * Gets the gender.
	 *
	 * @return the gender
	 */
	public java.lang.String getGender() {
		return gender;
	}

	/**
	 * Sets the gender.
	 *
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(java.lang.String gender) {
		this.gender = gender;
	}

	/**
	 * Gets the application patient id.
	 *
	 * @return the applicationPatientId
	 */
	public java.lang.String getApplicationPatientId() {
		return applicationPatientId;
	}

	/**
	 * Sets the application patient id.
	 *
	 * @param applicationPatientId
	 *            the applicationPatientId to set
	 */
	public void setApplicationPatientId(java.lang.String applicationPatientId) {
		this.applicationPatientId = applicationPatientId;
	}

	/**
	 * Gets the clinic id.
	 *
	 * @return the clinicId
	 */
	public java.lang.String getClinicId() {
		return clinicId;
	}

	/**
	 * Sets the clinic id.
	 *
	 * @param clinicId
	 *            the clinicId to set
	 */
	public void setClinicId(java.lang.String clinicId) {
		this.clinicId = clinicId;
	}

	/**
	 * Gets the weight.
	 *
	 * @return the weight
	 */
	public java.lang.Integer getWeight() {
		return weight;
	}

	/**
	 * Sets the weight.
	 *
	 * @param weight
	 *            the weight to set
	 */
	public void setWeight(java.lang.Integer weight) {
		this.weight = weight;
	}

	/**
	 * Gets the edhd number.
	 *
	 * @return the edhdNumber
	 */
	public java.lang.String getEdhdNumber() {
		return edhdNumber;
	}

	/**
	 * Sets the edhd number.
	 *
	 * @param edhdNumber
	 *            the edhdNumber to set
	 */
	public void setEdhdNumber(java.lang.String edhdNumber) {
		this.edhdNumber = edhdNumber;
	}

	/**
	 * Gets the weight unit.
	 *
	 * @return the weightUnit
	 */
	public java.lang.String getWeightUnit() {
		return weightUnit;
	}

	/**
	 * Sets the weight unit.
	 *
	 * @param weightUnit
	 *            the weightUnit to set
	 */
	public void setWeightUnit(java.lang.String weightUnit) {
		this.weightUnit = weightUnit;
	}

	/**
	 * Gets the active flag.
	 *
	 * @return the activeFlag
	 */
	public java.lang.Integer getActiveFlag() {
		return activeFlag;
	}

	/**
	 * Sets the active flag.
	 *
	 * @param activeFlag
	 *            the activeFlag to set
	 */
	public void setActiveFlag(java.lang.Integer activeFlag) {
		this.activeFlag = activeFlag;
	}

	/**
	 * Gets the last modified date.
	 *
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * Sets the last modified date.
	 *
	 * @param lastModifiedDate
	 *            the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * Gets the external patient ids.
	 *
	 * @return the external patient ids
	 */
	public List<ExternalPatient> getExternalPatientIds() {
		return externalPatientIds;
	}

	/**
	 * Sets the external patient ids.
	 *
	 * @param externalPatientIds
	 *            the new external patient ids
	 */
	public void setExternalPatientIds(List<ExternalPatient> externalPatientIds) {
		this.externalPatientIds = externalPatientIds;
	}

	/**
	 * Gets the owners with patient.
	 *
	 * @return the ownersWithPatient
	 */
	public Set<Owner> getOwnersWithPatient() {
		return ownersWithPatient;
	}

	/**
	 * Sets the owners with patient.
	 *
	 * @param ownersWithPatient
	 *            the ownersWithPatient to set
	 */
	public void setOwnersWithPatient(Set<Owner> ownersWithPatient) {
		this.ownersWithPatient = ownersWithPatient;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
