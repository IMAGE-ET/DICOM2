package com.idexx.dicom.domain;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

// TODO: Auto-generated Javadoc
/**
 * The Class RequestDetails_.
 */
@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(RequestDetails.class)
public abstract class RequestDetails_ {

	/** The requesting doctor. */
	public static volatile SingularAttribute<RequestDetails, String> requestingDoctor;

	/** The modality. */
	public static volatile SingularAttribute<RequestDetails, String> modality;

	/** The api key. */
	public static volatile SingularAttribute<RequestDetails, String> apiKey;

	/** The patient id. */
	public static volatile SingularAttribute<RequestDetails, String> patientId;

	/** The study instance uid. */
	public static volatile SingularAttribute<RequestDetails, String> studyInstanceUID;

	/** The create time stamp. */
	public static volatile SingularAttribute<RequestDetails, Timestamp> createTimeStamp;

	/** The update time stamp. */
	public static volatile SingularAttribute<RequestDetails, Timestamp> updateTimeStamp;

	/** The request notes. */
	public static volatile SingularAttribute<RequestDetails, String> requestNotes;

	/** The accession number. */
	public static volatile SingularAttribute<RequestDetails, String> accessionNumber;

	/** The patient. */
	public static volatile SingularAttribute<RequestDetails, Patient> patient;

	/** The Id. */
	public static volatile SingularAttribute<RequestDetails, String> Id;

	/** The sap id. */
	public static volatile SingularAttribute<RequestDetails, String> sapId;

	/** The status. */
	public static volatile SingularAttribute<RequestDetails, String> status;

}
