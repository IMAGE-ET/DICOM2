package com.idexx.dicom.domain;

import java.io.Serializable;


public class ExternalPatientPK implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 5202168131980323682L;
    
    private String patientID;
    
    private String issuerOfPatientID;

    
    
    /**
     * @return the patientID
     */
    public String getPatientID() {
        return patientID;
    }

    /**
     * @param patientID the patientID to set
     */
    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    /**
     * @return the issuerOfPatientID
     */
    public String getIssuerOfPatientID() {
        return issuerOfPatientID;
    }

    /**
     * @param issuerOfPatientID the issuerOfPatientID to set
     */
    public void setIssuerOfPatientID(String issuerOfPatientID) {
        this.issuerOfPatientID = issuerOfPatientID;
    }

    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public ExternalPatientPK() {
    }

    public ExternalPatientPK(String patientID, String issuerOfPatientID) {
	this.patientID = patientID;
	this.issuerOfPatientID = issuerOfPatientID;
    }
}
