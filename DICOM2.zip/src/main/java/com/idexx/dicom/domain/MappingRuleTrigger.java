package com.idexx.dicom.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="DS_MAPPING_RULE_TRIGGERS")
public class MappingRuleTrigger implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5073908920422374804L;

	@Id
	@GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name="ID", unique=true, nullable=false)
	private String id;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DS_MAPPING_RULE_ID", nullable = false)
	private MappingRule mappingRule;
	
	@Column(name="TAG_KEY", nullable =false)
	private String tagKey;
	
	@Column(name="TAG_VALUE", nullable =false)
	private String tagValue;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATE_DATE")
	private Date  createDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TIMESTAMP")
	private Date  updateDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public MappingRule getMappingRule() {
		return mappingRule;
	}

	public void setMappingRule(MappingRule mappingRule) {
		this.mappingRule = mappingRule;
	}

	public String getTagValue() {
		return tagValue;
	}

	public void setTagValue(String tagValue) {
		this.tagValue = tagValue;
	}

	public String getTagKey() {
		return tagKey;
	}

	public void setTagKey(String tagKey) {
		this.tagKey = tagKey;
	}

	@PrePersist
	void createdAt() {
		this.setCreateDate(this.setUpdateDate(new Date()));
	}

	@PreUpdate
	void updatedAt() {
		this.setUpdateDate(new Date());
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public Date setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
		return updateDate;
	}
}
