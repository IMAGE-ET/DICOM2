package com.idexx.dicom.domain;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MPPSNCreate.class)
public abstract class MPPSNCreate_ {

	public static volatile SingularAttribute<MPPSNCreate, Timestamp> performedProcedureStepEndDate;
	public static volatile SingularAttribute<MPPSNCreate, String> performedStationAETitle;
	public static volatile SingularAttribute<MPPSNCreate, String> patientId;
	public static volatile SingularAttribute<MPPSNCreate, String> scheduledProcedureStepId;
	public static volatile SingularAttribute<MPPSNCreate, String> mppsSOPInstanceUID;
	public static volatile SingularAttribute<MPPSNCreate, String> studyInstanceUID;
	public static volatile SingularAttribute<MPPSNCreate, String> performedStationName;
	public static volatile SingularAttribute<MPPSNCreate, String> performedLocation;
	public static volatile SingularAttribute<MPPSNCreate, String> performedProcedureStepStatus;
	public static volatile SingularAttribute<MPPSNCreate, Timestamp> updateTimestamp;
	public static volatile SingularAttribute<MPPSNCreate, Timestamp> createTimestamp;
	public static volatile SingularAttribute<MPPSNCreate, Timestamp> performedProcedureStepStartDate;
	public static volatile SingularAttribute<MPPSNCreate, String> id;

}

