package com.idexx.dicom.domain;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

// TODO: Auto-generated Javadoc
/**
 * The Class Patient_.
 */
@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Patient.class)
public abstract class Patient_ {

	/** The patient name. */
	public static volatile SingularAttribute<Patient, String> patientName;

	/** The clinic id. */
	public static volatile SingularAttribute<Patient, String> clinicId;

	/** The gender. */
	public static volatile SingularAttribute<Patient, String> gender;

	/** The last modified date. */
	public static volatile SingularAttribute<Patient, Timestamp> lastModifiedDate;

	/** The weight. */
	public static volatile SingularAttribute<Patient, Integer> weight;

	/** The application patient id. */
	public static volatile SingularAttribute<Patient, String> applicationPatientId;

	/** The breed. */
	public static volatile SingularAttribute<Patient, String> breed;

	/** The owners with client. */
	public static volatile SetAttribute<Patient, Owner> ownersWithClient;

	/** The species. */
	public static volatile SingularAttribute<Patient, String> species;

	/** The dob. */
	public static volatile SingularAttribute<Patient, Timestamp> dob;

	/** The external patient ids. */
	public static volatile ListAttribute<Patient, ExternalPatient> externalPatientIds;

	/** The edhd number. */
	public static volatile SingularAttribute<Patient, String> edhdNumber;

	/** The i d. */
	public static volatile SingularAttribute<Patient, String> iD;

	/** The owners with patient. */
	public static volatile SetAttribute<Patient, Owner> ownersWithPatient;

	/** The weight unit. */
	public static volatile SingularAttribute<Patient, String> weightUnit;

	/** The active flag. */
	public static volatile SingularAttribute<Patient, Integer> activeFlag;

}
