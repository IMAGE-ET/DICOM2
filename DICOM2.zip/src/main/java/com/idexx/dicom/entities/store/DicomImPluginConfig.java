/**
 * 
 */
package com.idexx.dicom.entities.store;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "Dicom_IM_Plugin_Config")
public class DicomImPluginConfig implements Serializable {

    /**
     * Generated
     */
    private static final long serialVersionUID = -4754455713092220609L;

    private int id;
    private String configName;
    private String configValue;
    private String description;
    private Timestamp createdDate;
    private Timestamp updatedDate;

    /**
     * @return the id
     */
    @Id
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final int id) {
        this.id = id;
    }

    /**
     * @return the configName
     */
    @Column(name = "CONFIG_NAME")
    public String getConfigName() {
        return configName;
    }

    /**
     * @param configName
     *            the configName to set
     */
    public void setConfigName(final String configName) {
        this.configName = configName;
    }

    /**
     * @return the configValue
     */
    @Column(name = "CONFIG_VALUE")
    public String getConfigValue() {
        return configValue;
    }

    /**
     * @param configValue
     *            the configValue to set
     */
    public void setConfigValue(final String configValue) {
        this.configValue = configValue;
    }

    /**
     * @return the description
     */
    @Column(name = "CONFIG_DESCRIPTION")
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * @return the createdDate
     */
    @Column(name = "CREATED_DATE")
    public Timestamp getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(final Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    @Column(name = "UPDATED_DATE")
    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(final Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DicomImPluginConfig [getId()=");
        builder.append(getId());
        builder.append(", getConfigName()=");
        builder.append(getConfigName());
        builder.append(", getConfigValue()=");
        builder.append(getConfigValue());
        builder.append(", getDescription()=");
        builder.append(getDescription());
        builder.append(", getCreatedDate()=");
        builder.append(getCreatedDate());
        builder.append(", getUpdatedDate()=");
        builder.append(getUpdatedDate());
        builder.append(", hashCode()=");
        builder.append(hashCode());
        builder.append("]");
        return builder.toString();
    }

}
