/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.conf;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * <pre>
 * Loading data source based on the environment
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Configuration
public class DBConfig {

	private static final Logger LOG = Logger.getLogger(DBConfig.class);

	@Autowired
	private Environment environment;

	public ComboPooledDataSource  dataSource;

	@Bean
	public DataSource getDbConfigXml() throws Exception {
		String env = environment.getProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME);
		LOG.info("DriverClassName: " + environment.getRequiredProperty("jdbc."+env+".driverClassName"));
		LOG.info("jdbc url: " + environment.getRequiredProperty("jdbc."+env+".url"));
		LOG.info("jdbc username: " + environment.getRequiredProperty("jdbc."+env+".username"));
		dataSource = new ComboPooledDataSource();
		dataSource.setDriverClass(environment.getRequiredProperty("jdbc."+env+".driverClassName"));
		dataSource.setJdbcUrl(environment.getRequiredProperty("jdbc."+env+".url"));
		dataSource.setUser(environment.getRequiredProperty("jdbc."+env+".username"));
		dataSource.setPassword(environment.getRequiredProperty("jdbc."+env+".password"));
		dataSource.setInitialPoolSize(getPropertyAsInt(env, ".initialPoolSize"));
		dataSource.setMaxPoolSize(getPropertyAsInt(env, ".maxPoolSize"));
		dataSource.setMinPoolSize(getPropertyAsInt(env, ".minPoolSize"));
		dataSource.setIdleConnectionTestPeriod(getPropertyAsInt(env, ".idleConnectionTestPeriod"));
		dataSource.setAcquireIncrement(getPropertyAsInt(env, ".acquireIncrement"));
		dataSource.setMaxStatements(getPropertyAsInt(env, ".maxStatements"));
		return dataSource;
	}
	
	private int getPropertyAsInt(String env, String propertyName) {
		int value = Integer.parseInt(environment.getRequiredProperty("jdbc." + env + propertyName));
		return value;
	}
}
