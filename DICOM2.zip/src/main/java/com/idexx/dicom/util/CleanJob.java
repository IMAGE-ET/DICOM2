/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.util;

import java.io.File;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.idexx.dicom.services.IdexxDicomServiceConstants;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
public class CleanJob implements Job {
    private static Logger LOG = Logger.getLogger(CleanJob.class);

    public final void execute(final JobExecutionContext jobContext) throws JobExecutionException {
	final long oldRecordTimestamp = new Date().getTime() - (60 * 60 * 1000);
	deleteDirContents(oldRecordTimestamp, IdexxDicomServiceConstants.TEMP_FILES);
	deleteDirContents(oldRecordTimestamp, IdexxDicomServiceConstants.DOWNLOADED_IMAGES_DIR);
    }

	/**
	 * @param oldRecordTimestamp
	 * @param tmpDir TODO
	 */
	public void deleteDirContents(final long oldRecordTimestamp, String tmpDir) {
		try {
		    File tempFiles = new File(
			    System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator + tmpDir);
		    File[] files = tempFiles.listFiles();
		    for (File file : files) {
			deleteFiles(file, oldRecordTimestamp);
		    }
		} catch (Exception e) {
		    LOG.error("Error while clearing temp files", e);
		}
	}

    public void deleteFiles(File f, Long oldRecs) {
	if (f.isDirectory()) {
	    File files[] = f.listFiles();
	    if (files != null && files.length <= 0) {
		return;
	    }
	    for (File file : files) {
		if (file.isDirectory()) {
		    deleteFiles(file, oldRecs);
		} else {
		    LOG.info("file.lastModified(): " + file.lastModified() + " : oldRecordTimestamp: " + oldRecs);
		    if (file.lastModified() < oldRecs) {
		    	deleteQuietly(file);
		    }
		}
	    }
	} else {
	    LOG.info("file.lastModified(): " + f.lastModified() + " : oldRecordTimestamp: " + oldRecs);
	    if (f.lastModified() < oldRecs) {
	    	deleteQuietly(f);
	    }
	}
    }
    
    private void deleteQuietly(File file) {
    	if (!FileUtils.deleteQuietly(file)) {
    		LOG.warn("unable to delete temp file: "+file.getAbsolutePath());	
    	}
    }
}
