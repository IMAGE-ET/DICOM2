package com.idexx.dicom.util;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.StandardElementDictionary;
import org.dcm4che3.data.VR;
import org.dcm4che3.util.TagUtils;

import com.idexx.dicom.dto.MappingRuleActionDTO;
import com.idexx.dicom.dto.MappingRuleDTO;
import com.idexx.dicom.dto.MappingRuleTriggerDTO;

public class MappingUtil {

	private static final Logger LOG = Logger.getLogger(MappingUtil.class);
	
	public static final String REPLACE_BY_TAG = "replace_by_tag";
	public static final String REPLACE_BY_VALUE = "replace_by_value";
	
	private static final Pattern tagPattern = Pattern.compile("\\([0-9a-fA-F]{4},[0-9a-fA-F]{4}\\)");

	public static final String getUN(Attributes ds, int privateTag) {
		String strelem = ds.getString(privateTag);
		return MappingUtil.getUN(strelem);
	}

	/**
	 * Takes Hex results of Dataset getString method and converts to ASCII e.g.
	 * \43\61\6E\69\6E\65  = Canine.
	 * 
	 * @param strElem
	 */
	public static String getUN(String strElem) {
		StringBuffer sb = new StringBuffer();
	
		if (strElem != null) {
			if (strElem.indexOf("\\") > -1) {
				StringTokenizer st = new StringTokenizer(strElem, "\\");
	
				while (st.hasMoreTokens()) {
					int blah = Integer.parseInt(st.nextToken(), 16);
					sb.append(new Character((char) blah));
				}
			} else {
				return strElem;
			}
		}
		if (sb.length() == 0) {
			return null;
		}
		return sb.toString().trim();
	}

	public static int getTag(String strTriggerTag) {
		if (tagPattern.matcher(strTriggerTag).matches()) {
			String grp = strTriggerTag.substring(1, 5);
			String elm = strTriggerTag.substring(6, 10);
			return TagUtils.toTag(Integer.parseInt(grp, 16), Integer.parseInt(elm, 16)); 
		}
		throw new RuntimeException("invalid tag: "+strTriggerTag+ " expected format (0080,0070)");
	}

	public static String applyDicomMapping(Attributes attr, MappingRuleDTO rule) {
		LOG.info("applying mapping: "+rule.getName());
		String mappingErrorMessage = null;
	
		boolean verifyTriggers = false;
		String tagValue = "";
	
		Set<MappingRuleTriggerDTO> triggers = rule.getMappingRuleTriggers();
		Set<MappingRuleActionDTO> actions = rule.getMappingRuleActions();
	
		for(MappingRuleTriggerDTO trigger:triggers){
			String triggerValue = trigger.getTagValue();
			String strTriggerTag = trigger.getTagKey();
			int triggerTag = getTag(strTriggerTag);
			String valueFromDicomFile = attr.getString(triggerTag);
	
			if(triggerValue!= null && triggerValue.trim().equalsIgnoreCase(valueFromDicomFile)){
				verifyTriggers = true;
			} else {
				verifyTriggers = false;
				break;
			}
		}
	
		if(verifyTriggers){
			for(MappingRuleActionDTO action:actions){
	
				String strOriginalTag = action.getTagKey();
				int originalTag = getTag(strOriginalTag);
				
				VR vrOfOriginaltag = StandardElementDictionary.vrOf(originalTag, null);
				String actionType = action.getActionType();
	
				if(actionType!=null && !actionType.isEmpty()){
					boolean doAction = true;
					if(actionType.equalsIgnoreCase(MappingUtil.REPLACE_BY_TAG)){
						String strMappedTag = action.getReplaceValue();
						int mappedTag = getTag(strMappedTag);
	
						if(action.getDoActionIfNull()){
							if (attr.getString(originalTag) == ""
									|| attr.getString(originalTag) == null)
							{
								if (TagUtils.isPrivateGroup(mappedTag))
								{
									tagValue = getUN(attr, mappedTag);
								} else
								{
									tagValue = attr.getString(mappedTag);
								}
							} else {
								doAction = false;
							}
						} else {
							if (TagUtils.isPrivateGroup(mappedTag))
							{
								tagValue = getUN(attr, mappedTag);
							} else
							{
								tagValue = attr.getString(mappedTag);
							}
						}
					} else {
						if(action.getDoActionIfNull()){
							if (StringUtils.isBlank(attr.getString(originalTag)))
							{
								tagValue = action.getReplaceValue();
							} else{
								doAction = false;
							}
						} else {
							tagValue = action.getReplaceValue();
						}
					}
					try{
						if(doAction){
							if(vrOfOriginaltag == VR.OB || vrOfOriginaltag == VR.OF || vrOfOriginaltag == VR.OW || vrOfOriginaltag == VR.UN){
								Charset charset = Charset.forName("ISO-8859-1");
								CharsetEncoder encoder = charset.newEncoder();
								ByteBuffer bbTagValue= encoder.encode(CharBuffer.wrap(tagValue.toCharArray()));
								attr.setValue(originalTag, vrOfOriginaltag, bbTagValue);
							} else {
								attr.setValue(originalTag, vrOfOriginaltag, tagValue);
							}
						}
					} catch(Exception e){
						mappingErrorMessage = "Data Type of Mapped Tag: (" + action.getTagKey() + ") didn't match with Replace Tag/Replace Value for Mapping Rule: '" + rule.getName() + "'";
						LOG.error(e.getMessage(), e);
					}
				}
			}
		}
		LOG.info("done applying mapping: "+rule.getName());
		return mappingErrorMessage;
	}

	public static void applyDicomMappings(Attributes attr, List<MappingRuleDTO> rulesBySapId) {
		String messages = ""; 
		for (MappingRuleDTO rule:rulesBySapId) {
			String message = applyDicomMapping(attr, rule);
			if (message!=null) {
				messages+=message;
			}
		}
		if (StringUtils.isNotBlank(messages)) {
			throw new RuntimeException(messages);
		}
	}

}
