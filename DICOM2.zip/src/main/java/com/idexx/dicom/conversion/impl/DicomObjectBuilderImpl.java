/**
 * 
 */
package com.idexx.dicom.conversion.impl;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.idexx.dicom.DicomObjectBuilder;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * @author vkandagatla
 * 
 */
public class DicomObjectBuilderImpl implements DicomObjectBuilder {
	
	private static final Logger LOG = Logger.getLogger(DicomObjectBuilderImpl.class);
	
    private ImageProperties imageProperties;
    private File dcmFile;
    public DicomObjectBuilderImpl(final ImageProperties imageProperties, final PatientDTO patientDTO,
            final StudyDTO studyDTO, final SeriesDTO seriesDTO, final ImageDTO imageDTO, final File dcmFile) {}

    /*
     * @see
     * com.idexx.dicom.DicomObjectBuilder#build(com.idexx.dicom.conversion.impl
     * .ImageProperties)
     */
    @Override
    public final void build() throws IOException {
        LOG.info(imageProperties.toString());
        this.write(dcmFile);
    }

    /**
     * @param imageFile
     * @param fileLength
     * @param dcmFile
     * @param dataSet
     * @throws IOException
     *             Writes the Image Data and Dicom DataSet to Dicom File
     */
    private void write(final File dcmFile) throws IOException {}
}
