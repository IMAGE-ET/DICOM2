package com.idexx.dicom.echo.v13;

import java.io.IOException;

import org.apache.cxf.common.util.StringUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.tool.storescu.StoreSCU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.util.ConnectionUtil;

/**
 * The Class DicomEchoServiceImpl.
 *
 * @author lamarawadi
 * @version 1.3
 */
@Service("dicomEchoServiceImplV13")
public class DicomEchoServiceImpl {

    /** The remote hostname. */
    String remoteHostname = "aws-dicom2-qa.dicom.idexxi.com";

    /** The remote port number. */
    int remotePortNumber = 11112;

    /** The default called aet. */
    String defaultCalledAET = "DCM4CHEE_MAIN";

    /** The device. */
    Device device = null;

    /** The ae. */
    ApplicationEntity ae = null;

    /** The conn. */
    Connection conn = null;

    @Autowired
    private ConnectionUtil connectionUtil;

    /** The Constant MESSAGE. */
    private static final String MESSAGE = "Unable to echo the dicom server: ";

    /**
     * Inits the.
     *
     * @param device
     *            the device
     * @param ae
     *            the ae
     * @param conn
     *            the conn
     */
    public void init(Device device, ApplicationEntity ae, Connection conn) {
	this.device = device;
	this.ae = ae;
	this.conn = conn;
    }

    /** The Constant log. */
    private static final Logger LOG = Logger.getLogger(DicomEchoServiceImpl.class);

    /**
     * Echo.
     *
     * @param callingAET
     *            the calling aet
     * @return true, if successful
     * @throws InterruptedException
     *             the interrupted exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public boolean echo(final String callingAET) throws InterruptedException, IOException {
	return echo(callingAET, remoteHostname, remotePortNumber);
    }

    /**
     * Echo.
     *
     * @param callingAET
     *            the calling aet
     * @param calledAET
     *            the called aet
     * @return true, if successful
     * @throws InterruptedException
     *             the interrupted exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public boolean echo(final String callingAET, final String calledAET) throws InterruptedException, IOException {
	return echo(callingAET, calledAET, remoteHostname, remotePortNumber);
    }

    /**
     * Echo.
     *
     * @param callingAET
     *            the calling aet
     * @param hostName
     *            the host name
     * @param port
     *            the port
     * @return true, if successful
     * @throws InterruptedException
     *             the interrupted exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public boolean echo(final String calledAET, final String hostName, final int port)
	    throws InterruptedException, IOException {
	String host = hostName;
	String calledAetTitle = calledAET;
	if (StringUtils.isEmpty(hostName)) {
	    host = remoteHostname;
	}
	if (StringUtils.isEmpty(calledAET)) {
	    calledAetTitle = defaultCalledAET;
	}
	return echo("", calledAetTitle, host, port);
    }

    /**
     * Echo.
     *
     * @param callingAET
     *            the calling aet
     * @param calledAET
     *            the called aet
     * @param hostName
     *            the host name
     * @param port
     *            the port
     * @return true, if successful
     * @throws InterruptedException
     *             the interrupted exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public boolean echo(final String callingAET, final String calledAET, final String hostName, final int port)
	    throws InterruptedException, IOException {
	boolean returnValue = true;
	StoreSCU main = null;
	try {
	    main = new StoreSCU(ae);
	} catch (IOException e) {
	    LOG.error(MESSAGE + e);
	    throw e;
	}
	connectionUtil.addTimeouts(conn);
	main.getAAssociateRQ().setCalledAET(calledAET);
	main.getRemoteConnection().setHostname(hostName);
	main.getRemoteConnection().setPort(port);
	main.getRemoteConnection().setTlsCipherSuites(conn.getTlsCipherSuites());
	main.getRemoteConnection().setTlsProtocols(conn.getTlsProtocols());
	main.getRemoteConnection().setResponseTimeout(conn.getResponseTimeout());
	main.setAttributes(new Attributes());

	try {
	    main.open();
	    main.echo();
	} catch (Exception exc) {
	    LOG.error(MESSAGE + exc);
	    returnValue = false;
	} finally {
	    try {
		main.close();
	    } catch (IOException e) {
		LOG.error(MESSAGE + e);
		returnValue = false;
	    }
	}
	return returnValue;
    }
}