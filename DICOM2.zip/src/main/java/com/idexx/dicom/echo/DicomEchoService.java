package com.idexx.dicom.echo;

public interface DicomEchoService {

	boolean echo(String callingAET, String hostName, int port) throws InterruptedException;

	boolean echo(String callingAET) throws InterruptedException;

	boolean echo(String callingAET, String calledAET) throws InterruptedException;

	boolean echo(String callingAET, String calledAET, String hostName, int port) throws InterruptedException;
}
