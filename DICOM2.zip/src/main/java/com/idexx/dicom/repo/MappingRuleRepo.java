package com.idexx.dicom.repo;

import java.util.List;

import com.idexx.dicom.domain.MappingRule;

public interface MappingRuleRepo extends IdexxRepository<MappingRule, String>{
	List<MappingRule> findBySapId(String sapId);
	MappingRule findById(String id);
	void delete(MappingRule rule);
}
