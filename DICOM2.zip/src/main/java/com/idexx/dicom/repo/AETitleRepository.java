package com.idexx.dicom.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.idexx.dicom.ae.entities.AETitle;

public interface AETitleRepository extends IdexxRepository<AETitle, String> {
	
	List<AETitle> findByAeTitle(String aeTitle);
	
	@Query("Select DISTINCT(RD.sapId) from AETitle RD where RD.aeTitle = ?1")
	List<String> findDistinctAeTitleBySapId(String aeTitle);

}
