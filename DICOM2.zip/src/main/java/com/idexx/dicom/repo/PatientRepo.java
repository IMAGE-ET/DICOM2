package com.idexx.dicom.repo;

import com.idexx.dicom.domain.Patient;

public interface PatientRepo extends IdexxRepository<Patient, String> {
	Patient findByID(String id);
}
