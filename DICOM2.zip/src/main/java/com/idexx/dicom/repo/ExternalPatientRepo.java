package com.idexx.dicom.repo;

import java.util.List;

import com.idexx.dicom.domain.ExternalPatient;

public interface ExternalPatientRepo extends IdexxRepository<ExternalPatient, String> {
	List<ExternalPatient> findByPatientID(String patientId);
}
