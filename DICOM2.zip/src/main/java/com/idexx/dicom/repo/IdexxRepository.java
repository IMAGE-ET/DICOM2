/**
 * 
 */
package com.idexx.dicom.repo;

import java.io.Serializable;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.Repository;

/**
 * @author vvanjarana
 *
 */
@NoRepositoryBean
public interface IdexxRepository <T, ID extends Serializable> extends Repository<T, ID> {	
	T save(T entity);
}
