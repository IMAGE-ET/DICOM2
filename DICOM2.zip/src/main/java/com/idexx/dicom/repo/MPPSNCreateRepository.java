package com.idexx.dicom.repo;

import java.util.List;

import com.idexx.dicom.domain.MPPSNCreate;

/**
 * 
 * @author sbitla
 *
 */
public interface MPPSNCreateRepository extends IdexxRepository<MPPSNCreate, String> {

	List<MPPSNCreate> findByMppsSOPInstanceUID(String mppsSOPInstanceUID);
	List<MPPSNCreate> findByStudyInstanceUID(String studyInstanceUID);
}
