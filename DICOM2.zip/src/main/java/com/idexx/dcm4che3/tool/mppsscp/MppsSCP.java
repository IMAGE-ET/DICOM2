package com.idexx.dcm4che3.tool.mppsscp;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.IOD;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.data.ValidationResult;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.service.BasicMPPSSCP;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.tool.common.CLIUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.services.mpps.MPPSService;
import com.idexx.dicom.util.ConnectionUtil;

@Component("mppsSCP")
public class MppsSCP {

    private static ResourceBundle rb =
            ResourceBundle.getBundle("org.dcm4che3.tool.mppsscp.messages");

    private static final Logger LOG = Logger.getLogger(MppsSCP.class);

    private IOD mppsNCreateIOD;
    private IOD mppsNSetIOD;

	@Autowired
	
	private MPPSService mppsRequestService;
	
	@Autowired
	private ConnectionUtil connectionUtil;

    protected final BasicMPPSSCP basicMPPSSCP = new BasicMPPSSCP() {

        @Override
        protected Attributes create(Association as, Attributes rq,
                                    Attributes rqAttrs, Attributes rsp) throws DicomServiceException {
       		return MppsSCP.this.create(as, rq, rqAttrs, rsp);
        }

        @Override
        protected Attributes set(Association as, Attributes rq, Attributes rqAttrs,
                                 Attributes rsp) throws DicomServiceException {
            return MppsSCP.this.set(as, rq, rqAttrs, rsp);
        }
    };
    
    public MppsSCP() {
    }

    public void init(String[] args, Device device, ApplicationEntity ae, Connection conn, DicomServiceRegistry serviceRegistry) throws IOException, ParseException, GeneralSecurityException {
        CommandLine cl = MppsSCP.parseComandLine(args);

        serviceRegistry.addDicomService(basicMPPSSCP);
        ae.setDimseRQHandler(serviceRegistry);

        CLIUtils.configureBindServer(conn, ae, cl);
        CLIUtils.configure(conn, cl);
        configureTransferCapability(ae, cl);
        connectionUtil.addTimeouts(conn);
        configure(cl.hasOption("no-validate"),
                cl.getOptionValue("mpps-ncreate-iod", "resource:mpps-ncreate-iod.xml"),
                cl.getOptionValue("mpps-nset-iod", "resource:mpps-nset-iod.xml"),
                cl.hasOption("ignore"),
                cl.getOptionValue("directory", "."));
        LOG.debug("MPPS SCP registered in dicom registry");
    }

    private void configure(boolean hasOptionNoValidate,
                           String mppsNCreateIOD,
                           String mppsNSetIOD,
                           boolean ignore,
                           String directory) throws IOException, GeneralSecurityException {
        configureIODs(this, hasOptionNoValidate,
                mppsNCreateIOD,
                mppsNSetIOD);
    }

    private void setMppsNCreateIOD(IOD mppsNCreateIOD) {
        this.mppsNCreateIOD = mppsNCreateIOD;
    }

    private void setMppsNSetIOD(IOD mppsNSetIOD) {
        this.mppsNSetIOD = mppsNSetIOD;
    }

    private static CommandLine parseComandLine(String[] args) throws ParseException {
        Options opts = new Options();
        CLIUtils.addBindServerOption(opts);
        CLIUtils.addAEOptions(opts);
        CLIUtils.addCommonOptions(opts);
        return CLIUtils.parseComandLine(args, opts, rb, MppsSCP.class);
    }

    private static void configureIODs(MppsSCP main, boolean hasOptionNoValidate, String mppsNCreateIOD, String mppsNSetIOD)
            throws IOException {
        if (!hasOptionNoValidate) {
            main.setMppsNCreateIOD(IOD.load(mppsNCreateIOD));
            main.setMppsNSetIOD(IOD.load(mppsNSetIOD));
        }
    }

    private static void configureTransferCapability(ApplicationEntity ae,
                                                    CommandLine cl) throws IOException {
        Properties p = CLIUtils.loadProperties(
                cl.getOptionValue("sop-classes",
                        "resource:sop-classes.properties"),
                null);
        for (String cuid : p.stringPropertyNames()) {
            String ts = p.getProperty(cuid);
            ae.addTransferCapability(
                    new TransferCapability(null,
                            CLIUtils.toUID(cuid),
                            TransferCapability.Role.SCP,
                            CLIUtils.toUIDs(ts)));
        }
    }

    private Attributes create(Association as, Attributes rq, Attributes rqAttrs, Attributes rsp)
            throws DicomServiceException {
    	LOG.debug("MPPS N-CREATE is invoked");
        if (mppsNCreateIOD != null) {
            ValidationResult result = rqAttrs.validate(mppsNCreateIOD);
            if (!result.isValid()) {
            	LOG.error("Validation of MPPS N-CREATE request failed, " + result.toString());
                throw DicomServiceException.valueOf(result, rqAttrs);
            }
        }
        String ppsStatus = rqAttrs.getString(Tag.PerformedProcedureStepStatus);
        if(ppsStatus == null || !"IN PROGRESS".equalsIgnoreCase(ppsStatus)) {
    		rsp.setInt(Tag.Status, VR.US, 0x0106);
            rsp.setString(Tag.ErrorComment, VR.LO, "Invalid Performed Procedure Step Status attribute value");
            LOG.error("Invalid Performed Procedure Step Status attribute value. Attribute value must be \"IN PROGRESS\"");
            return null;
        }
        // Process the request
        return mppsRequestService.processMPPSNCreate(as, rq, rqAttrs, rsp);
    }

    private Attributes set(Association as, Attributes rq, Attributes rqAttrs, Attributes rsp)
            throws DicomServiceException {
    	LOG.debug("MPPS MPPS-N-SET is invoked");
        if (mppsNSetIOD != null) {
            ValidationResult result = rqAttrs.validate(mppsNSetIOD);
            if (!result.isValid()) {
            	LOG.error("Validation of MPPS N-SET request failed, " + result.toString());
            	DicomServiceException exc = DicomServiceException.valueOf(result, rqAttrs);
            	exc.setUID(Tag.AffectedSOPClassUID, rsp.getString(Tag.AffectedSOPClassUID));
            	exc.setUID(Tag.AffectedSOPInstanceUID, rsp.getString(Tag.AffectedSOPInstanceUID));
            	throw exc;
            }
        }
        return mppsRequestService.processMPPSNSet(as, rq, rqAttrs, rsp);
    }
}
