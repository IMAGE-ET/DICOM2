__author__ = 't_schutte'

import requests
import socket

from checks import AgentCheck
from utils.dockerutil import get_client, set_docker_settings

class dockerIDEXX(AgentCheck):

    def __init__(self, name, init_config, agentConfig, instances=None):
        if instances is not None and len(instances) > 1:
            raise Exception("Docker check only supports one configured instance.")
        AgentCheck.__init__(self, name, init_config,
                            agentConfig, instances=instances)

        self.init_success = False
        self.init()

    def init(self):
        try:
            # We configure the check with the right cgroup settings for this host
            # Just needs to be done once
            instance = self.instances[0]
            set_docker_settings(self.init_config, instance)

            self.client = get_client()

        except Exception, e:
            self.log.critical(e)
            self.warning("Initialization failed. Will retry at next iteration")
        else:
            self.init_success = True

    def check(self, instance):
        """Run the Docker check for one instance."""
        if not self.init_success:
            # Initialization can fail if cgroups are not ready. So we retry if needed
            # https://github.com/DataDog/dd-agent/issues/1896
            self.init()
            if not self.init_success:
                # Initialization failed, will try later
                return

        if 'url' not in instance:
            self.log.info("Skipping instance, no url found")
            return

        url = instance['url']
        tags = instance.get('tags', '')

        info = self.client.info()
        #print float(info['DriverStatus'][6][1].partition(" ")[0])
        #print float(info['DriverStatus'][7][1].partition(" ")[0])
        #print float(info['DriverStatus'][8][1].partition(" ")[0])

        self.gauge('dockeridexx.data_space.used', float(info['DriverStatus'][6][1].partition(" ")[0]), tags=[tags])
        self.gauge('dockeridexx.data_space.total', float(info['DriverStatus'][7][1].partition(" ")[0]), tags=[tags])
        self.gauge('dockeridexx.data_space.available', float(info['DriverStatus'][8][1].partition(" ")[0]), tags=[tags])

if __name__ == '__main__':
    check, instances = dockerIDEXX.from_yaml('conf.d/dockeridexx.yaml')
    for instance in instances:
        print "\nRunning the check against url: %s" % (instance['url'])
        check.check(instance)
        if check.has_events():
            print 'Events: %s' % (check.get_events())
        print 'Metrics: %s' % (check.get_metrics())
